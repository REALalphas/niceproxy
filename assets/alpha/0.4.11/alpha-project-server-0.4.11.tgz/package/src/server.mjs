import { createServer } from 'node:http';
import { mkdir, cp, readFile, writeFile, stat, readdir, rename, rm } from 'node:fs/promises';
import { resolve, join, basename } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { json, body, within, webUrl, allowMutation, staticFile } from './http.mjs';
import { runNpm } from './npm.mjs';
import { cleanBuildCache, isBuildId } from './build-cache.mjs';

export async function createProjectServer(config) {
  const source = resolve(config.source || '.');
  if (!['react', 'qwik'].includes(config.framework)) throw new Error('framework: react or qwik');
  const hub = webUrl(config.hub || 'http://127.0.0.1:5180');
  const output = config.output || 'dist';
  within(source, output);
  if (!/^[a-zA-Z0-9:_-]+$/.test(config.buildScript || 'build'))
    throw new Error('Invalid npm script name');
  const builds = within(source, '.alpha-builds');
  await mkdir(builds, { recursive: true });
  const copyable = (path) =>
    !['node_modules', '.git', '.alpha-builds', 'dist', 'releases', '.env', '.env.local'].includes(
      basename(path),
    ) && !basename(path).startsWith('.env.');
  async function sourceDigest() {
    const hash = createHash('sha256');
    async function walk(dir) {
      for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a, b) =>
        a.name.localeCompare(b.name),
      )) {
        const path = join(dir, entry.name);
        if (!copyable(path)) continue;
        hash.update(path.slice(source.length));
        if (entry.isDirectory()) await walk(path);
        else {
          const bytes = await readFile(path);
          hash.update(String(bytes.length) + ':');
          hash.update(bytes);
        }
      }
    }
    await walk(source);
    return hash.digest('hex');
  }
  let active = null,
    building = false,
    lastError = null;
  let protectedId = null;
  const retained = new Map();
  try {
    const state = JSON.parse(await readFile(join(builds, 'active.json'), 'utf8'));
    if (!isBuildId(state.id)) throw Error('Invalid build id');
    protectedId = state.id;
    const dir = within(builds, state.id);
    await stat(within(dir, output + '/index.html'));
    active = state;
    retained.set(state.id, dir);
  } catch {}
  let cleanupError = null;
  const retainBuilds = config.retainBuilds ?? 3;
  if (!Number.isInteger(retainBuilds) || retainBuilds < 1 || retainBuilds > 100)
    throw Error('retainBuilds: integer from 1 to 100');
  async function cleanup() {
    try {
      const result = await cleanBuildCache({
        builds,
        output,
        activeId: active?.id ?? protectedId,
        retainBuilds,
      });
      for (const id of result.removed) retained.delete(id);
      cleanupError = null;
      return result;
    } catch (error) {
      cleanupError = error.message;
      return { kept: [], removed: [], error: cleanupError };
    }
  }
  await cleanup();
  const state = () => ({
    schema: 1,
    name: config.name || basename(source),
    framework: config.framework,
    version: active?.version || null,
    active: active ? `/runs/${active.id}/` : null,
    building,
    error: lastError,
    cleanupError,
    retainBuilds,
    update: '/_alpha/update',
  });
  async function upgrade(manifestUrl) {
    if (building) throw new Error('Build is already in progress');
    const url = webUrl(manifestUrl);
    if (url.origin !== hub.origin || !url.pathname.startsWith('/releases/'))
      throw new Error("Release must come from the configured Alpha's Hub");
    building = true;
    lastError = null;
    let candidate = null;
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error(`Release: HTTP ${response.status}`);
      const manifest = await response.json();
      if (manifest.schema !== 1 || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(manifest.version))
        throw new Error('Invalid manifest');
      const digest = createHash('sha256').update(JSON.stringify(manifest)).digest('hex');
      const sourceHash = await sourceDigest();
      if (active?.digest === digest && active?.sourceHash === sourceHash) {
        await cleanup();
        return state();
      }
      const id = `${manifest.version}-${randomUUID()}`;
      const dir = within(builds, id);
      candidate = { id, dir };
      await mkdir(dir);
      for (const entry of await readdir(source)) {
        const from = within(source, entry);
        if (copyable(from))
          await cp(from, within(dir, entry), { recursive: true, filter: copyable });
      }
      const pkg = JSON.parse(await readFile(join(dir, 'package.json'), 'utf8'));
      if (pkg.workspaces)
        throw new Error('For a monorepo, specify a separate build project without workspaces');
      // Replace UI pins in this copy; preserve unrelated package lock entries.
      const artifacts = within(dir, '.alpha-packages');
      await mkdir(artifacts, { recursive: true });
      const files = [];
      for (const name of ['@alpha/core', `@alpha/${config.framework}`]) {
        const item = manifest.packages?.[name];
        if (!item || !/^[\w.-]+\.tgz$/.test(item.file)) throw new Error(`Missing archive for ${name}`);
        const archive = await fetch(new URL(item.file, url), {
          signal: AbortSignal.timeout(30000),
        });
        if (!archive.ok) throw new Error(`Archive: HTTP ${archive.status}`);
        const bytes = Buffer.from(await archive.arrayBuffer());
        if (`sha512-${createHash('sha512').update(bytes).digest('base64')}` !== item.integrity)
          throw new Error(`Checksum ${name} does not match`);
        const file = within(artifacts, item.file);
        await writeFile(file, bytes);
        files.push(file);
        delete pkg.devDependencies?.[name];
        delete pkg.dependencies?.[name];
      }
      // The provider is already running; a snapshot only needs the UI packages.
      delete pkg.dependencies?.['@alpha/project-server'];
      delete pkg.devDependencies?.['@alpha/project-server'];
      delete pkg.dependencies?.[`@alpha/${config.framework === 'react' ? 'qwik' : 'react'}`];
      await writeFile(join(dir, 'package.json'), JSON.stringify(pkg, null, 2));
      await runNpm(
        ['install', '--ignore-scripts', '--no-audit', '--no-fund', '--save-exact', ...files],
        { cwd: dir },
      );
      const installed = JSON.parse(
        await readFile(join(dir, 'node_modules/@alpha/core/package.json')),
      );
      const adapter = JSON.parse(
        await readFile(join(dir, `node_modules/@alpha/${config.framework}/package.json`)),
      );
      if (installed.version !== manifest.version || adapter.version !== manifest.version)
        throw new Error('A different component version was installed');
      const env = { ...process.env, ...config.env, ALPHA_UI_VERSION: manifest.version };
      await runNpm(['run', config.buildScript || 'build'], { cwd: dir, env });
      await stat(within(dir, output + '/index.html'));
      const next = { id, version: manifest.version, digest, sourceHash };
      const pointer = within(builds, `.active-${randomUUID()}.json`);
      await writeFile(pointer, JSON.stringify(next));
      await rename(pointer, join(builds, 'active.json'));
      retained.set(id, dir);
      active = next;
      protectedId = id;
      await cleanup();
      return state();
    } catch (error) {
      if (candidate && candidate.id !== active?.id) {
        try {
          await rm(candidate.dir, { recursive: true, force: true });
        } catch (cleanupFailure) {
          cleanupError = cleanupFailure.message;
        }
      }
      lastError = error.message;
      throw error;
    } finally {
      building = false;
    }
  }
  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/.well-known/alpha-ui.json')
        return json(res, 200, state());
      if (req.method === 'POST' && url.pathname === '/_alpha/update') {
        if (!allowMutation(req, config.token)) return json(res, 403, { error: 'Access denied' });
        if (building) return json(res, 409, { error: 'Build is already in progress' });
        const data = await body(req);
        await upgrade(data.manifestUrl);
        return json(res, 200, state());
      }
      if (['GET', 'HEAD'].includes(req.method) && url.pathname.startsWith('/runs/')) {
        const match = url.pathname.match(/^\/runs\/([\w.-]+)\/(.*)$/);
        if (!match) return json(res, 404, { error: 'Build not found' });
        const dir = retained.get(match[1]) || within(builds, match[1]);
        return await staticFile(req, res, within(dir, output), match[2], { spa: true });
      }
      if (req.method === 'GET' && url.pathname === '/' && active) {
        res.writeHead(302, { Location: `/runs/${active.id}/` });
        return res.end();
      }
      return json(res, 404, { error: "Start the project from Alpha's Hub first" });
    } catch (error) {
      if (!res.headersSent) json(res, 500, { error: error.message, active: state() });
      else res.end();
    }
  });
  return { server, upgrade, state };
}
