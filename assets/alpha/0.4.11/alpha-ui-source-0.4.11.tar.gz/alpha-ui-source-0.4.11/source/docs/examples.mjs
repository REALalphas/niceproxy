// These examples are compiled for both frameworks and displayed as their source on the site.
const options = `const options = [
  { value: 'react', label: 'React' },
  { value: 'qwik', label: 'Qwik' },
  { value: 'unavailable', label: 'Unavailable option', disabled: true },
];`;
const navigation = `const items: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: 'home' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];`;

export const examples = {
  TextInput: {
    description: 'Controlled field with label, hint, and error state.',
    imports: ['TextInput', 'Text'],
    state: { value: '' },
    body: `<TextInput id="name" label="Name" value={state.value}
      hint="Enter a name" onValueChange@={value => update({ value })} />
    <Text>Value: {state.value || 'empty'}</Text>
    <TextInput id="disabled-name" label="Disabled field" value="" disabled />`,
  },
  TextArea: {
    description: 'Multiline controlled field with resize support.',
    imports: ['TextArea', 'Text'],
    state: { value: '' },
    body: `<TextArea id="description" label="Description" value={state.value} rows={3}
      onValueChange@={value => update({ value })} />
    <Text>Characters: {state.value.length}</Text>
    <TextArea id="disabled-description" label="Disabled field" value="" disabled />`,
  },
  Checkbox: {
    description: 'Checkbox with controlled selection and accessible label.',
    imports: ['Checkbox', 'Text'],
    state: { checked: false },
    body: `<Checkbox id="choice" label="Save choice for future sessions and other open windows"
      checked={state.checked} onCheckedChange@={checked => update({ checked })} />
    <Text>{state.checked ? 'Selected' : 'Not selected'}</Text>
    <Checkbox id="disabled-choice" label="Unavailable option" checked={false} disabled />`,
  },
  Switch: {
    description: 'Switch with controlled state.',
    imports: ['Switch', 'Text'],
    state: { checked: false },
    body: `<Switch id="notifications" label="Notifications" checked={state.checked}
      onCheckedChange@={checked => update({ checked })} />
    <Text>{state.checked ? 'Enabled' : 'Disabled'}</Text>
    <Switch id="disabled-notifications" label="Disabled switch" checked={false} disabled />`,
  },
  Select: {
    description: 'Dropdown select: native popup or shared library overlay.',
    imports: ['Select', 'Text'],
    state: { value: 'react' },
    setup: options,
    body: `<Select id="framework" label="Framework" value={state.value} options={options}
      popup="overlay" onValueChange@={value => update({ value })} />
    <Select id="native-framework" label="Native select" value={state.value} options={options}
      popup="native" onValueChange@={value => update({ value })} />
    <Text>Selected: {state.value}</Text>`,
  },
  Picker: {
    description: 'Compact controlled picker without a permanent border.',
    imports: ['Picker', 'Text'],
    state: { value: 'react' },
    setup: options,
    body: `<Picker label="Framework" value={state.value} options={options} popup="overlay"
      onValueChange@={value => update({ value })} />
    <Text>Selected: {state.value}</Text>`,
  },
  Icon: {
    description: 'Lucide icons in regular and bold weights.',
    imports: ['Icon', 'Text'],
    body: `<Stack direction="row" gap={4}>
      <Icon name="settings" label="Settings" />
      <Icon name="settings" label="Settings, bold" weight="bold" />
      <Icon name="search" label="Search" />
    </Stack>
    <Text>Regular — 1.5, bold — 2; size — 24 × 24 at 16px base.</Text>`,
  },
  Logo: {
    description: 'Service logo as a standalone SVG asset.',
    imports: ['Logo'],
    body: '<Logo label="Alpha\'s UI" />',
  },
  Text: {
    description: 'Typography: Noto Sans, Manrope, and Fira Code.',
    imports: ['Text'],
    body: `<Text as="h2" size="title">Manrope · Heading</Text>
    <Text>Noto Sans · Primary interface body text</Text>
    <Text tone="secondary">Additional description</Text>
    <Text font="mono">Fira Code · 384 kHz</Text>`,
  },
  Stack: {
    description: 'Layout of items using spacing from shared tokens.',
    imports: ['Switch', 'Card', 'Text'],
    state: { horizontal: false },
    body: `<Switch id="direction" label="Horizontal direction" checked={state.horizontal}
      onCheckedChange@={horizontal => update({ horizontal })} />
    <Stack direction={state.horizontal ? 'row' : 'column'} gap={4}>
      <Card><Text>First block</Text></Card>
      <Card><Text>Second block</Text></Card>
      <Card><Text>Third block</Text></Card>
    </Stack>`,
  },
  Card: {
    description: 'Surface for content composition.',
    imports: ['Card', 'Text', 'Button'],
    state: { clicks: 0 },
    body: `<Card><Stack gap={4}>
      <Text as="h2">Card</Text>
      <Text>Clicks: {state.clicks}</Text>
      <Button onPress@={() => update({ clicks: state.clicks + 1 })}>Action</Button>
    </Stack></Card>`,
  },
  ChatSurface: {
    description: 'Shared surface for chat components.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage'],
    body: `<ChatSurface><ChatThread>
      <ChatMessage text="Incoming message" />
      <ChatMessage text="Outgoing message" outgoing />
    </ChatThread></ChatSurface>`,
  },
  ChatMessage: {
    description: 'Message with actions available on hover and focus.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage', 'Text'],
    state: { favorite: false, notice: '' },
    body: `<ChatSurface><ChatThread>
      <ChatMessage text="Hover or navigate to actions with Tab"
        favorite={state.favorite}
        onFavorite@={() => update({ favorite: !state.favorite })}
        onReply@={() => update({ notice: 'Selected action: Reply' })} />
    </ChatThread></ChatSurface>
    <Text>{state.favorite ? 'Favorited' : 'Not favorited'}</Text>
    <Text>{state.notice}</Text>`,
  },
  ChatButton: {
    description: 'Composer actions: emoji, attach, record, and send.',
    imports: ['ChatSurface', 'ChatButton', 'Text'],
    state: { notice: '' },
    body: `<ChatSurface><Stack direction="row" gap={3}>
      <ChatButton variant="emoji" onPress@={() => update({ notice: 'Emoji' })} />
      <ChatButton variant="attach" onPress@={() => update({ notice: 'Attachment' })} />
      <ChatButton variant="record" onPress@={() => update({ notice: 'Record' })} />
      <ChatButton variant="send" onPress@={() => update({ notice: 'Send' })} />
    </Stack></ChatSurface>
    <Text>{state.notice || 'Choose an action'}</Text>`,
  },
  ChatInput: {
    description: 'Controlled message input field.',
    imports: ['ChatSurface', 'ChatInput', 'Text'],
    state: { value: '' },
    body: `<ChatSurface><ChatInput value={state.value} onValueChange@={value => update({ value })} /></ChatSurface>
    <Text>Characters: {state.value.length}</Text>`,
  },
  ChatThread: {
    description: 'Message thread with shared grouping.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage'],
    body: `<ChatSurface><ChatThread label="Conversation example">
      <ChatMessage text="First message" />
      <ChatMessage text="Next message" />
      <ChatMessage text="Reply" outgoing />
    </ChatThread></ChatSurface>`,
  },
  ChatComposer: {
    description: 'Composition of message input and send actions.',
    imports: ['ChatSurface', 'ChatComposer', 'Text'],
    state: { value: '', sent: '', recording: false },
    body: `<ChatSurface><ChatComposer value={state.value}
      onValueChange@={value => update({ value })}
      onEmoji@={() => update({ value: state.value + '🙂' })}
      onRecord@={() => update({ recording: !state.recording })}
      onSend@={() => { if (state.value.trim()) update({ sent: state.value, value: '' }); }} />
    </ChatSurface>
    <Text>{state.sent ? 'Sent locally: ' + state.sent : 'Enter a message'}</Text>
    <Text>{state.recording ? 'Voice message recording selected' : 'Recording not selected'}</Text>`,
    notes:
      'Sending and toggling recording in the example only update browser state. Microphone access and message persistence are wired by the app.',
  },
  Badge: {
    description: 'Notification counter inside a navigation item.',
    imports: ['NavButton', 'Button', 'Text'],
    state: { count: 3, selected: false },
    body: `<Stack direction="row" align="start" gap={4}>
      <NavButton label="Chat" icon="messageReply"
        notifications={state.count > 99 ? '99+' : state.count} selected={state.selected}
        onPress@={() => update({ selected: !state.selected })} />
    </Stack>
    <Stack direction="row" gap={3}>
      <Button onPress@={() => update({ count: state.count + 1 })}>Add notification</Button>
      <Button variant="simple" onPress@={() => update({ count: 100 })}>Show 99+</Button>
    </Stack>
    <Text>Notifications: {state.count}</Text>`,
    notes:
      'Badge is part of a navigation item rather than a standalone block. Pass the value via notifications on NavButton or BottomNav items. This example uses a standard NavButton, which places Badge next to the icon automatically.',
  },
  Button: {
    description: 'Button with shared pressed, loading, and disabled states.',
    imports: ['Button', 'Text'],
    state: { clicks: 0 },
    body: `<Button onPress@={() => update({ clicks: state.clicks + 1 })}>
      Press button with long label
    </Button>
    <Text>Clicks: {state.clicks}</Text>
    <Stack direction="row" gap={3}>
      <Button variant="simple" onPress@={() => update({ clicks: state.clicks + 1 })}>Simple</Button>
      <Button variant="blank" onPress@={() => update({ clicks: state.clicks + 1 })}>Blank</Button>
      <Button loading>Loading</Button>
      <Button disabled>Disabled</Button>
    </Stack>`,
  },
  IconButton: {
    description: 'Icon action with a required accessible label.',
    imports: ['IconButton', 'Text'],
    state: { pressed: false },
    body: `<IconButton icon="heart" label="Favorite" pressed={state.pressed}
      onPress@={() => update({ pressed: !state.pressed })} />
    <Text>{state.pressed ? 'Selected' : 'Not selected'}</Text>
    <IconButton icon="settings" label="Disabled settings" disabled />`,
  },
  Profile: {
    description: 'Profile in default, loading, unstable, and error states.',
    imports: ['Profile', 'Text'],
    state: { notice: '' },
    body: `<Stack direction="row" gap={3}>
      <Stack align="start" gap={2}><Text>Default</Text>
        <Profile label="Account" onPress@={() => update({ notice: 'Open account' })} />
      </Stack>
      <Stack align="start" gap={2}><Text>Loading</Text>
        <Profile label="Loading account" state="loading" />
      </Stack>
      <Stack align="start" gap={2}><Text>Unstable</Text>
        <Profile label="Unstable connection" state="unstable"
          onPress@={() => update({ notice: 'Unstable connection' })} />
      </Stack>
      <Stack align="start" gap={2}><Text>Error</Text>
        <Profile label="Account error" state="error"
          onPress@={() => update({ notice: 'Account error' })} />
      </Stack>
    </Stack>
    <Text>{state.notice || 'Profile image is passed by the application via src.'}</Text>`,
  },
  HeadBar: {
    description: 'Header bar with controlled service selector and optional context.',
    imports: ['HeadBar', 'Text'],
    state: { value: 'react', context: 'react', notice: '' },
    setup: options,
    body: `<HeadBar serviceName="Alpha's UI" serviceValue={state.value} serviceOptions={options}
      onServiceChange@={value => update({ value })}
      context={{ label: 'Context', value: state.context, options }}
      onContextChange@={context => update({ context })}
      onAccountPress@={() => update({ notice: 'Open account' })} />
    <Text>Service: {state.value} · Context: {state.context}</Text>
    <Text>{state.notice}</Text>`,
  },
  NavButton: {
    description: 'Navigation button with selection and notification counter.',
    imports: ['NavButton', 'Text'],
    state: { selected: false },
    body: `<NavButton label="Chat" icon="messageReply" notifications="3" selected={state.selected}
      onPress@={() => update({ selected: !state.selected })} />
    <Text>{state.selected ? 'Selected' : 'Not selected'}</Text>`,
  },
  BottomNav: {
    description: 'Bottom navigation with controlled active item.',
    imports: ['BottomNav', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    body: `<BottomNav items={items} selectedId={state.selectedId}
      onSelect@={selectedId => update({ selectedId })} />
    <Text>Selected: {state.selectedId}</Text>`,
  },
  DrawerButton: {
    description: 'Drawer menu item with secondary text.',
    imports: ['DrawerButton'],
    state: { selected: false },
    body: `<DrawerButton label="Settings" icon="settings" secondaryText="Additional description below the label"
      secondaryPlacement="below" selected={state.selected}
      onPress@={() => update({ selected: !state.selected })} />`,
  },
  DrawerDivider: {
    description: 'Sidebar navigation group divider.',
    imports: ['DrawerDivider', 'DrawerButton'],
    state: { selectedId: 'overview' },
    body: `<DrawerButton label="Overview" icon="home" selected={state.selectedId === 'overview'}
      onPress@={() => update({ selectedId: 'overview' })} />
    <DrawerDivider label="Account" />
    <DrawerButton label="Settings" icon="settings" selected={state.selectedId === 'settings'}
      onPress@={() => update({ selectedId: 'settings' })} />`,
  },
  Sidebar: {
    description: 'Sidebar navigation with controlled active item.',
    imports: ['Sidebar', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    body: `<Sidebar items={items} selectedId={state.selectedId}
      onSelect@={selectedId => update({ selectedId })} />
    <Text>Selected: {state.selectedId}</Text>`,
  },
  AppShell: {
    description: 'Adaptive shell: header, navigation, and application content.',
    imports: ['AppShell', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    shell: true,
    body: `<AppShell serviceName="Alpha's UI" items={items} selectedId={state.selectedId} width="container"
      onSelect@={selectedId => update({ selectedId })}>
      <Stack gap={4}><Text as="h2">{items.find(item => item.id === state.selectedId)?.label}</Text>
      <Text>Content of the selected section.</Text></Stack>
    </AppShell>`,
  },
};
