#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { createProjectServer } from './server.mjs';
const file=resolve(process.argv[2]||'alpha.project.json');
const config=JSON.parse(await readFile(file,'utf8'));
config.source=resolve(dirname(file),config.source||'.');
const {server}=await createProjectServer(config);
server.listen(config.port||5191,'127.0.0.1',()=>console.log(`Alpha project: http://127.0.0.1:${config.port||5191}`));
