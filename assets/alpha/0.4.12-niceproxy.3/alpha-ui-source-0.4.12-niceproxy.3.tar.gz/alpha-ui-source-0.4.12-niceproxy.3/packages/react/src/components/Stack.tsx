// Generated from source/components/layout/Stack.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type StackProps = CommonProps & {
  gap?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
  direction?: 'column' | 'row';
  align?: 'start' | 'center' | 'stretch';
};
export function Stack(p: StackProps) {
  return (
    <div
      className={cx('as-stack', p.className)}
      data-gap={p.gap ?? 4}
      data-direction={p.direction ?? 'column'}
      data-align={p.align ?? 'stretch'}
    >
      {p.children}
    </div>
  );
}
