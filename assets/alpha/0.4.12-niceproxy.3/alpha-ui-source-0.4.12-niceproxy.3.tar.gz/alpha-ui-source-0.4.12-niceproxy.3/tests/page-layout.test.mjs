import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { AppShell, Page } from '../packages/react/dist/index.js';
test('full document shell removes dead chrome without changing embedded defaults', () => {
  const props = { serviceName: 'Example', items: [], selectedId: '' };
  const html = renderToStaticMarkup(
    createElement(AppShell, {
      ...props,
      viewport: 'full',
      serviceMode: 'static',
      showAccount: false,
    }),
  );
  assert.match(html, /data-viewport="full"/);
  assert.doesNotMatch(html, /as-profile|Switch service/);
  assert.match(html, /<div class="as-service">/);
  const legacy = renderToStaticMarkup(createElement(AppShell, props));
  assert.match(legacy, /data-viewport="content"/);
  assert.match(legacy, /as-profile/);
});
test('page is a neutral container with public width and inset variants', () => {
  const html = renderToStaticMarkup(
    createElement(
      Page,
      { width: 'form', viewport: 'full', inset: 'comfortable', gap: 5 },
      'content',
    ),
  );
  assert.match(html, /data-width="form"/);
  assert.match(html, /data-gap="5"/);
  assert.doesNotMatch(html, /<main/);
  assert.ok(html.includes('content'));
});

test('standalone page can own the viewport without a shell', () => {
  const html = renderToStaticMarkup(
    createElement(Page, { viewport: 'full', width: 'form' }, 'login'),
  );
  assert.match(html, /data-viewport="full"/);
  assert.doesNotMatch(html, /as-shell/);
});
