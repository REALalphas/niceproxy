export default {
  name: 'Stack',
  group: 'layout',
  sources: [],
  status: 'extension',
  props: `
gap?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
direction?: 'column' | 'row';
align?: 'start' | 'center' | 'stretch';
`,
  body: `
return (
  <div
    className={cx('as-stack', p.className)}
    data-gap={p.gap ?? 4}
    data-direction={p.direction ?? 'column'}
    data-align={p.align ?? 'stretch'}
  >
    @CHILDREN@
  </div>
);
`,
};
