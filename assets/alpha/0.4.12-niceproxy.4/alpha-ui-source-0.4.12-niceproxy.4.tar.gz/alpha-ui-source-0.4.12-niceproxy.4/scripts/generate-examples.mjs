import { components } from '../source/components/index.mjs';
import { renderExample } from './lib/docs-examples.mjs';

export async function generateExamples(emit) {
  for (const framework of ['react', 'qwik']) {
    const names = [];
    for (const { name } of components) {
      names.push(name);
      await emit(
        `apps/${framework}/src/examples/${name}.tsx`,
        '// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.\n' +
          (await renderExample(name, framework)),
        'typescript',
      );
    }
    await emit(
      `apps/${framework}/src/examples/index.ts`,
      '// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.\n' +
        names.map((name) => `import { ${name}Example } from './${name}';`).join('\n') +
        `\nexport const examples = { ${names.map((name) => `${name}: ${name}Example`).join(', ')} };\n`,
      'typescript',
    );
  }
}
