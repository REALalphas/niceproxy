import { spawn } from 'node:child_process';
import { readFile, writeFile, mkdtemp, rm, mkdir } from 'node:fs/promises';
import { join, resolve, extname } from 'node:path';
import { tmpdir } from 'node:os';
import assert from 'node:assert/strict';

await mkdir('output/yonix-review', { recursive: true });
const profile = await mkdtemp(join(tmpdir(), 'alpha-yonix-review-'));
const browser = spawn(
  'chromium',
  [
    '--headless',
    '--no-sandbox',
    '--disable-gpu',
    '--remote-debugging-port=9351',
    `--user-data-dir=${profile}`,
    'about:blank',
  ],
  { stdio: 'ignore' },
);
let socket;
try {
  let tabs;
  for (let attempt = 0; attempt < 80; attempt++) {
    try {
      tabs = await (await fetch('http://127.0.0.1:9351/json')).json();
      break;
    } catch {
      await new Promise((r) => setTimeout(r, 100));
    }
  }
  socket = new WebSocket(tabs.find((tab) => tab.type === 'page').webSocketDebuggerUrl);
  await new Promise((r) => socket.addEventListener('open', r, { once: true }));
  let id = 0;
  const requests = new Map();
  const errors = [];
  let framework = 'react';
  let prefix = '/';
  socket.addEventListener('message', async (event) => {
    const message = JSON.parse(event.data);
    if (message.id) {
      requests.get(message.id)?.(message);
      requests.delete(message.id);
    }
    if (message.method === 'Runtime.exceptionThrown')
      errors.push(
        message.params.exceptionDetails.text +
          ': ' +
          JSON.stringify(message.params.exceptionDetails.exception?.description),
      );
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error')
      errors.push(message.params.args.map((arg) => arg.description ?? arg.value).join(' '));
    if (message.method === 'Fetch.requestPaused') {
      const { requestId, request } = message.params;
      try {
        const path = decodeURIComponent(new URL(request.url).pathname).slice(prefix.length);
        const file = resolve(`apps/${framework}/dist`, path || 'index.html');
        assert.ok(file.startsWith(resolve(`apps/${framework}/dist`)));
        const data = await readFile(file);
        const mime =
          {
            '.html': 'text/html',
            '.js': 'text/javascript',
            '.css': 'text/css',
            '.svg': 'image/svg+xml',
            '.woff2': 'font/woff2',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
          }[extname(file)] || 'application/octet-stream';
        await call('Fetch.fulfillRequest', {
          requestId,
          responseCode: 200,
          responseHeaders: [{ name: 'Content-Type', value: mime }],
          body: data.toString('base64'),
        });
      } catch {
        await call('Fetch.fulfillRequest', { requestId, responseCode: 404, body: '' });
      }
    }
  });
  const call = (method, params = {}) =>
    new Promise((resolveCall, reject) => {
      const n = ++id;
      requests.set(n, (m) => (m.error ? reject(m.error) : resolveCall(m.result)));
      socket.send(JSON.stringify({ id: n, method, params }));
    });
  const evaluate = async (expression) => {
    const result = await call('Runtime.evaluate', {
      expression,
      awaitPromise: true,
      returnByValue: true,
    });
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
  const key = async (name) => {
    const code = { Enter: 13, Escape: 27, ArrowDown: 40, ArrowUp: 38, Tab: 9 }[name] || 0;
    await call('Input.dispatchKeyEvent', {
      type: 'keyDown',
      key: name,
      code: name,
      windowsVirtualKeyCode: code,
      text: name === 'Enter' ? '\r' : undefined,
    });
    await call('Input.dispatchKeyEvent', {
      type: 'keyUp',
      key: name,
      code: name,
      windowsVirtualKeyCode: code,
    });
  };
  await call('Page.enable');
  await call('Runtime.enable');
  const live = process.env.ALPHA_REVIEW_LIVE === '1';
  if (!live)
    await call('Fetch.enable', {
      patterns: [{ urlPattern: 'http://alpha-review.local/*', requestStage: 'Request' }],
    });
  const until = async (expression, label) => {
    for (let attempt = 0; attempt < 80; attempt++) {
      if (await evaluate(expression)) return;
      await new Promise((resolve) => setTimeout(resolve, 75));
    }
    console.error(
      await evaluate('({url:location.href,text:document.body.innerText.slice(0,1200)})'),
      errors,
    );
    throw new Error('Timed out: ' + label);
  };
  const pageUrl = () =>
    (live
      ? 'http://127.0.0.1:' + (framework === 'react' ? 5173 : 5174)
      : 'http://alpha-review.local') + prefix;
  const hover = async (selector) => {
    const rect = await evaluate(
      `(() => {const r=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`,
    );
    await call('Input.dispatchMouseEvent', { type: 'mouseMoved', ...rect });
  };
  for (framework of process.env.ALPHA_REVIEW_FRAMEWORK
    ? [process.env.ALPHA_REVIEW_FRAMEWORK]
    : ['react', 'qwik'])
    for (prefix of live ? ['/'] : ['/', '/review/'])
      for (const width of [1680, 320]) {
        await call('Emulation.setDeviceMetricsOverride', {
          width,
          height: 1000,
          deviceScaleFactor: 1,
          mobile: false,
        });
        await call('Emulation.setEmulatedMedia', {
          features: [{ name: 'prefers-reduced-motion', value: 'no-preference' }],
        });
        await call('Page.navigate', { url: pageUrl() + '?view=base' });
        await until(
          'document.querySelectorAll(".demo-stage .as-picker select").length===2',
          framework + ' native selects',
        );
        await evaluate('document.fonts.ready');
        await evaluate(
          'new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))',
        );
        assert.equal(
          await evaluate('document.documentElement.scrollWidth <= innerWidth'),
          true,
          'overflow ' + framework + ' ' + width,
        );
        assert.equal(
          await evaluate(
            'Math.round(document.querySelector(".demo-stage .as-shell").getBoundingClientRect().width)',
          ),
          await evaluate('Math.round(document.body.getBoundingClientRect().width)'),
          'example fills available container',
        );
        assert.equal(
          await evaluate('document.querySelectorAll(".demo-page-nav button").length'),
          2,
          'only catalog and example tabs',
        );
        assert.equal(
          await evaluate('document.querySelectorAll(".as-picker [role=listbox]").length'),
          0,
        );
        const contextSelector = '.as-headbar-context select';
        const serviceSelector = '.as-headbar-service select';
        const style = await evaluate(`(() => {
      const control=document.querySelector('${contextSelector}');
      const field=control.closest('.as-field');
      const icon=control.parentElement.querySelector('.as-icon');
      const c=getComputedStyle(control), i=getComputedStyle(icon);
      return {width:control.getBoundingClientRect().width,areaWidth:field.parentElement.getBoundingClientRect().width,
        iconSize:i.width,fontSize:c.fontSize,weight:c.fontWeight,iconWeight:icon.dataset.iconWeight,
        transition:c.transitionProperty,durations:c.transitionDuration,delays:c.transitionDelay,easing:c.transitionTimingFunction};
    })()`);
        assert.equal(style.iconSize, style.fontSize);
        assert.equal(style.weight, '400');
        assert.equal(style.iconWeight, 'bold', 'compact chevron uses bold Lucide stroke');
        assert.ok(style.transition.includes('box-shadow'));
        assert.equal(style.durations.split(', ')[0], '0.4s');
        assert.equal(style.delays.split(', ')[0], '0.033s');
        if (width >= 960) {
          assert.ok(style.width < style.areaWidth / 2, 'short selection sizes by content');
          const layout = await evaluate(`(() => {
        const sidebar=document.querySelector('.demo-stage .as-sidebar').getBoundingClientRect();
        const context=document.querySelector('.as-headbar-context').getBoundingClientRect();
        return {sidebarRight:sidebar.right,contextLeft:context.left};
      })()`);
          assert.ok(
            Math.abs(layout.sidebarRight - layout.contextLeft) < 1,
            'context right of sidebar ' + JSON.stringify(layout),
          );
        }
        const selectKey = async (selector, direction) => {
          await evaluate(`document.querySelector('${selector}').focus()`);
          const overlay = await evaluate(
            `document.querySelector('${selector}').dataset.popup==='overlay' && CSS.supports('appearance','base-select')`,
          );
          if (overlay) {
            await key('Enter');
            await until(
              `document.querySelector('${selector}').matches(':open, [data-as-overlay-open]')`,
              framework + ' keyboard open overlay',
            );
          }
          await key(direction);
          if (overlay) await key('Enter');
        };
        await selectKey(serviceSelector, 'ArrowDown');
        await until(
          `document.querySelector('${serviceSelector}').value==='storyteller' && document.querySelector('.as-headbar-service .as-select-size').textContent==='Storyteller'`,
          framework + ' controlled service',
        );
        assert.equal(
          await evaluate(`document.querySelector('${contextSelector}').value`),
          'workstation',
        );
        await selectKey(contextSelector, 'ArrowDown');
        await until(
          `document.querySelector('${contextSelector}').value==='server' && document.querySelector('.as-headbar-context .as-select-size').textContent==='Домашний сервер'`,
          framework + ' controlled machine',
        );
        await selectKey(contextSelector, 'End');
        await until(
          `document.querySelector('${contextSelector}').value==='long' && document.querySelector('.as-headbar-context .as-select-size').textContent.includes('очень длинное')`,
          framework + ' native End skips disabled',
        );
        assert.equal(
          await evaluate('document.documentElement.scrollWidth <= innerWidth'),
          true,
          'long selected label overflow',
        );
        await selectKey(contextSelector, 'Home');
        await until(
          `document.querySelector('${contextSelector}').value==='workstation'`,
          framework + ' Home skips placeholder',
        );
        await evaluate('document.querySelector("#demo-show-context").click()');
        await until(
          '!document.querySelector(".as-headbar-context")',
          framework + ' optional context',
        );
        await evaluate('document.querySelector("#demo-show-context").click()');
        await until(
          '!!document.querySelector(".as-headbar-context select")',
          framework + ' restore context',
        );
        const headerFrames = await evaluate(`(async()=>{
      const field=document.querySelector('.as-headbar-context select');
      field.click();
      const panel=document.querySelector('.as-select-overlay:not([inert])');
      const value=field.parentElement.querySelector('.as-select-value');
      const selected=panel.querySelector('[aria-selected=true]');
      const animations=field.parentElement.getAnimations({subtree:true});
      animations.forEach(a=>a.pause());
      const samples=[];
      for(const time of [0,40,400]){
        animations.forEach(a=>{a.currentTime=time;});
        await new Promise(resolve=>requestAnimationFrame(resolve));
        const c=getComputedStyle(panel),s=getComputedStyle(selected);
        const container=field.closest('.as-select-field').parentElement,containerCSS=getComputedStyle(container),arrow=panel.querySelector('.as-select-overlay-arrow');
        samples.push({items:[...panel.querySelectorAll('[role=option]')].map(row=>({selected:row.getAttribute('aria-selected')==='true',opacity:Number(getComputedStyle(row).opacity),distance:Number(row.style.getPropertyValue('--as-select-option-distance'))})),textWidth:selected.querySelector('.as-select-overlay-text > span').getBoundingClientRect().width,width:panel.getBoundingClientRect().width,fieldWidth:field.getBoundingClientRect().width,containerWidth:container.clientWidth-parseFloat(containerCSS.paddingLeft)-parseFloat(containerCSS.paddingRight),arrowGap:panel.getBoundingClientRect().right-parseFloat(getComputedStyle(arrow).left),arrowInset:parseFloat(c.getPropertyValue('--as-select-arrow-inset'))*parseFloat(getComputedStyle(document.documentElement).fontSize),time,sourceTop:value.getBoundingClientRect().top+value.getBoundingClientRect().height/2,selectedTop:selected.getBoundingClientRect().top+selected.getBoundingClientRect().height/2,opacity:s.opacity,background:getComputedStyle(selected,'::before').backgroundColor,fill:getComputedStyle(panel,'::before').backgroundColor,surface:c.backgroundColor});
      }
      animations.forEach(a=>a.finish());
      return samples;
    })()`);
        for (const frame of headerFrames) {
          assert.ok(
            Math.abs(frame.sourceTop - frame.selectedTop) < 1,
            'header source text follows selected row at ' + frame.time,
          );
          assert.equal(frame.opacity, '1');
          assert.ok(
            !frame.background.startsWith('rgba'),
            'header selection is opaque at ' + frame.time,
          );
        }
        assert.ok(
          Math.abs(headerFrames[0].width - headerFrames[0].fieldWidth) < 1,
          'overlay starts at the closed text width ' + JSON.stringify(headerFrames),
        );
        if (headerFrames[0].width < headerFrames[0].containerWidth - 1) {
          assert.ok(
            headerFrames[2].width > headerFrames[0].width + 1,
            'wide option expands the compact overlay',
          );
          assert.ok(
            headerFrames[1].width > headerFrames[0].width &&
              headerFrames[1].width < headerFrames[2].width,
            'width interpolates during opening',
          );
        }
        for (const frame of headerFrames) {
          assert.ok(
            Math.abs(frame.textWidth - headerFrames[0].textWidth) < 0.1,
            'ellipsis layout stays at the final item width throughout expansion',
          );
          assert.ok(
            frame.width <= frame.containerWidth + 1,
            'overlay stays within its container width',
          );
          assert.ok(Math.abs(frame.arrowGap) < 1, 'arrow follows the animated right edge');
        }
        assert.equal(headerFrames[0].fill, 'rgba(0, 0, 0, 0)', 'before starts transparent');
        assert.notEqual(headerFrames[1].fill, headerFrames[0].fill);
        assert.notEqual(
          headerFrames[1].fill,
          headerFrames[2].fill,
          'header lower background interpolates',
        );
        assert.equal(headerFrames[2].fill, 'rgba(34, 34, 34, 0.33)');
        assert.equal(
          headerFrames[0].surface,
          'rgb(34, 34, 34)',
          'opening starts on the header canvas',
        );
        assert.equal(
          headerFrames[2].surface,
          'rgb(41, 41, 41)',
          'opening transitions the base to the overlay surface',
        );
        assert.notEqual(
          headerFrames[1].surface,
          headerFrames[0].surface,
          'base background visibly interpolates',
        );
        assert.notEqual(
          headerFrames[1].surface,
          headerFrames[2].surface,
          'base background has a real intermediate color',
        );
        assert.ok(
          headerFrames[0].items.every((row) => row.opacity === (row.selected ? 1 : 0)),
          'selected stays visible while other rows start transparent',
        );
        assert.ok(
          headerFrames[2].items.every((row) => row.opacity === 1),
          'all rows finish fully visible',
        );
        const revealing = headerFrames[1].items
          .filter((row) => !row.selected)
          .sort((a, b) => a.distance - b.distance);
        assert.ok(
          revealing.some((row) => row.opacity > 0 && row.opacity < 1),
          'row opacity interpolates during expansion',
        );
        assert.ok(
          revealing.every((row, index) => !index || row.opacity <= revealing[index - 1].opacity),
          'opacity spreads from the selected item towards distant items',
        );
        await key('Escape');
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' header frame review closes',
        );
        await evaluate(`document.querySelector('.as-headbar-context select').click()`);
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' width selection opens',
        );
        const closingWidths = await evaluate(`(async()=>{
      const field=document.querySelector('.as-headbar-context select'),panel=document.querySelector('.as-select-overlay:not([inert])');
      panel.querySelector('[data-index="2"]').click();
      const animations=field.parentElement.getAnimations({subtree:true});
      animations.forEach(a=>{a.pause();a.currentTime=0;});
      for(let i=0;i<120 && field.parentElement.querySelector('.as-select-size').textContent!==panel.querySelector('[aria-selected=true]').textContent;i++)await new Promise(resolve=>requestAnimationFrame(resolve));
      const samples=[];
      for(const time of [0,150,399]){
        animations.forEach(a=>{a.currentTime=time;});
        await new Promise(resolve=>requestAnimationFrame(resolve));
        const arrow=panel.querySelector('.as-select-overlay-arrow');
        samples.push({items:[...panel.querySelectorAll('[role=option]')].map(row=>({selected:row.getAttribute('aria-selected')==='true',opacity:Number(getComputedStyle(row).opacity),distance:Number(row.style.getPropertyValue('--as-select-option-distance'))})),time,width:panel.getBoundingClientRect().width,fieldWidth:field.getBoundingClientRect().width,arrowGap:panel.getBoundingClientRect().right-parseFloat(getComputedStyle(arrow).left),textWidth:panel.querySelector('[aria-selected=true] .as-select-overlay-text > span').getBoundingClientRect().width,textViewport:panel.querySelector('[aria-selected=true] .as-select-overlay-text').getBoundingClientRect().width,sourceWidth:field.parentElement.querySelector('.as-select-value > span').getBoundingClientRect().width});
      }
      animations.forEach(a=>a.finish());
      return samples;
    })()`);
        assert.ok(
          Math.abs(closingWidths.at(-1).width - closingWidths.at(-1).fieldWidth) < 1,
          'compact overlay closes to the newly selected text width ' +
            JSON.stringify(closingWidths),
        );
        assert.ok(
          Math.abs(closingWidths.at(-1).textWidth - closingWidths.at(-1).sourceWidth) < 1,
          'closing label uses the same final ellipsis width as the source field',
        );
        assert.ok(
          closingWidths.every(
            (frame) => Math.abs(frame.textWidth - closingWidths.at(-1).textWidth) < 1,
          ),
          'closing ellipsis layout stays fixed while the overlay narrows',
        );
        if (closingWidths[0].width > closingWidths.at(-1).width + 1) {
          assert.ok(
            closingWidths[1].width < closingWidths[0].width &&
              closingWidths[1].width > closingWidths.at(-1).width,
            'closing width interpolates',
          );
        }
        closingWidths.forEach((frame) =>
          assert.ok(Math.abs(frame.arrowGap) < 1, 'arrow follows the closing right edge'),
        );
        assert.ok(
          closingWidths.every((frame) => frame.items.find((row) => row.selected).opacity === 1),
          'chosen row stays opaque throughout collapse',
        );
        assert.ok(
          closingWidths.at(-1).items.every((row) => row.selected || row.opacity < 0.001),
          'other rows disappear before the overlay is removed',
        );
        const fading = closingWidths[1].items
          .filter((row) => !row.selected)
          .sort((a, b) => a.distance - b.distance);
        assert.ok(
          fading.every((row, index) => !index || row.opacity <= fading[index - 1].opacity),
          'closing opacity recedes towards the newly selected item',
        );
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' width selection closes',
        );
        await evaluate('document.querySelector("#demo-show-context").focus()');
        const screenshot = await call('Page.captureScreenshot', {
          format: 'png',
          captureBeyondViewport: true,
        });
        await writeFile(
          `output/yonix-review/headbar-${framework}-${prefix === '/' ? 'root' : 'subdir'}-${width}.png`,
          Buffer.from(screenshot.data, 'base64'),
        );

        // Verify the same native Select in the catalog, plus legacy shell alignment.
        await call('Page.navigate', { url: pageUrl() + '?view=catalog' });
        await until('!!document.querySelector("#tab-navigation")', framework + ' catalog');
        await evaluate('document.querySelector("#tab-navigation").click()');
        await until(
          '!document.querySelector("#category-navigation").hidden',
          framework + ' navigation',
        );
        if (width >= 960) {
          const layout = await evaluate(`(() => {
        const shell=document.querySelector('.demo-navigation-stage .as-shell');
        const header=shell.querySelector('.as-headbar').getBoundingClientRect();
        const service=shell.querySelector('.as-headbar-service').getBoundingClientRect();
        const sidebar=shell.querySelector('.as-sidebar').getBoundingClientRect();
        const logo=shell.querySelector('.as-service .as-logo').getBoundingClientRect();
        const expected=parseFloat(getComputedStyle(document.documentElement).fontSize)*1.25;
        return {headerLeft:header.left,shellLeft:shell.getBoundingClientRect().left,serviceRight:service.right,sidebarRight:sidebar.right,logoInset:logo.left-header.left,expected};
      })()`);
          assert.ok(
            Math.abs(layout.serviceRight - layout.sidebarRight) < 1,
            'legacy header columns align ' + JSON.stringify(layout),
          );
          assert.ok(
            Math.abs(layout.logoInset - layout.expected) < 1,
            'legacy service has one inset ' + JSON.stringify(layout),
          );
        }
        const catalogShot = await call('Page.captureScreenshot', {
          format: 'png',
          captureBeyondViewport: true,
        });
        await writeFile(
          `output/yonix-review/catalog-${framework}-${prefix === '/' ? 'root' : 'subdir'}-${width}.png`,
          Buffer.from(catalogShot.data, 'base64'),
        );
        await evaluate('document.querySelector("#tab-controls").click()');
        await until(
          '!document.querySelector("#category-controls").hidden',
          framework + ' controls',
        );
        await evaluate('document.querySelector("#demo-picker").scrollIntoView({block:"center"})');
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
        await evaluate('document.activeElement.blur()');
        const inherited = await evaluate(`(() => {
      const keys=['transitionProperty','transitionDuration','transitionDelay','transitionTimingFunction'];
      return ['#demo-select','#demo-picker'].map(id=>{const c=getComputedStyle(document.querySelector(id));return keys.map(key=>c[key]);});
    })()`);
        assert.deepEqual(inherited[0], inherited[1], 'compact Select inherits all field motion');
        await hover('#demo-picker');
        // Pause the actual browser transition half way through to prove interpolation.
        const hoverAnimation =
          await evaluate(`new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const control=document.querySelector('#demo-picker');
      const animation=control.getAnimations().find(a=>a.transitionProperty==='box-shadow');
      if (!animation) { resolve(null);return; }
      const timing=animation.effect.getTiming();
      animation.pause();animation.currentTime=Number(timing.delay)+Number(timing.duration)/2;
      requestAnimationFrame(()=>{
        resolve({duration:timing.duration,delay:timing.delay,shadow:getComputedStyle(control).boxShadow,frames:animation.effect.getKeyframes().map(f=>f.boxShadow)});
        animation.finish();
      });
    })))`);
        assert.ok(hoverAnimation, 'browser runs hover animation');
        assert.equal(hoverAnimation.duration, 400);
        assert.equal(hoverAnimation.delay, 33);
        assert.ok(
          hoverAnimation.frames.every((frame) => frame !== hoverAnimation.shadow),
          'hover frame interpolates',
        );
        await evaluate(
          `document.querySelector('#demo-picker').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,button:0}))`,
        );
        assert.equal(
          await evaluate(`document.querySelector('#demo-picker').hasAttribute('data-as-pressed')`),
          true,
        );
        assert.equal(
          await evaluate(
            `getComputedStyle(document.querySelector('#demo-picker')).transitionDuration.split(', ')[0]`,
          ),
          '0.166s',
        );
        await evaluate(
          `document.querySelector('#demo-picker').dispatchEvent(new PointerEvent('pointerup',{bubbles:true,button:0}))`,
        );
        await until(
          `document.querySelector('#demo-picker').hasAttribute('data-as-release')`,
          framework + ' delegated release',
        );
        assert.equal(
          await evaluate(
            `getComputedStyle(document.querySelector('#demo-picker')).transitionDuration.split(', ')[0]`,
          ),
          '0.4s',
        );
        assert.equal(
          await evaluate(
            `getComputedStyle(document.querySelector('#demo-picker')).transitionDelay.split(', ')[0]`,
          ),
          '0s',
        );
        // Real clicks open a top-layer list directly over the existing field.
        const overlayClick = async (selector, block = 'center') => {
          await evaluate(
            `document.querySelector('${selector}').scrollIntoView({block:'${block}'})`,
          );
          const rect = await evaluate(
            `(()=>{const r=document.querySelector('${selector}').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`,
          );
          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', ...rect });
          await call('Input.dispatchMouseEvent', {
            type: 'mousePressed',
            button: 'left',
            buttons: 1,
            clickCount: 1,
            ...rect,
          });
          await call('Input.dispatchMouseEvent', {
            type: 'mouseReleased',
            button: 'left',
            buttons: 0,
            clickCount: 1,
            ...rect,
          });
          await until(
            `document.querySelector('${selector}').hasAttribute('data-as-overlay-open')`,
            framework + ' real overlay click',
          );
          return rect;
        };
        for (const selector of ['#demo-select', '#demo-picker']) {
          await evaluate(`document.querySelector('${selector}').scrollIntoView({block:'center'})`);
          const holdRect = await evaluate(
            `(()=>{const r=document.querySelector('${selector}').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`,
          );
          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', ...holdRect });
          await call('Input.dispatchMouseEvent', {
            type: 'mousePressed',
            button: 'left',
            buttons: 1,
            clickCount: 1,
            ...holdRect,
          });
          await evaluate('new Promise(resolve=>setTimeout(resolve,250))');
          assert.equal(
            await evaluate(
              `document.querySelector('${selector}').matches(':open, [data-as-overlay-open]')`,
            ),
            false,
            'holding does not open either list',
          );
          assert.equal(
            await evaluate(`document.querySelector('${selector}').hasAttribute('data-as-pressed')`),
            true,
            'holding keeps normal press state',
          );
          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0, buttons: 1 });
          await call('Input.dispatchMouseEvent', {
            type: 'mouseReleased',
            button: 'left',
            buttons: 0,
            clickCount: 1,
            x: 0,
            y: 0,
          });
          assert.equal(
            await evaluate(
              `document.querySelector('${selector}').hasAttribute('data-as-overlay-open')`,
            ),
            false,
            'release outside cancels opening',
          );
          const closedArrow = await evaluate(
            `(()=>{const s=document.querySelector('${selector}'),r=s.getBoundingClientRect(),a=s.parentElement.querySelector(':scope > .as-icon');return {placement:s.dataset.asPlacement,rotate:getComputedStyle(a).rotate,top:a.getBoundingClientRect().top,left:a.getBoundingClientRect().left,fieldTop:r.top};})()`,
          );
          assert.equal(closedArrow.placement, 'down', 'closed arrow predicts downward placement');
          await overlayClick(selector);
          assert.equal(
            await evaluate(
              `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase`,
            ),
            'expand',
            'click starts expansion immediately without waiting for press',
          );
          const expanding = await evaluate(`new Promise(resolve=>{
        const p=document.querySelector('.as-select-overlay:not([inert])');
        const source=document.querySelector('${selector}').parentElement.querySelector('.as-select-value');
        const animations=[...p.getAnimations({subtree:true}),...source.getAnimations()].filter(a=>a.effect.getTiming().duration===400);
        animations.forEach(a=>{a.pause();a.currentTime=200;});
        requestAnimationFrame(()=>{
          const r=document.querySelector('${selector}').getBoundingClientRect(),o=p.querySelector('[aria-selected=true]').getBoundingClientRect();
          resolve({sourceTop:source.getBoundingClientRect().top+source.getBoundingClientRect().height/2,sourceOpacity:getComputedStyle(source).opacity,selectedOpacity:getComputedStyle(p.querySelector('[aria-selected=true]')).opacity,selectedBackground:getComputedStyle(p.querySelector('[aria-selected=true]'),'::before').backgroundColor,top:r.top,optionTop:o.top+o.height/2,left:r.left,optionLeft:o.left,width:p.getBoundingClientRect().width,fieldWidth:r.width,shadow:getComputedStyle(p,'::after').boxShadow,contentFade:animations.some(a=>a.transitionProperty==='opacity' && a.effect.pseudoElement!=='::before'),animations:animations.map(a=>a.effect.getKeyframes())});
          animations.forEach(a=>a.finish());
        });
      })`);

          assert.ok(
            Math.abs(expanding.sourceTop - expanding.optionTop) < 1,
            'source value and overlay selection share their motion ' + JSON.stringify(expanding),
          );
          assert.equal(expanding.sourceOpacity, '1');
          assert.equal(expanding.selectedOpacity, '1');
          assert.ok(
            !expanding.selectedBackground.startsWith('rgba'),
            'selected background stays opaque through opening',
          );
          assert.ok(
            expanding.animations.some((frames) => frames.some((f) => f.height)),
            'height expands toward final placement',
          );
          assert.ok(
            expanding.width >= expanding.fieldWidth - 1,
            'overlay can grow beyond the field width',
          );
          assert.ok(Math.abs(expanding.left - expanding.optionLeft) < 1, 'no horizontal movement');
          assert.equal(
            expanding.contentFade,
            false,
            'opening does not fade the panel or selected text',
          );
          assert.ok(
            expanding.animations.every((frames) => frames.every((f) => f.width === undefined)),
            'width is shared through the animated custom property',
          );
          assert.ok(
            expanding.animations.some((frames) => frames.some((f) => f.boxShadow)),
            'frame thins during expansion',
          );
          const contour = expanding.animations.find((frames) => frames.some((f) => f.boxShadow));
          assert.ok(
            contour[0].boxShadow.includes('3px inset'),
            'initial contour has the doubled pressed width',
          );
          assert.ok(
            contour[0].boxShadow.includes('rgba(221, 221, 221, 0.4)'),
            'initial contour uses border-pressed color',
          );
          assert.ok(
            contour.at(-1).boxShadow.includes('3px inset'),
            'open contour retains the same doubled thickness as focused TextArea',
          );
          assert.ok(
            contour.at(-1).boxShadow.includes('rgba(153, 153, 153, 0.267)'),
            'target contour uses ordinary border color',
          );
          assert.ok(
            expanding.shadow.includes('3px inset'),
            'opening keeps focused thickness throughout',
          );
          assert.notEqual(
            expanding.shadow,
            contour[0].boxShadow,
            'pressed contour color interpolates immediately',
          );
          assert.notEqual(
            expanding.shadow,
            contour.at(-1).boxShadow,
            'contour color is still transitioning at an intermediate frame',
          );
          await until(
            `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
            framework + ' expansion completes',
          );
          const aligned = await evaluate(
            `(()=>{const s=document.querySelector('${selector}'),panel=document.querySelector('.as-select-overlay:not([inert])'),o=panel.querySelector('[aria-selected=true]'),r=s.getBoundingClientRect(),v=o.getBoundingClientRect(),c=getComputedStyle(s),p=getComputedStyle(o);return {top:r.top,optionTop:v.top,panelTop:panel.getBoundingClientRect().top,left:r.left+parseFloat(c.paddingLeft),optionLeft:v.left+parseFloat(p.paddingLeft),font:c.font,optionFont:p.font,width:r.width,optionWidth:v.width,topLayer:panel.matches(':popover-open'),placement:panel.dataset.placement,shadow:getComputedStyle(panel,'::after').boxShadow,border:getComputedStyle(panel).borderTopWidth};})()`,
          );
          assert.equal(aligned.topLayer, true, 'overlay uses top layer');
          const openingArrow = await evaluate(
            `(()=>{const s=document.querySelector('${selector}'),a=document.querySelector('.as-select-overlay-arrow'),r=a.getBoundingClientRect(),f=s.getBoundingClientRect(),c=getComputedStyle(a);return {rotate:c.rotate,top:r.top,left:r.left,center:r.top+r.height/2,fieldCenter:f.top+f.height/2,inRow:!!a.closest('[role=option]'),transition:c.transitionProperty};})()`,
          );
          assert.equal(openingArrow.rotate, '180deg', 'downward dropdown points up while open');
          assert.equal(
            openingArrow.inRow,
            false,
            'arrow belongs to the panel rather than a selected row',
          );
          assert.ok(
            Math.abs(openingArrow.center - openingArrow.fieldCenter) < 1,
            'arrow stays at field center',
          );
          assert.ok(
            Math.abs(openingArrow.top - closedArrow.top) < 1,
            'opening preserves the arrow height',
          );
          assert.ok(
            Math.abs(openingArrow.left - closedArrow.left - (aligned.optionWidth - aligned.width)) <
              1,
            'arrow follows the expanded panel width',
          );
          assert.equal(
            openingArrow.transition,
            'rotate',
            'direction uses a CSS rotation transition',
          );
          assert.equal(aligned.placement, 'down', 'downward placement when full list fits');
          assert.ok(
            Math.abs(aligned.top - aligned.panelTop) < 1,
            'downward overlay stays anchored to the field top ' + JSON.stringify(aligned),
          );
          assert.equal(aligned.border, '0px', 'no CSS border');
          assert.ok(
            aligned.shadow.includes('3px inset'),
            'expanded frame matches focused multiline thickness',
          );
          assert.ok(
            Math.abs(aligned.left - aligned.optionLeft) < 1,
            'text has same horizontal position',
          );
          assert.equal(aligned.font, aligned.optionFont, 'text keeps exact typography');
          assert.ok(aligned.optionWidth >= aligned.width - 1, 'overlay fits the wider options');
          const rowStyle = await evaluate(
            `(()=>{const r=document.querySelector('.as-select-overlay:not([inert]) [aria-selected=true]'),c=getComputedStyle(r);return {transition:c.transitionProperty,shadow:c.boxShadow,border:c.borderTopWidth};})()`,
          );
          assert.equal(
            rowStyle.transition,
            'color, background',
            'text hover and selected background use transitions',
          );
          assert.equal(rowStyle.shadow, 'none', 'row hover has no frame');
          assert.equal(rowStyle.border, '0px');
          const highlightGeometry = await evaluate(
            `(()=>{const p=document.querySelector('.as-select-overlay:not([inert])'),r=p.querySelector('[aria-selected=true]'),c=getComputedStyle(r,'::before'),radius=parseFloat(getComputedStyle(p).borderTopLeftRadius);return {insets:[c.top,c.right,c.bottom,c.left].map(parseFloat),radius:parseFloat(c.borderTopLeftRadius),outerRadius:radius,frame:parseFloat(getComputedStyle(p).getPropertyValue('--as-borderwidth-control'))*parseFloat(getComputedStyle(document.documentElement).fontSize)*2};})()`,
          );
          assert.ok(
            highlightGeometry.insets.every(
              (inset) => Math.abs(inset - 2 * highlightGeometry.frame) < 0.01,
            ),
            'selected background leaves two base strokes clear after the inner edge',
          );
          assert.ok(
            Math.abs(
              highlightGeometry.radius -
                (highlightGeometry.outerRadius - highlightGeometry.insets[0]),
            ) < 0.01,
            'inner highlight radius accounts for the contour thickness',
          );
          const rowHeight = await evaluate(
            `(()=>{const field=document.querySelector('${selector}'),p=document.querySelector('.as-select-overlay:not([inert])'),row=p.querySelector('[aria-selected=true]');return {field:field.getBoundingClientRect().height,row:row.getBoundingClientRect().height};})()`,
          );
          assert.ok(
            Math.abs(rowHeight.row - rowHeight.field) < 0.1,
            'overlay rows preserve the field height',
          );
          if (selector === '#demo-select') {
            const firstText = await evaluate(
              `(()=>{const field=document.querySelector('${selector}'),r=field.getBoundingClientRect(),row=document.querySelector('.as-select-overlay:not([inert]) [data-index="0"]').getBoundingClientRect();return {index:field.selectedIndex,fieldCenter:r.top+r.height/2,rowCenter:row.top+row.height/2};})()`,
            );
            if (firstText.index === 0)
              assert.ok(
                Math.abs(firstText.fieldCenter - firstText.rowCenter) < 0.1,
                'first selected text never moves during opening',
              );
          }
          const stationaryHover = await evaluate(`(async()=>{
        const panel=document.querySelector('.as-select-overlay:not([inert])');
        await Promise.all(panel.getAnimations({subtree:true}).map(a=>a.finished.catch(()=>{})));
        const row=panel.querySelector('.as-select-overlay-option:hover:not(:disabled)');
        return row?{color:getComputedStyle(row).color,target:getComputedStyle(panel).getPropertyValue('--as-select-option-hover-color').trim()}:null;
      })()`);
          if (selector === '#demo-select') {
            assert.ok(stationaryHover, 'row beneath the stationary click pointer is hovered');
            assert.equal(
              stationaryHover.color,
              'rgb(255, 255, 255)',
              'hover uses the ordinary white token without moving the mouse',
            );
          }
          const hoverRow =
            '.as-select-overlay:not([inert]) .as-select-overlay-option:not(:disabled):not([aria-selected=true])';
          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
          await evaluate(
            'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
          );
          const selectionStyle = await evaluate(
            `(()=>{const panel=document.querySelector('.as-select-overlay:not([inert])'),selected=panel.querySelector('[aria-selected=true]'),other=panel.querySelector(':not(:disabled)[aria-selected=false]'),s=getComputedStyle(selected),o=getComputedStyle(other),p=getComputedStyle(panel);return {selectedColor:s.color,otherColor:o.color,selectedBackground:getComputedStyle(selected,'::before').backgroundColor,otherBackground:getComputedStyle(other,'::before').backgroundColor,surface:p.backgroundColor,colorVariable:p.getPropertyValue('--as-select-option-color'),backgroundVariable:p.getPropertyValue('--as-select-option-selected-background')};})()`,
          );
          assert.equal(
            selectionStyle.selectedColor,
            selectionStyle.otherColor,
            'selected text stays gray like other idle options',
          );
          assert.notEqual(
            selectionStyle.selectedBackground,
            selectionStyle.otherBackground,
            'selected value is marked by background',
          );
          assert.ok(
            selectionStyle.colorVariable.trim() && selectionStyle.backgroundVariable.trim(),
            'text and selected background use variables',
          );
          assert.equal(
            selectionStyle.selectedBackground,
            'rgb(51, 51, 51)',
            'selected background uses the lighter navigation token',
          );
          const beforeHover = await evaluate(
            `(()=>{const c=getComputedStyle(document.querySelector('${hoverRow}'));return {color:c.color,background:getComputedStyle(document.querySelector('${hoverRow}'),'::before').backgroundColor,shadow:c.boxShadow};})()`,
          );
          await hover(hoverRow);
          await evaluate(
            'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
          );
          const afterHover = await evaluate(
            `(()=>{const c=getComputedStyle(document.querySelector('${hoverRow}'));return {color:c.color,background:getComputedStyle(document.querySelector('${hoverRow}'),'::before').backgroundColor,shadow:c.boxShadow};})()`,
          );
          assert.notEqual(beforeHover.color, afterHover.color, 'hover changes text color');
          assert.equal(
            afterHover.color,
            'rgb(255, 255, 255)',
            'option hover uses the ordinary white token',
          );
          assert.equal(
            beforeHover.background,
            afterHover.background,
            'hover leaves background unchanged',
          );
          assert.equal(beforeHover.shadow, afterHover.shadow, 'hover leaves frame unchanged');
          assert.equal(
            await evaluate(
              `getComputedStyle(document.querySelector('.as-select-overlay:not([inert]) [aria-selected=true]')).color`,
            ),
            selectionStyle.selectedColor,
            'hover on another value does not highlight selected text',
          );
          assert.equal(
            await evaluate(
              `getComputedStyle(document.querySelector('.as-select-overlay:not([inert]) [aria-selected=true]'),'::before').backgroundColor`,
            ),
            selectionStyle.selectedBackground,
            'hover preserves selected background',
          );

          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
          await call('Input.dispatchMouseEvent', {
            type: 'mousePressed',
            button: 'left',
            buttons: 1,
            clickCount: 1,
            x: 0,
            y: 0,
          });
          await call('Input.dispatchMouseEvent', {
            type: 'mouseReleased',
            button: 'left',
            buttons: 0,
            clickCount: 1,
            x: 0,
            y: 0,
          });
          await until(
            `!document.querySelector('${selector}').hasAttribute('data-as-overlay-open')`,
            framework + ' outside click closes overlay',
          );
          const endingFrame = await evaluate(`(()=>{
        const panel=document.querySelector('.as-select-overlay[inert]'),field=document.querySelector('${selector}');
        const target=getComputedStyle(field),p=getComputedStyle(panel);
        const animation=panel.getAnimations({subtree:true}).find(a=>a.transitionProperty==='box-shadow');
        const result={color:p.getPropertyValue('--as-field-frame-color').trim(),fieldColor:target.getPropertyValue('--as-field-frame-color').trim(),width:p.getPropertyValue('--as-field-frame-width').trim(),fieldWidth:target.getPropertyValue('--as-field-frame-width').trim(),target:animation?.effect.getKeyframes().at(-1).boxShadow};
        if(animation){animation.pause();animation.currentTime=Number(animation.effect.getTiming().duration)/5;result.middle=getComputedStyle(panel,'::after').boxShadow;animation.play();}
        return result;
      })()`);
          assert.equal(
            endingFrame.color,
            endingFrame.fieldColor,
            'closing overlay inherits final input contour color',
          );
          assert.equal(
            endingFrame.width,
            endingFrame.fieldWidth,
            'closing overlay inherits final input contour thickness',
          );
          if (selector === '#demo-picker') {
            assert.equal(
              endingFrame.color,
              'transparent',
              'plain selector contour ends transparent',
            );
            assert.ok(
              endingFrame.target.includes('rgba(0, 0, 0, 0)'),
              'plain contour transitions to full transparency',
            );
            assert.notEqual(
              endingFrame.middle,
              endingFrame.target,
              'plain contour fades before the panel is removed',
            );
          }
          const closing = await evaluate(
            `(()=>{const p=document.querySelector('.as-select-overlay[inert]');return p ? {phase:p.dataset.phase,opacity:getComputedStyle(p).opacity,contentFade:p.getAnimations({subtree:true}).some(a=>a.transitionProperty==='opacity' && a.effect.pseudoElement!=='::before'),frames:p.getAnimations({subtree:true}).flatMap(a=>a.effect.getKeyframes())} : null;})()`,
          );
          assert.ok(closing && closing.phase === 'close', 'closing collapses the overlay');
          assert.equal(closing.opacity, '1', 'closing never fades the text');
          assert.equal(
            closing.contentFade,
            false,
            'closing does not fade the panel or selected text',
          );
          assert.ok(
            closing.frames.every((f) => f.width === undefined),
            'closing width uses the shared custom property',
          );
          await evaluate(
            `document.querySelector('.as-select-overlay[inert]').getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=80;})`,
          );
          await hover(selector);
          const hoveredClosing = await evaluate(`(()=>{
        const field=document.querySelector('${selector}'),panel=document.querySelector('.as-select-overlay[inert]');
        const f=getComputedStyle(field),p=getComputedStyle(panel);
        const animation=panel.getAnimations({subtree:true}).find(a=>a.transitionProperty==='box-shadow');
        return {sourceOpacity:getComputedStyle(field).opacity,hovered:field.matches(':hover'),fieldColor:f.getPropertyValue('--as-field-frame-color').trim(),color:p.getPropertyValue('--as-field-frame-color').trim(),target:animation?.effect.getKeyframes().at(-1).boxShadow};
      })()`);
          assert.equal(
            hoveredClosing.hovered,
            true,
            'pointer enters the actual select during collapse',
          );
          assert.equal(
            hoveredClosing.sourceOpacity,
            '0',
            'native field cannot paint clipped corner fragments behind the closing overlay',
          );
          assert.equal(
            hoveredClosing.color,
            hoveredClosing.fieldColor,
            'closing contour follows hover without an attribute mutation',
          );
          assert.ok(
            hoveredClosing.target?.includes('221, 221, 221'),
            'closing contour transitions to the input hover color',
          );
          const stationaryClosing = await evaluate(`(async()=>{
        const field=document.querySelector('${selector}'),panel=document.querySelector('.as-select-overlay[inert]');
        const frame=panel.getAnimations({subtree:true}).find(a=>a.transitionProperty==='box-shadow');
        frame.pause();frame.currentTime=Number(frame.effect.getTiming().duration)/2;
        await new Promise(resolve=>requestAnimationFrame(resolve));
        const middle=getComputedStyle(panel,'::after').boxShadow;
        const target=frame.effect.getKeyframes().at(-1).boxShadow;
        frame.currentTime=Number(frame.effect.getTiming().duration)-.001;
        const end=getComputedStyle(panel,'::after').boxShadow;
        frame.currentTime=Number(frame.effect.getTiming().duration)/2;
        return {middle,target,end,hovered:field.matches(':hover')};
      })()`);
          assert.equal(
            stationaryClosing.hovered,
            true,
            'hover stays active with a stationary pointer during collapse',
          );
          assert.notEqual(
            stationaryClosing.middle,
            stationaryClosing.target,
            'hover interpolates before closing completes',
          );
          assert.equal(
            stationaryClosing.end,
            stationaryClosing.target,
            'hover reaches its final contour while overlay still exists',
          );
          await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
          const unhoveredClosing = await evaluate(`(()=>{
        const field=document.querySelector('${selector}'),panel=document.querySelector('.as-select-overlay[inert]');
        return {fieldColor:getComputedStyle(field).getPropertyValue('--as-field-frame-color').trim(),color:getComputedStyle(panel).getPropertyValue('--as-field-frame-color').trim()};
      })()`);
          assert.equal(
            unhoveredClosing.color,
            unhoveredClosing.fieldColor,
            'closing contour also follows pointer exit',
          );
          await evaluate(
            `document.querySelector('.as-select-overlay[inert]').getAnimations({subtree:true}).forEach(a=>a.play())`,
          );
          await evaluate(
            'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
          );
          await until(
            '!document.querySelector(".as-select-overlay")',
            framework + ' contour ownership returns after closing',
          );
          assert.equal(
            await evaluate(`getComputedStyle(document.querySelector('${selector}')).opacity`),
            '1',
            'native field paints again after the overlay is removed',
          );
        }
        assert.equal(
          await evaluate('document.querySelector("#demo-picker-disabled").disabled'),
          true,
        );
        const selectorColors = await evaluate(
          `['#demo-select','#demo-picker'].map(id=>{const s=document.querySelector(id),v=s.parentElement.querySelector('.as-select-value'),a=s.parentElement.querySelector(':scope > .as-icon');return {select:getComputedStyle(s).color,value:getComputedStyle(v).color,arrow:getComputedStyle(a).color};})`,
        );
        selectorColors.forEach((colors, index) =>
          assert.deepEqual(
            colors,
            {
              select: 'rgb(255, 255, 255)',
              value: 'rgb(255, 255, 255)',
              arrow: index === 0 ? 'rgb(255, 255, 255)' : 'rgb(221, 221, 221)',
            },
            'closed selector retains its ordinary value and arrow colors',
          ),
        );
        const disabledArrows = await evaluate(
          `['#demo-select-disabled','#demo-picker-disabled','#demo-picker-empty'].map(id=>{const s=document.querySelector(id),a=s.parentElement.querySelector(':scope > .as-icon');return {color:getComputedStyle(a).color,token:getComputedStyle(s).getPropertyValue('--as-color-text-disabled').trim(),weight:a.dataset.iconWeight};})`,
        );
        for (const arrow of disabledArrows)
          assert.equal(
            arrow.color,
            'rgb(102, 102, 102)',
            'disabled chevron matches disabled text color',
          );
        assert.equal(disabledArrows[0].weight, 'regular', 'normal field retains regular stroke');
        assert.equal(disabledArrows[1].weight, 'bold', 'compact field uses bold stroke');
        assert.equal(await evaluate('document.querySelector("#demo-picker-empty").disabled'), true);
        assert.equal(await evaluate('document.querySelector("#demo-picker-unknown").value'), '');
        await overlayClick('#demo-select');
        await key('Home');
        await key('Enter');
        await until(
          `document.querySelector('#demo-select').value==='react' && !document.querySelector('#demo-select').hasAttribute('data-as-overlay-open')`,
          framework + ' choose first overlay row',
        );
        const originalRect = await evaluate(
          `document.querySelector('#demo-select').getBoundingClientRect().toJSON()`,
        );
        await overlayClick('#demo-select');
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' ready for selection background',
        );
        const nextRow = await evaluate(
          `(()=>{const r=document.querySelector('.as-select-overlay:not([inert]) [data-index="1"]').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`,
        );
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', ...nextRow });
        await call('Input.dispatchMouseEvent', {
          type: 'mousePressed',
          button: 'left',
          buttons: 1,
          clickCount: 1,
          ...nextRow,
        });
        await call('Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          button: 'left',
          buttons: 0,
          clickCount: 1,
          ...nextRow,
        });
        assert.equal(
          await evaluate(`document.querySelector('#demo-select').value`),
          'qwik',
          'controlled value changes immediately on selection',
        );
        const selectionFrame = await evaluate(`(async()=>{
      const panel=document.querySelector('.as-select-overlay');
      const animations=panel.getAnimations({subtree:true});
      const backgrounds=animations.filter(a=>a.transitionProperty?.startsWith('background'));
      const row=panel.querySelector('[aria-selected=true]'),previous=panel.querySelector('[data-index="0"]');
      const previousAnimation=backgrounds.find(a=>a.effect.target===previous);
      const nextAnimation=backgrounds.find(a=>a.effect.target===row);
      const duration=nextAnimation.effect.getTiming().duration;
      animations.forEach(a=>{a.pause();a.currentTime=Number(duration)/2;});
      await new Promise(resolve=>requestAnimationFrame(resolve));
      const c=getComputedStyle(row);
      const frame={phase:panel.dataset.phase,inert:panel.inert,background:getComputedStyle(row,'::before').backgroundColor,color:c.color,count:backgrounds.length,choiceDuration:duration,oldDuration:previousAnimation.effect.getTiming().duration,oldTarget:previousAnimation.effect.getKeyframes().at(-1).backgroundColor,newTarget:nextAnimation.effect.getKeyframes().at(-1).backgroundColor};
      nextAnimation.finish();
      await new Promise(resolve=>requestAnimationFrame(resolve));
      const returning=panel.getAnimations({subtree:true}).find(a=>a.transitionProperty?.startsWith('background') && a.effect.target===row);
      frame.returning=returning?{duration:returning.effect.getTiming().duration,frames:returning.effect.getKeyframes()}:null;
      if(returning){
        returning.pause();returning.currentTime=Number(returning.effect.getTiming().duration)/5;
        frame.returnMiddle=getComputedStyle(row,'::before').backgroundColor;
        returning.finish();
        frame.returnEnd=getComputedStyle(row,'::before').backgroundColor;
      } else frame.returnEnd=getComputedStyle(row,'::before').backgroundColor;
      animations.forEach(a=>a.finish());
      frame.oldRest=getComputedStyle(previous,'::before').backgroundColor;
      const shape=getComputedStyle(row,'::before');
      frame.endRadii=shape.borderTopLeftRadius.split(' ').map(parseFloat);
      frame.expectedRadius=parseFloat(getComputedStyle(panel).borderTopLeftRadius)-parseFloat(shape.left);
      return frame;
    })()`);
        assert.equal(selectionFrame.phase, 'close', 'selection immediately starts collapsing');
        assert.equal(
          selectionFrame.inert,
          true,
          'selection does not wait with an interactive list',
        );
        assert.ok(selectionFrame.count >= 2, 'background changes run during collapse');
        assert.equal(
          selectionFrame.oldDuration,
          400,
          'old highlight retains its original duration',
        );
        assert.equal(
          selectionFrame.choiceDuration,
          166,
          'new highlight retains the interaction duration',
        );
        assert.equal(
          selectionFrame.oldTarget,
          'rgba(0, 0, 0, 0)',
          'previous selection transitions to transparent',
        );
        assert.equal(
          selectionFrame.oldRest,
          'rgba(0, 0, 0, 0)',
          'previous row has no leftover lighter background',
        );
        assert.notEqual(
          selectionFrame.background,
          'rgba(0, 0, 0, 0)',
          'chosen row stays visible while collapsing',
        );
        assert.equal(
          selectionFrame.newTarget,
          'rgb(51, 51, 51)',
          'new selection uses the lighter navigation token',
        );
        assert.notEqual(
          selectionFrame.background,
          selectionFrame.newTarget,
          'new selected background interpolates during collapse',
        );
        assert.ok(selectionFrame.color, 'selected text remains visible throughout collapse');
        assert.ok(
          selectionFrame.returning,
          'lighter selection returns to the ordinary surface before removal',
        );
        assert.equal(selectionFrame.returning.frames.at(-1).backgroundColor, 'rgb(41, 41, 41)');
        assert.notEqual(
          selectionFrame.returnMiddle,
          selectionFrame.returnEnd,
          'lighter highlight fades back smoothly',
        );
        assert.equal(
          selectionFrame.returnEnd,
          'rgb(41, 41, 41)',
          'collapsed row already matches the ordinary field surface',
        );
        assert.ok(
          selectionFrame.endRadii.every(
            (radius) => Math.abs(radius - selectionFrame.expectedRadius) < 0.01,
          ),
          'closed highlight radius follows its inset',
        );
        await until(
          `document.querySelector('#demo-select').value==='qwik'  && !document.querySelector('#demo-select').hasAttribute('data-as-overlay-open')`,
          framework + ' choose next overlay row',
        );
        await overlayClick('#demo-select');
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' lower selected expansion',
        );
        const lowerRow = await evaluate(
          `(()=>{const s=document.querySelector('#demo-select'),r=s.getBoundingClientRect(),panel=document.querySelector('.as-select-overlay:not([inert])'),o=panel.getBoundingClientRect(),a=panel.querySelector('.as-select-overlay-arrow').getBoundingClientRect();return {top:r.top,panelTop:o.top,index:s.selectedIndex,arrowCenter:a.top+a.height/2,fieldCenter:r.top+r.height/2};})()`,
        );
        assert.ok(
          Math.abs(lowerRow.arrowCenter - lowerRow.fieldCenter) < 1,
          'selecting another row does not move the arrow',
        );
        assert.equal(lowerRow.index, 1);
        const cssTransitions = await evaluate(
          `document.querySelector('.as-select-overlay:not([inert])').getAnimations({subtree:true}).every(a=>a instanceof CSSTransition)`,
        );
        assert.equal(cssTransitions, true, 'overlay uses CSS transitions only');
        assert.ok(Math.abs(originalRect.top - lowerRow.top) < 1, 'field stays in place');
        assert.ok(
          Math.abs(lowerRow.top - lowerRow.panelTop) < 1,
          'lower selection keeps the field anchor',
        );
        assert.equal(
          await evaluate(
            `(()=>{const field=document.querySelector('#demo-select'),source=field.parentElement.querySelector('.as-select-value'),row=document.querySelector('.as-select-overlay:not([inert]) [aria-selected=true]');return Math.abs(source.getBoundingClientRect().top+source.getBoundingClientRect().height/2-row.getBoundingClientRect().top-row.getBoundingClientRect().height/2)<1;})()`,
          ),
          true,
          'lower source value ends at selected row',
        );
        await evaluate(
          'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
        );
        const overlayShot = await call('Page.captureScreenshot', {
          format: 'png',
          captureBeyondViewport: false,
        });
        await writeFile(
          `output/yonix-review/overlay-${framework}-${prefix === '/' ? 'root' : 'subdir'}-${width}.png`,
          Buffer.from(overlayShot.data, 'base64'),
        );
        const documentScroll = await evaluate(`(async()=>{
      const panel=document.querySelector('.as-select-overlay:not([inert])');
      const field=document.querySelector('#demo-select');
      const before={field:field.getBoundingClientRect().top,panel:panel.getBoundingClientRect().top,scroll:scrollY};
      window.scrollBy({top:40,behavior:'instant'});
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      const after={field:field.getBoundingClientRect().top,panel:panel.getBoundingClientRect().top};
      const result={anchored:panel.hasAttribute('data-anchored'),phase:panel.dataset.phase,fieldDelta:after.field-before.field,panelDelta:after.panel-before.panel,gap:after.panel-after.field,position:getComputedStyle(panel).positionAnchor,anchor:getComputedStyle(field).anchorName};
      window.scrollTo({top:before.scroll,behavior:'instant'});
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      return result;
    })()`);
        assert.equal(documentScroll.anchored, true, 'overlay uses CSS anchoring');
        assert.equal(documentScroll.phase, 'open', 'document scroll does not close overlay');
        assert.equal(
          documentScroll.position,
          documentScroll.anchor,
          'CSS anchor points at the actual select',
        );
        assert.ok(Math.abs(documentScroll.fieldDelta) > 1, 'document really scrolled');
        assert.ok(
          Math.abs(documentScroll.fieldDelta - documentScroll.panelDelta) < 1,
          'overlay follows document scroll without lag',
        );
        assert.ok(Math.abs(documentScroll.gap) < 1, 'overlay preserves the field anchor');
        await call('Input.dispatchMouseEvent', {
          type: 'mousePressed',
          button: 'left',
          buttons: 1,
          clickCount: 1,
          x: 0,
          y: 0,
        });
        await call('Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          button: 'left',
          buttons: 0,
          clickCount: 1,
          x: 0,
          y: 0,
        });
        await until(
          `!document.querySelector('#demo-select').hasAttribute('data-as-overlay-open')`,
          framework + ' outside click closes overlay',
        );
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' closing overlay releases anchor',
        );
        assert.equal(
          await evaluate(
            `document.querySelector('#demo-select').style.getPropertyValue('anchor-name')`,
          ),
          '',
          'temporary anchor is cleaned up',
        );
        await evaluate(`(() => {
      const field=document.querySelector('#demo-select');
      const section=field.closest('.demo-section');
      window.anchorScrollSection=section;
      window.anchorScrollStyle=section.getAttribute('style');
      section.style.height='12rem';section.style.overflow='auto';
      field.scrollIntoView({block:'center'});
    })()`);
        await overlayClick('#demo-select');
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' nested scroller open',
        );
        const nestedScroll = await evaluate(`(async()=>{
      const section=window.anchorScrollSection,field=document.querySelector('#demo-select');
      const panel=document.querySelector('.as-select-overlay:not([inert])');
      const edge=()=>panel.dataset.placement==='up'?'bottom':'top';
      const before={field:field.getBoundingClientRect()[edge()],panel:panel.getBoundingClientRect()[edge()]};
      section.scrollTop+=24;
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      return {phase:panel.dataset.phase,fieldDelta:field.getBoundingClientRect()[edge()]-before.field,panelDelta:panel.getBoundingClientRect()[edge()]-before.panel,gap:panel.getBoundingClientRect()[edge()]-field.getBoundingClientRect()[edge()],frameTop:parseFloat(getComputedStyle(panel,'::after').top),frameTopRaw:getComputedStyle(panel,'::after').top,frameBottom:getComputedStyle(panel,'::after').bottom,frameAnchor:getComputedStyle(panel,'::after').positionAnchor,panelTop:panel.getBoundingClientRect().top};
    })()`);
        assert.equal(nestedScroll.phase, 'open', 'nested scroll does not close overlay');
        assert.ok(Math.abs(nestedScroll.fieldDelta) > 1, 'nested container really scrolled');
        assert.ok(
          Math.abs(nestedScroll.fieldDelta - nestedScroll.panelDelta) < 1,
          'CSS anchor follows nested scrolling without lag',
        );
        assert.ok(Math.abs(nestedScroll.gap) < 1, 'nested scroll preserves the anchored edge');
        const panelObject = await call('Runtime.evaluate', {
          expression: "document.querySelector('.as-select-overlay:not([inert])')",
        });
        const { node: panelNode } = await call('DOM.describeNode', {
          objectId: panelObject.result.objectId,
          depth: 1,
        });
        const contour = panelNode.pseudoElements.find((node) => node.pseudoType === 'after');
        const { model: contourBox } = await call('DOM.getBoxModel', {
          backendNodeId: contour.backendNodeId,
        });
        assert.ok(
          Math.abs(contourBox.border[1] - nestedScroll.panelTop) < 1,
          'rendered inset contour follows the panel ' +
            JSON.stringify({ top: contourBox.border[1], panel: nestedScroll.panelTop }),
        );
        await key('Escape');
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' nested scroller close',
        );
        await evaluate(
          `(() => {const section=window.anchorScrollSection;if(window.anchorScrollStyle===null)section.removeAttribute('style');else section.setAttribute('style',window.anchorScrollStyle);delete window.anchorScrollSection;delete window.anchorScrollStyle;})()`,
        );
        const morph = await evaluate(`(async()=>{
      const field=document.querySelector('#demo-select'),arrow=field.parentElement.querySelector(':scope > .as-icon'),path=arrow.querySelector('path');
      field.scrollIntoView({block:'center'});
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      await Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})));
      field.style.setProperty('position','relative');
      field.style.setProperty('top',(innerHeight-field.getBoundingClientRect().bottom)+'px');
      document.dispatchEvent(new Event('scroll'));
      const animation=path.getAnimations().find(a=>a.transitionProperty==='d');
      if(!animation)return {found:false,placement:field.dataset.asPlacement};
      animation.pause();
      const frames=animation.effect.getKeyframes(),from=frames[0].d.match(/-?\\d+(?:\\.\\d+)?/g).map(Number),to=frames.at(-1).d.match(/-?\\d+(?:\\.\\d+)?/g).map(Number);
      let low=0,high=Number(animation.effect.getTiming().duration);
      for(let i=0;i<24;i++){
        const time=(low+high)/2;animation.currentTime=time;
        const values=getComputedStyle(path).d.match(/-?\\d+(?:\\.\\d+)?/g).map(Number);
        const progress=(values[1]-from[1])/(to[1]-from[1]);
        if(progress<.5)low=time;else high=time;
      }
      const values=getComputedStyle(path).d.match(/-?\\d+(?:\\.\\d+)?/g).map(Number);
      const result={found:true,rotate:getComputedStyle(arrow).rotate,flatY:[values[1],values[3],values[5]],frames,duration:animation.effect.getTiming().duration};
      animation.finish();
      field.style.removeProperty('position');field.style.removeProperty('top');document.dispatchEvent(new Event('scroll'));
      await Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})));
      return result;
    })()`);
        assert.equal(morph.found, true, 'placement change morphs the Lucide chevron path');
        assert.equal(morph.rotate, '0deg', 'placement change does not rotate the arrow');
        assert.ok(
          Math.max(...morph.flatY) - Math.min(...morph.flatY) < 0.01,
          'chevron passes through a straight horizontal line',
        );
        assert.equal(morph.duration, 400, 'shape morph uses shared fast timing');
        await call('Emulation.setDeviceMetricsOverride', {
          width,
          height: 400,
          deviceScaleFactor: 1,
          mobile: false,
        });
        await evaluate(`document.querySelector('#demo-select').scrollIntoView({block:'end'})`);
        await evaluate(
          'new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))',
        );
        assert.equal(
          await evaluate(`document.querySelector('#demo-select').dataset.asPlacement`),
          'up',
          'closed arrow predicts upward placement near viewport bottom',
        );
        await evaluate(
          'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
        );
        assert.ok(
          await evaluate(
            `(()=>{const s=document.querySelector('#demo-select'),a=s.parentElement.querySelector(':scope > .as-icon').getBoundingClientRect(),r=s.getBoundingClientRect();return Math.abs(a.top+a.height/2-r.top-r.height/2)<1;})()`,
          ),
          'closed upward arrow stays vertically centered inside the field',
        );
        await overlayClick('#demo-select', 'end');
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' edge expansion',
        );
        const upward = await evaluate(
          `(()=>{const s=document.querySelector('#demo-select'),r=s.getBoundingClientRect(),p=document.querySelector('.as-select-overlay:not([inert])'),v=p.getBoundingClientRect(),unit=parseFloat(getComputedStyle(document.documentElement).fontSize);return {placement:p.dataset.placement,fieldBottom:r.bottom,panelBottom:v.bottom,top:v.top,height:v.height,fullHeight:p.scrollHeight,gap:unit*.5};})()`,
        );
        assert.equal(upward.placement, 'up', 'insufficient space below chooses upward placement');
        const upwardArrow = await evaluate(
          `(()=>{const s=document.querySelector('#demo-select'),a=document.querySelector('.as-select-overlay-arrow'),r=a.getBoundingClientRect(),f=s.getBoundingClientRect();return {rotate:getComputedStyle(a).rotate,center:r.top+r.height/2,fieldCenter:f.top+f.height/2};})()`,
        );
        assert.equal(upwardArrow.rotate, '180deg', 'opening rotates the upward chevron back down');
        assert.ok(
          Math.abs(upwardArrow.center - upwardArrow.fieldCenter) < 1,
          'upward expansion leaves arrow at the field',
        );
        assert.ok(
          Math.abs(upward.panelBottom - upward.fieldBottom) < 1,
          'upward overlay stays anchored to the field bottom',
        );
        assert.equal(
          await evaluate(
            `(()=>{const field=document.querySelector('#demo-select'),source=field.parentElement.querySelector('.as-select-value'),row=document.querySelector('.as-select-overlay:not([inert]) [aria-selected=true]');return Math.abs(source.getBoundingClientRect().top+source.getBoundingClientRect().height/2-row.getBoundingClientRect().top-row.getBoundingClientRect().height/2)<1;})()`,
          ),
          true,
          'upward source value ends at selected row',
        );
        assert.ok(
          upward.panelBottom <= 401,
          'edge overlay stays within viewport ' + JSON.stringify(upward),
        );
        assert.ok(upward.top >= upward.gap - 1, 'upward overlay stays in viewport');
        await key('Escape');
        await until(
          `!document.querySelector('#demo-select').hasAttribute('data-as-overlay-open')`,
          framework + ' close upward overlay',
        );
        await call('Emulation.setDeviceMetricsOverride', {
          width,
          height: 1000,
          deviceScaleFactor: 1,
          mobile: false,
        });

        await call('Emulation.setEmulatedMedia', {
          features: [{ name: 'prefers-reduced-motion', value: 'reduce' }],
        });
        assert.equal(
          await evaluate(
            `getComputedStyle(document.querySelector('#demo-picker')).transitionProperty`,
          ),
          'none',
          'reduced motion',
        );
        await evaluate(`document.querySelector('#demo-select').focus()`);
        await key('Enter');
        await key('Escape');
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' reduced motion closes without leftovers',
        );

        await call('Emulation.setEmulatedMedia', {
          features: [{ name: 'prefers-reduced-motion', value: 'no-preference' }],
        });
        for (let rapid = 0; rapid < 4; rapid++) {
          await overlayClick('#demo-select');
          await key('Escape');
        }
        await evaluate(
          'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
        );
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' interrupted transitions leave no panel',
        );
        assert.equal(
          await evaluate(
            `document.querySelector('#demo-select').parentElement.style.getPropertyValue('--as-select-value-offset')`,
          ),
          '',
          'closing cleans up value offset',
        );
        await evaluate('document.activeElement.blur()');
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
        await evaluate(
          'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
        );
        const rest = await evaluate(
          `(()=>{const c=getComputedStyle(document.querySelector('#demo-select'));return {color:c.getPropertyValue('--as-field-frame-color'),shadow:c.boxShadow};})()`,
        );
        assert.equal(rest.color.trim(), '#9994', 'rapid toggles restore neutral frame variable');
        assert.ok(
          !rest.shadow.includes('255, 255, 255') && !rest.shadow.includes('221, 221, 221'),
          'no white press frame stuck after rapid toggles',
        );
        // Change actual inherited tokens: JS press timing and every opening layer must follow.
        await evaluate(`(() => {
      const field=document.querySelector('#demo-select');
      field.style.setProperty('--as-motion-interaction','275ms');
      field.style.setProperty('--as-motion-fast','720ms');
      field.style.setProperty('--as-motion-normal','910ms');
      field.style.setProperty('--as-motion-hover-delay','51ms');
      field.style.setProperty('--as-control-easing','cubic-bezier(0.3, 0.1, 0.2, 1)');
      field.dataset.motionSpeed='normal';
    })()`);
        await overlayClick('#demo-select');
        const customOpening = await evaluate(`(() => {
      const panel=document.querySelector('.as-select-overlay:not([inert])');
      const selected=panel.querySelector('[aria-selected=true]');
      const source=document.querySelector('#demo-select').parentElement.querySelector('.as-select-value');
      const animations=[...panel.getAnimations({subtree:true}),...source.getAnimations()];
      animations.forEach(a=>{a.pause();a.currentTime=275/2;});
      const details=animations.map(a=>({property:a.transitionProperty,duration:a.effect.getTiming().duration,delay:a.effect.getTiming().delay,easing:a.effect.getTiming().easing,frames:a.effect.getKeyframes()}));
      const color=animations.find(a=>a.transitionProperty==='color' && a.effect.target===selected);
      if(color) color.currentTime=275/2;
      const middle=getComputedStyle(selected).color;
      return {phase:panel.dataset.phase,details,middle,targetColor:selected.matches(':hover')?'rgb(255, 255, 255)':'rgb(221, 221, 221)',sourceTop:source.getBoundingClientRect().top+source.getBoundingClientRect().height/2,selectedTop:selected.getBoundingClientRect().top+selected.getBoundingClientRect().height/2,sourceOpacity:getComputedStyle(source).opacity,selectedOpacity:getComputedStyle(selected).opacity,selectedBackground:getComputedStyle(selected,'::before').backgroundColor,duration:getComputedStyle(panel).transitionDuration};
    })()`);
        assert.equal(customOpening.phase, 'expand', 'custom tokens do not delay opening');
        assert.ok(
          Math.abs(customOpening.sourceTop - customOpening.selectedTop) < 1,
          'moving field value follows selected overlay row at mid-frame',
        );
        assert.equal(customOpening.sourceOpacity, '1');
        assert.equal(customOpening.selectedOpacity, '1');
        assert.ok(
          !customOpening.selectedBackground.startsWith('rgba'),
          'selected background is fully opaque while changing color',
        );
        const colorFade = customOpening.details.find((a) => a.property === 'color');
        if (colorFade) {
          assert.equal(colorFade.frames[0].color, 'rgb(255, 255, 255)');
          assert.equal(colorFade.frames.at(-1).color, customOpening.targetColor);
        } else
          assert.equal(
            customOpening.targetColor,
            'rgb(255, 255, 255)',
            'hovered selection retains the ordinary white color',
          );
        const initialContour = customOpening.details.find((a) => a.property === 'box-shadow');
        assert.ok(initialContour, 'contour starts its transition immediately without a hold');
        assert.equal(initialContour.duration, 720);
        assert.equal(initialContour.delay, 0);
        const backgroundFades = customOpening.details.filter((a) =>
          a.property?.startsWith('background'),
        );
        const fillFade = customOpening.details.find(
          (a) =>
            a.property?.startsWith('background') &&
            a.frames[0].backgroundColor === 'rgba(0, 0, 0, 0)' &&
            a.frames.at(-1).backgroundColor === 'rgba(34, 34, 34, 0.33)',
        );
        assert.ok(fillFade, 'darkening layer transitions its background');
        assert.equal(fillFade.duration, 275, 'darkening inherits the faster interaction token');
        assert.equal(
          fillFade.easing,
          initialContour.easing,
          'darkening inherits the control easing',
        );
        assert.equal(
          fillFade.delay,
          initialContour.delay,
          'darkening starts with the contour transition',
        );
        assert.ok(
          backgroundFades.some((a) => a.frames.at(-1).backgroundColor === 'rgb(51, 51, 51)'),
          'selected row transitions to lighter navigation background',
        );
        assert.ok(
          backgroundFades.filter((a) => a !== fillFade).every((a) => a.duration === 910),
          'item backgrounds retain the selected motion duration',
        );
        const layers = await evaluate(
          `(()=>{const panel=document.querySelector('.as-select-overlay:not([inert])'),c=getComputedStyle(panel);const b=getComputedStyle(panel,'::before');return {image:c.backgroundImage,beforeImage:b.backgroundImage,base:b.backgroundColor,opacity:b.opacity,surface:c.backgroundColor,content:b.content,pointerEvents:b.pointerEvents,disabled:c.getPropertyValue('--as-color-disabled-fill')};})()`,
        );
        assert.equal(layers.image, 'none');
        assert.equal(layers.beforeImage, 'none', 'backgrounds have no images or gradients');
        assert.equal(layers.content, '""', 'second background is the before pseudo-element');
        assert.equal(layers.pointerEvents, 'none');
        assert.notEqual(
          layers.base,
          'rgba(0, 0, 0, 0)',
          'before background is visible mid-transition',
        );
        assert.notEqual(
          layers.base,
          'rgba(34, 34, 34, 0.33)',
          'before background has not reached its final fill',
        );
        assert.equal(layers.opacity, '1', 'darkening does not animate layer opacity');
        assert.equal(layers.surface, 'rgb(41, 41, 41)', 'ordinary overlay surface stays opaque');
        assert.ok(
          customOpening.details.every((a) => a.easing === 'cubic-bezier(0.3, 0.1, 0.2, 1)'),
          'all opening layers inherit the control easing',
        );
        assert.ok(
          customOpening.details.some((a) => a.property === 'height' && a.duration === 910),
          'geometry follows normal speed immediately',
        );
        const multilineTiming = await evaluate(`(()=>{
      const wrap=document.querySelector('#demo-description').parentElement;
      wrap.style.setProperty('--as-motion-fast','720ms');
      wrap.style.setProperty('--as-control-easing','cubic-bezier(0.3, 0.1, 0.2, 1)');
      wrap.setAttribute('data-as-release','');
      const c=getComputedStyle(wrap),o=getComputedStyle(document.querySelector('.as-select-overlay:not([inert])'),'::after');
      const result={textarea:[c.transitionDuration,c.transitionDelay,c.transitionTimingFunction],overlay:[o.transitionDuration,o.transitionDelay,o.transitionTimingFunction]};
      wrap.removeAttribute('data-as-release');wrap.style.removeProperty('--as-motion-fast');wrap.style.removeProperty('--as-control-easing');
      return result;
    })()`);
        assert.deepEqual(
          multilineTiming.overlay,
          multilineTiming.textarea,
          'overlay contour matches actual multiline release duration, delay and easing',
        );
        await evaluate(
          `document.querySelector('#demo-select').parentElement.getAnimations({subtree:true}).forEach(a=>a.finish())`,
        );
        await until(
          `document.querySelector('.as-select-overlay:not([inert])')?.dataset.phase==='open'`,
          framework + ' custom opening completes',
        );
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 0, y: 0 });
        await evaluate(
          'Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})))',
        );
        await call('Input.dispatchMouseEvent', {
          type: 'mousePressed',
          button: 'left',
          buttons: 1,
          clickCount: 1,
          x: 0,
          y: 0,
        });
        await call('Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          button: 'left',
          buttons: 0,
          clickCount: 1,
          x: 0,
          y: 0,
        });
        const closingFrame = await evaluate(`(() => {
      const panel=document.querySelector('.as-select-overlay[inert]');
      const animations=panel.getAnimations({subtree:true});
      animations.forEach(a=>{a.pause();a.currentTime=a.transitionProperty?.startsWith('background')?Number(a.effect.getTiming().duration)/2:455;});
      const c=getComputedStyle(panel),b=getComputedStyle(panel,'::before');
      const selected=panel.querySelector('[aria-selected=true]');
      const text=animations.find(a=>a.transitionProperty==='color' && a.effect.target===selected);
      const frame={color:getComputedStyle(selected).color,text:text?{duration:text.effect.getTiming().duration,delay:text.effect.getTiming().delay,frames:text.effect.getKeyframes()}:null,surface:c.backgroundColor,background:b.backgroundColor,opacity:Number(b.opacity),fades:animations.filter(a=>a.transitionProperty?.startsWith('background') && a.effect.target===panel && a.effect.pseudoElement==='::before').map(a=>a.effect.getKeyframes())};
      animations.forEach(a=>a.finish());return frame;
    })()`);
        assert.ok(closingFrame.text, 'closing selected text transitions back to ordinary color');
        assert.equal(closingFrame.text.duration, 910);
        assert.equal(closingFrame.text.delay, 0);
        assert.equal(closingFrame.text.frames[0].color, 'rgb(221, 221, 221)');
        assert.equal(closingFrame.text.frames.at(-1).color, 'rgb(255, 255, 255)');
        assert.equal(
          closingFrame.surface,
          'rgb(41, 41, 41)',
          'close keeps the ordinary surface instead of fading it to black',
        );
        assert.notEqual(
          closingFrame.background,
          'rgba(34, 34, 34, 0.33)',
          'before background transitions away from the fill',
        );
        assert.notEqual(
          closingFrame.background,
          'rgba(0, 0, 0, 0)',
          'before background remains visible mid-transition',
        );
        assert.equal(closingFrame.opacity, 1, 'layer opacity stays constant during close');
        assert.ok(
          closingFrame.fades.some(
            (frames) =>
              frames[0].backgroundColor === 'rgba(34, 34, 34, 0.33)' &&
              frames.at(-1).backgroundColor === 'rgba(0, 0, 0, 0)',
          ),
        );
        await until(
          '!document.querySelector(".as-select-overlay")',
          framework + ' custom closing completes',
        );
        await evaluate(
          `document.querySelector('#demo-select').removeAttribute('style');document.querySelector('#demo-select').removeAttribute('data-motion-speed')`,
        );
        console.log(
          'PASS',
          framework,
          prefix,
          width,
          'native Select, shared interpolated motion, legacy header, container width',
        );
      }
  assert.deepEqual(errors, []);
  console.log(
    'PASS: native Select composition, controlled keyboard actions, disabled/unknown values, actual animation interpolation, release/reduced motion, legacy header and container width, React/Qwik and 1680/320px.',
  );
} finally {
  socket?.close();
  browser.kill('SIGTERM');
  await new Promise((r) => browser.once('exit', r));
  await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
}
