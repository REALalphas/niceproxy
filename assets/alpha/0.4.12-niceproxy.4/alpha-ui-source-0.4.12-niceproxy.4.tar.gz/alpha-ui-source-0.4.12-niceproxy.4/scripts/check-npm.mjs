import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';
import { runNpm } from './lib/npm.mjs';
import { packageNames } from './lib/package-files.mjs';

if (process.argv.length !== 3) throw new Error('Usage: npm run check:npm -- releases/X.Y.Z');
const release = resolve(process.argv[2]);
const manifest = JSON.parse(await readFile(join(release, 'manifest.json'), 'utf8'));
assert.equal(manifest.schema, 1);
assert.match(manifest.version, /^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/);
assert.deepEqual(
  Object.keys(manifest.packages).sort(),
  packageNames.map((n) => `@alpha/${n}`).sort(),
);

// Check every archive before running even a dry publication. No registry writes occur.
const archives = [];
for (const name of packageNames) {
  const expectedName = `@alpha/${name}`;
  const item = manifest.packages[expectedName];
  assert.match(item.file, /^[a-zA-Z0-9._-]+\.tgz$/);
  const archive = join(release, item.file);
  const bytes = await readFile(archive);
  assert.equal(bytes.length, item.size, `${name}: archive size`);
  assert.equal(
    `sha512-${createHash('sha512').update(bytes).digest('base64')}`,
    item.integrity,
    `${name}: archive integrity`,
  );
  const [packed] = JSON.parse(
    await runNpm(['pack', archive, '--dry-run', '--json', '--ignore-scripts']),
  );
  assert.equal(packed.name, expectedName);
  assert.equal(packed.version, manifest.version);
  for (const file of ['README.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md'])
    assert.ok(
      packed.files.some((entry) => entry.path === file),
      `${name}: missing ${file}`,
    );
  archives.push(archive);
}
for (const archive of archives) {
  await runNpm(
    [
      'publish',
      archive,
      '--dry-run',
      '--ignore-scripts',
      '--access',
      'public',
      '--registry',
      'https://registry.npmjs.org/',
      '--tag',
      manifest.version.includes('-') ? 'next' : 'latest',
    ],
    { onOutput: (text) => process.stdout.write(text) },
  );
}
console.log(
  'All four npm publication dry runs passed. Nothing was published; scope permissions and version availability must be checked with your npm account.',
);
