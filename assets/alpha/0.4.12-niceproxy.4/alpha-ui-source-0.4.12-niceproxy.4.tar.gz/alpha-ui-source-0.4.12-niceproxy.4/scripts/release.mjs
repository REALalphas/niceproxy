import { readFile, writeFile, mkdir, cp, rename, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { runNpm } from './lib/npm.mjs';
import { packageNames } from './lib/package-files.mjs';
import { stagePackage, stageReleaseDocumentation } from './lib/package-staging.mjs';
import { createReleaseSource } from './lib/release-source.mjs';

const root = resolve(import.meta.dirname, '..');
const version = process.argv[2] || JSON.parse(await readFile(join(root, 'package.json'))).version;
if (!/^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/.test(version)) throw new Error('Expected version X.Y.Z.');
const destination = join(root, 'releases', version);
if (existsSync(destination))
  throw new Error(`Release ${version} already exists. Choose a new version; archives are immutable.`);
await runNpm(['run', 'verify'], { cwd: root, onOutput: (t) => process.stdout.write(t) });
const staging = join(root, 'releases', `.stage-${randomUUID()}`);
await mkdir(staging, { recursive: true });
const packages = {};
try {
  for (const name of packageNames) {
    const target = join(staging, `package-${name}`);
    const pkg = await stagePackage({ root, name, target, version });
    const packed = JSON.parse(
      await runNpm(['pack', '--json', '--ignore-scripts', '--pack-destination', staging], {
        cwd: target,
      }),
    )[0];
    const bytes = await readFile(join(staging, packed.filename));
    packages[pkg.name] = {
      file: packed.filename,
      integrity: `sha512-${createHash('sha512').update(bytes).digest('base64')}`,
      size: bytes.length,
    };
    await rm(target, { recursive: true }); // verified child of this task's staging directory
  }
  const source = await createReleaseSource({ root, target: staging, version });
  await stageReleaseDocumentation({ root, target: staging, source });
  await cp(join(root, 'scripts/install-release.mjs'), join(staging, 'install.mjs'));
  await mkdir(join(staging, 'lib'));
  await cp(join(root, 'scripts/lib/npm.mjs'), join(staging, 'lib/npm.mjs'));
  await writeFile(
    join(staging, 'manifest.json'),
    JSON.stringify(
      { schema: 1, version, createdAt: new Date().toISOString(), packages, source },
      null,
      2,
    ) + '\n',
  );
  await rename(staging, destination);
  const pointer = join(root, `releases/.latest-${randomUUID()}.json`);
  await writeFile(pointer, JSON.stringify({ version }, null, 2) + '\n');
  await rename(pointer, join(root, 'releases/latest.json'));
  console.log(`Release ${version} ready: ${destination}`);
} catch (error) {
  console.error(`Incomplete build: ${staging}`);
  throw error;
}
