import { readFile } from 'node:fs/promises';
import { components } from '../source/components/index.mjs';
export async function generateDemo(emit) {
  const template = await readFile('source/demo/Demo.tsx.template', 'utf8');
  for (const framework of ['react', 'qwik']) {
    const qwik = framework === 'qwik';
    let header = qwik
      ? `import { component$, useStore, useVisibleTask$, $ } from '@builder.io/qwik';\n`
      : `import { useState } from 'react';\nimport { flushSync } from 'react-dom';\n`;
    header += qwik
      ? `import { transitionView, waitForViewCommit } from '@alpha/core';\n`
      : `import { transitionView } from '@alpha/core';\n`;
    header += `import { ${components.map((c) => c.name).join(', ')}, type NavItem } from '@alpha/${framework}';\n`;
    let code = template
      .replace('@COMPONENT_COUNT@', String(components.length))
      .replace('@EXPORT@', qwik ? 'export const Demo = component$(() =>' : 'export function Demo()')
      .replace('@EXPORT_END@', qwik ? ');' : '')
      .replace(
        '@STATE@',
        qwik
          ? 'const state = useStore<DemoState>({...initial,...readDemoPreferences()}); useVisibleTask$(() => { Object.assign(state, readDemoPreferences()); }, {strategy: "document-ready"});'
          : 'const [state, setState] = useState<DemoState>(() => ({...initial,...readDemoPreferences()}));',
      )
      .replace(
        '@UPDATE@',
        qwik
          ? `const update = $(async (patch: Partial<DemoState>) => {
   saveDemoPreferences(patch);
   if (patch.view && patch.view !== state.view) {
     const root = document.querySelector('.demo')!;
     await transitionView(async () => {
       const committed = waitForViewCommit(root,'data-view',patch.view!);
       Object.assign(state,patch);
       await committed;
     });
   } else Object.assign(state,patch);
 });`
          : `const update = (patch: Partial<DemoState>) => {
   saveDemoPreferences(patch);
   if (patch.view && patch.view !== state.view) return transitionView(() => flushSync(() => setState(s => ({...s,...patch}))));
   setState(s => ({...s,...patch}));
 };`,
      )
      .replace(
        '@CHAT_ATTACHMENT_EVENT@',
        qwik
          ? "onChange$={(_, el) => { const file = el.files?.[0]; if (file) update({notice:'Selected file: '+file.name}); el.value=''; }}"
          : "onChange={event => { const file = event.currentTarget.files?.[0]; if (file) update({notice:'Selected file: '+file.name}); event.currentTarget.value=''; }}",
      )
      .replace(
        '@TAB_KEY_EVENT@',
        qwik
          ? `onKeyDown$={async (event,el) => {
   const offset = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
   if (!offset && event.key !== 'Home' && event.key !== 'End') return;
   event.preventDefault();
   const index = categories.findIndex(item => item.id === category.id);
   const next = event.key === 'Home' ? 0 : event.key === 'End' ? categories.length-1 : (index+offset+categories.length)%categories.length;
   (el.parentElement?.querySelectorAll<HTMLButtonElement>('[role="tab"]')[next])?.focus();
   await update({category:categories[next].id});
 }}`
          : `onKeyDown={event => {
   const offset = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
   if (!offset && event.key !== 'Home' && event.key !== 'End') return;
   event.preventDefault();
   const index = categories.findIndex(item => item.id === category.id);
   const next = event.key === 'Home' ? 0 : event.key === 'End' ? categories.length-1 : (index+offset+categories.length)%categories.length;
   (event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>('[role="tab"]')[next])?.focus();
   update({category:categories[next].id});
 }}`,
      )
      .replace('@FRAMEWORK@', qwik ? 'Qwik' : 'React')
      .replaceAll('@', qwik ? '$' : '');
    const result =
      '// Generated from source/demo/Demo.tsx.template. Run npm run generate; do not edit.\n' +
      header +
      code;
    await emit(`apps/${framework}/src/demo.tsx`, result, 'typescript');
  }
}
