import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createProjectServer } from '../packages/project-server/src/server.mjs';
for (const name of ['react', 'qwik']) {
  const source = resolve('examples/consumers', name);
  const config = JSON.parse(await readFile(resolve(source, 'alpha.project.json')));
  const { server } = await createProjectServer({ ...config, source });
  server.listen(config.port, '127.0.0.1', () =>
    console.log(`${name}: http://127.0.0.1:${config.port}`),
  );
}
