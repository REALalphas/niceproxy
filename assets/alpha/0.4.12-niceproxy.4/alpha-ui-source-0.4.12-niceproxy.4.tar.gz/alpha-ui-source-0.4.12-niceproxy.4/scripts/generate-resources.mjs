import { readFile } from 'node:fs/promises';
import { iconFiles } from '../source/resources/icons.mjs';

export async function generateResources(emit) {
  const icons = (regular) =>
    Object.entries(iconFiles)
      .map(
        ([name, file]) =>
          `${JSON.stringify(name)}: new URL('./icons/${file}${regular ? '-regular' : ''}.svg', import.meta.url).href,`,
      )
      .join('\n');
  await emit(
    'packages/core/src/icons.ts',
    `
// Generated from source/resources/icons.mjs. Run npm run generate; do not edit.
export const icons = {${icons(false)}} as const;
export const iconsRegular = {${icons(true)}} as const;
export type IconName = keyof typeof icons;
`,
    'typescript',
  );

  const tokens = JSON.parse(await readFile('packages/core/src/tokens.json', 'utf8'));
  const declarations = [];
  for (const [group, values] of Object.entries(tokens)) {
    if (group === 'breakpoint') continue;
    for (const [name, value] of Object.entries(values)) {
      const key = name.replace(/[A-Z]/g, (letter) => '-' + letter.toLowerCase());
      declarations.push(`--as-${group.toLowerCase()}-${key}: ${value};`);
    }
  }
  await emit(
    'packages/core/src/tokens.css',
    `
/* Generated from tokens.json. Run npm run generate; do not edit. */
:root, .alpha-ui {${declarations.join('\n')}}
`,
    'css',
  );
}
