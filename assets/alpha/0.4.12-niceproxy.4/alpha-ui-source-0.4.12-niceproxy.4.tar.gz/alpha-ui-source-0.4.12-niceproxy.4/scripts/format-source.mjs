import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { formatComponentModule, formatDemoTemplate } from './lib/template-format.mjs';

const check = process.argv.includes('--check');
async function formatFile(file, formatter) {
  const previous = await readFile(file, 'utf8');
  const formatted = await formatter(previous, file);
  if (previous === formatted) return;
  if (check) throw new Error(`Format ${file}: npm run format`);
  await writeFile(file, formatted);
}

async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const file = join(directory, entry.name);
    if (entry.isDirectory()) await walk(file);
    else if (entry.name.endsWith('.mjs')) await formatFile(file, formatComponentModule);
  }
}

await walk('source/components');
await formatFile('source/demo/Demo.tsx.template', formatDemoTemplate);
console.log(check ? 'Canonical source formatting is current.' : 'Canonical sources formatted.');
