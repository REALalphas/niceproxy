import assert from 'node:assert/strict';
import { cp, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { docsBase, guideFiles, rewriteDocsLinks } from './lib/docs-site.mjs';
import { createReleaseSource } from './lib/release-source.mjs';
import { examples } from '../source/docs/examples.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const content = resolve(root, 'apps/docs/src/content/docs');
const publicDir = resolve(root, 'apps/docs/public');
const base = docsBase(process.env.DOCS_BASE_PATH);
const catalog = JSON.parse(await readFile(resolve(root, 'packages/core/src/catalog.json'), 'utf8'));
const references = new Set(['LICENSE', 'THIRD_PARTY_NOTICES.md']);
const siteLicenses = [];
const referencePath = (file) => (file === 'LICENSE' ? 'LICENSE.txt' : file);
function sourceHref(file) {
  assert(!file.startsWith('../') && !file.startsWith('/'), `Reference escapes repository: ${file}`);
  references.add(file);
  return base + 'reference/' + referencePath(file);
}
async function emit(file, text) {
  const target = resolve(content, file);
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, text);
}
function page(title, body, description) {
  return `---\ntitle: ${JSON.stringify(title)}\ndescription: ${JSON.stringify(description ?? title)}\neditUrl: false\n---\n\n${body}\n`;
}

await rm(content, { recursive: true, force: true });
await rm(publicDir, { recursive: true, force: true });
await mkdir(publicDir, { recursive: true });
await cp(resolve(root, 'packages/core/assets/hub_logo.svg'), resolve(publicDir, 'favicon.svg'));
for (const framework of ['react', 'qwik']) {
  const target = resolve(publicDir, `examples/${framework}`);
  await cp(resolve(root, `apps/${framework}/dist-examples`), target, {
    recursive: true,
  });
  await rename(resolve(target, 'examples.html'), resolve(target, 'index.html'));
}

const source = await createReleaseSource({
  root,
  target: resolve(publicDir, 'downloads'),
  version: catalog.version,
});
await writeFile(
  resolve(publicDir, 'downloads/source.json'),
  JSON.stringify({ schema: 1, version: catalog.version, source }, null, 2) + '\n',
);
const sourceLink = `${base}downloads/${source.file}`;

// Preserve notices for the runtimes shipped in the static site and its live examples.
const docsRequire = createRequire(resolve(root, 'apps/docs/package.json'));
for (const [name, license] of [
  ['astro', 'LICENSE'],
  ['@astrojs/starlight', 'LICENSE'],
  ['react', 'LICENSE'],
  ['react-dom', 'LICENSE'],
  ['@builder.io/qwik', 'LICENSE'],
  ['pagefind', 'LICENSE/LICENSE'],
]) {
  let packageDirectory;
  for (const search of docsRequire.resolve.paths(name)) {
    const candidate = resolve(search, name);
    const manifest = await readFile(resolve(candidate, 'package.json'), 'utf8').catch((error) => {
      if (error.code === 'ENOENT') return undefined;
      throw error;
    });
    if (manifest && JSON.parse(manifest).name === name) {
      packageDirectory = candidate;
      break;
    }
  }
  assert(packageDirectory, `Missing site dependency: ${name}`);
  const file = `reference/site-licenses/${name.replaceAll('/', '-')}.txt`;
  const target = resolve(publicDir, file);
  await mkdir(dirname(target), { recursive: true });
  await cp(resolve(packageDirectory, license), target);
  siteLicenses.push(`[${name}](${base}${file})`);
}

for (const name of guideFiles) {
  const file = `docs/${name}.md`;
  const source = await readFile(resolve(root, file), 'utf8');
  const title = source.match(/^# (.+)$/m)?.[1] ?? name;
  const body = rewriteDocsLinks(source.replace(/^# .+\n+/, ''), file, base, sourceHref);
  await emit(
    `guides/${name}.md`,
    page(title, body + `\n\n[Source document](${sourceHref(file)})`),
  );
}

for (const component of catalog.components) {
  assert(examples[component.name], `Missing example: ${component.name}`);
  const name = component.name;
  const description = examples[name].description;
  const note =
    component.status === 'extension'
      ? '\nThis is a library extension. It is not claimed to be an exact copy of a Figma component.\n'
      : '';
  await emit(
    `components/${name.toLowerCase()}.mdx`,
    page(
      name,
      `import LiveExample from '../../../components/LiveExample.astro';
import PropsReference from '../../../components/PropsReference.astro';

## Live example

<LiveExample name="${name}" />

To run, import the styles and \`installControlMotion()\` — [integration guide](${base}guides/agent-guide/).

## Props

<PropsReference name="${name}" />

## Behavior and constraints

${note}

${examples[name].notes ?? ''}

${component.group === 'chat' ? `Detailed contract and support boundaries are in the [chat guide](${base}guides/chat/).` : component.group === 'controls' ? `States and handlers are in the [${name === 'Button' ? 'buttons' : 'fields and selection'} guide](${base}guides/${name === 'Button' ? 'buttons' : 'forms'}/).` : `Composition and controlled state rules are in the [integration guide](${base}guides/agent-guide/).`}

Examples keep state in the browser. Platform APIs are passed by the application.
`,
      description,
    ),
  );
}

await emit(
  'index.mdx',
  page(
    "Alpha's UI",
    `import ComponentIndex from '../../components/ComponentIndex.astro';
import Overview from '../../components/Overview.astro';

<Overview />

## Components

<ComponentIndex />

## Source and terms

[Release installation](${base}guides/distribution/) · [Terms of use](${base}legal/) · [Source for this build](${sourceLink})
`,
    "Alpha's UI documentation: live React and Qwik examples, component API, and guides.",
  ),
);

const license = await readFile(resolve(root, 'LICENSE'), 'utf8');
const notices = await readFile(resolve(root, 'THIRD_PARTY_NOTICES.md'), 'utf8');
await emit(
  'legal.md',
  page(
    'Terms of use',
    `Source is available under AHCL-1.0. This is a source-available library with usage restrictions.

## Site and example source

[Download corresponding source](${sourceLink}) · [Version, size, and SHA-512](${base}downloads/source.json)

The archive contains library, site, and both demo sources, build scripts, lockfile, and licenses. After unpacking, run \`npm ci\`, then \`npm run verify\`. This is a snapshot of the current site build; the source of an individual package release is in its \`manifest.source\`.

## License

[Download LICENSE](${sourceHref('LICENSE')})

\`\`\`text
${license}
\`\`\`

${rewriteDocsLinks(notices.replace(/^# /, '## '), 'THIRD_PARTY_NOTICES.md', base, sourceHref)}

## Site and example tools

Licenses of included runtimes and tools: ${siteLicenses.join(' · ')}.
`,
  ),
);
await mkdir(resolve(publicDir, 'reference'), { recursive: true });
for (const file of references) {
  const target = resolve(publicDir, 'reference', referencePath(file));
  await mkdir(dirname(target), { recursive: true });
  await cp(resolve(root, file), target);
}
await writeFile(resolve(publicDir, '.nojekyll'), '');
console.log(
  `Prepared ${catalog.components.length} component pages, ${guideFiles.length} guides and both live demos.`,
);
