import assert from 'node:assert/strict';
import { cp, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { docsBase, guideFiles, rewriteDocsLinks } from './lib/docs-site.mjs';
import { createReleaseSource } from './lib/release-source.mjs';
import { examples } from '../source/docs/examples.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const content = resolve(root, 'apps/docs/src/content/docs');
const publicDir = resolve(root, 'apps/docs/public');
const base = docsBase(process.env.DOCS_BASE_PATH);
const catalog = JSON.parse(await readFile(resolve(root, 'packages/core/src/catalog.json'), 'utf8'));
const references = new Set(['LICENSE', 'THIRD_PARTY_NOTICES.md']);
const siteLicenses = [];
const referencePath = (file) => (file === 'LICENSE' ? 'LICENSE.txt' : file);
function sourceHref(file) {
  assert(!file.startsWith('../') && !file.startsWith('/'), `Reference escapes repository: ${file}`);
  references.add(file);
  return base + 'reference/' + referencePath(file);
}
async function emit(file, text) {
  const target = resolve(content, file);
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, text);
}
function page(title, body, description) {
  return `---\ntitle: ${JSON.stringify(title)}\ndescription: ${JSON.stringify(description ?? title)}\neditUrl: false\n---\n\n${body}\n`;
}

await rm(content, { recursive: true, force: true });
await rm(publicDir, { recursive: true, force: true });
await mkdir(publicDir, { recursive: true });
await cp(resolve(root, 'packages/core/assets/hub_logo.svg'), resolve(publicDir, 'favicon.svg'));
for (const framework of ['react', 'qwik']) {
  const target = resolve(publicDir, `examples/${framework}`);
  await cp(resolve(root, `apps/${framework}/dist-examples`), target, {
    recursive: true,
  });
  await rename(resolve(target, 'examples.html'), resolve(target, 'index.html'));
}

const source = await createReleaseSource({
  root,
  target: resolve(publicDir, 'downloads'),
  version: catalog.version,
});
await writeFile(
  resolve(publicDir, 'downloads/source.json'),
  JSON.stringify({ schema: 1, version: catalog.version, source }, null, 2) + '\n',
);
const sourceLink = `${base}downloads/${source.file}`;

// Preserve notices for the runtimes shipped in the static site and its live examples.
const docsRequire = createRequire(resolve(root, 'apps/docs/package.json'));
for (const [name, license] of [
  ['astro', 'LICENSE'],
  ['@astrojs/starlight', 'LICENSE'],
  ['react', 'LICENSE'],
  ['react-dom', 'LICENSE'],
  ['@builder.io/qwik', 'LICENSE'],
  ['pagefind', 'LICENSE/LICENSE'],
]) {
  let packageDirectory;
  for (const search of docsRequire.resolve.paths(name)) {
    const candidate = resolve(search, name);
    const manifest = await readFile(resolve(candidate, 'package.json'), 'utf8').catch((error) => {
      if (error.code === 'ENOENT') return undefined;
      throw error;
    });
    if (manifest && JSON.parse(manifest).name === name) {
      packageDirectory = candidate;
      break;
    }
  }
  assert(packageDirectory, `Missing site dependency: ${name}`);
  const file = `reference/site-licenses/${name.replaceAll('/', '-')}.txt`;
  const target = resolve(publicDir, file);
  await mkdir(dirname(target), { recursive: true });
  await cp(resolve(packageDirectory, license), target);
  siteLicenses.push(`[${name}](${base}${file})`);
}

for (const name of guideFiles) {
  const file = `docs/${name}.md`;
  const source = await readFile(resolve(root, file), 'utf8');
  const title = source.match(/^# (.+)$/m)?.[1] ?? name;
  const body = rewriteDocsLinks(source.replace(/^# .+\n+/, ''), file, base, sourceHref);
  await emit(
    `guides/${name}.md`,
    page(title, body + `\n\n[Исходный документ](${sourceHref(file)})`),
  );
}

for (const component of catalog.components) {
  assert(examples[component.name], `Missing example: ${component.name}`);
  const name = component.name;
  const description = examples[name].description;
  const note =
    component.status === 'extension'
      ? '\nЭто расширение библиотеки. Оно не заявляется точной копией компонента из Figma.\n'
      : '';
  await emit(
    `components/${name.toLowerCase()}.mdx`,
    page(
      name,
      `import LiveExample from '../../../components/LiveExample.astro';
import PropsReference from '../../../components/PropsReference.astro';

## Живой пример

<LiveExample name="${name}" />

Для запуска подключите стили и \`installControlMotion()\` — [подключение библиотеки](${base}guides/agent-guide/).

## Свойства

<PropsReference name="${name}" />

## Поведение и ограничения

${note}

${examples[name].notes ?? ''}

${component.group === 'chat' ? `Подробный контракт и границы поддержки — в [руководстве по чату](${base}guides/chat/).` : component.group === 'controls' ? `Состояния и обработчики — в [руководстве по ${name === 'Button' ? 'кнопкам' : 'полям и выбору'}](${base}guides/${name === 'Button' ? 'buttons' : 'forms'}/).` : `Правила композиции и управляемого состояния — в [руководстве по подключению](${base}guides/agent-guide/).`}

Примеры хранят состояние в браузере. Платформенные API передаёт приложение.
`,
      description,
    ),
  );
}

await emit(
  'index.mdx',
  page(
    "Alpha's UI",
    `import ComponentIndex from '../../components/ComponentIndex.astro';
import Overview from '../../components/Overview.astro';

<Overview />

## Компоненты

<ComponentIndex />

## Исходники и условия

[Установка выпусков](${base}guides/distribution/) · [Условия использования](${base}legal/) · [Исходники этой сборки](${sourceLink})
`,
    "Документация Alpha's UI: живые примеры React и Qwik, API компонентов и руководства.",
  ),
);

const license = await readFile(resolve(root, 'LICENSE'), 'utf8');
const notices = await readFile(resolve(root, 'THIRD_PARTY_NOTICES.md'), 'utf8');
await emit(
  'legal.md',
  page(
    'Условия использования',
    `Исходники доступны под AHCL-1.0. Это source-available библиотека с ограничениями использования.

## Исходники сайта и примеров

[Скачать соответствующие исходники](${sourceLink}) · [Версия, размер и SHA-512](${base}downloads/source.json)

Архив содержит исходники библиотеки, сайта и обоих демо, сборочные скрипты, lock-файл и лицензии. После распаковки выполни \`npm ci\`, затем \`npm run verify\`. Это снимок текущей сборки сайта; исходники отдельного выпуска пакетов находятся в его \`manifest.source\`.

## Лицензия

[Скачать LICENSE](${sourceHref('LICENSE')})

\`\`\`text
${license}
\`\`\`

${rewriteDocsLinks(notices.replace(/^# /, '## '), 'THIRD_PARTY_NOTICES.md', base, sourceHref)}

## Инструменты сайта и примеров

Лицензии включённых сред выполнения и инструментов: ${siteLicenses.join(' · ')}.
`,
  ),
);
await mkdir(resolve(publicDir, 'reference'), { recursive: true });
for (const file of references) {
  const target = resolve(publicDir, 'reference', referencePath(file));
  await mkdir(dirname(target), { recursive: true });
  await cp(resolve(root, file), target);
}
await writeFile(resolve(publicDir, '.nojekyll'), '');
console.log(
  `Prepared ${catalog.components.length} component pages, ${guideFiles.length} guides and both live demos.`,
);
