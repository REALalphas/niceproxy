import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { runNpm } from './lib/npm.mjs';
import { coreDocuments, legalFiles, licenseSources, packageNames } from './lib/package-files.mjs';
import { stagePackage, stageReleaseDocumentation } from './lib/package-staging.mjs';
import { checkDocumentLinks } from './lib/document-links.mjs';
import {
  collectSourceFiles,
  createReleaseSource,
  extractReleaseSource,
} from './lib/release-source.mjs';

const root = resolve(import.meta.dirname, '..');
const scratch = await mkdtemp(join(tmpdir(), 'alpha-package-audit-'));
const version = JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).version;
const manifests = {};
for (const name of packageNames) {
  const pkg = JSON.parse(await readFile(join(root, `packages/${name}/package.json`), 'utf8'));
  manifests[pkg.name] = pkg;
}
const expectedAssets = Object.values(
  JSON.parse(await readFile(join(root, 'source/resources/assets.json'), 'utf8')),
)
  .map((asset) => 'dist/' + asset.file.replace('packages/core/', ''))
  .sort();

async function checkPackage(directory, name, expectedVersion) {
  const pkg = JSON.parse(await readFile(join(directory, 'package.json'), 'utf8'));
  assert.equal(pkg.version, expectedVersion, `${name}: package version`);
  assert.equal(pkg.license, 'SEE LICENSE IN LICENSE', `${name}: custom license metadata`);
  assert.ok(pkg.description?.length, `${name}: missing npm description`);
  assert.equal(pkg.publishConfig?.access, 'public', `${name}: npm access`);
  assert.equal(pkg.publishConfig?.registry, 'https://registry.npmjs.org/', `${name}: npm registry`);
  const [packed] = JSON.parse(
    await runNpm(['pack', '--dry-run', '--json', '--ignore-scripts'], { cwd: directory }),
  );
  const paths = packed.files.map((file) => file.path);
  assert.ok(paths.includes('README.md'), `${name}: missing npm README`);
  const links = await checkDocumentLinks({ root: directory, files: paths, manifests });
  assert.equal(links.issues.length, 0, links.issues.join('\n'));
  for (const file of legalFiles) {
    assert.ok(paths.includes(file), `${name}: missing packed ${file}`);
    assert.deepEqual(
      await readFile(join(directory, file)),
      await readFile(join(root, file)),
      `${name}: stale ${file}`,
    );
  }
  for (const file of paths) {
    assert.doesNotMatch(
      file,
      /(?:sync-conflict-|(?:^|\/)(?:node_modules|output|\.git|\.env[^/]*|\.npmrc|local-assets)(?:\/|$)|\.(?:log|pem|key|p12|pfx)$|(?:Test)?ProfilePicture|(?:bc1f4|9aa53|2625a|2ab5d)\.png)/i,
      `${name}: unwanted file ${file}`,
    );
  }
  function checkExport(value) {
    if (typeof value === 'string')
      assert.ok(paths.includes(value.replace(/^\.\//, '')), `${name}: missing export ${value}`);
    else if (value && typeof value === 'object') Object.values(value).forEach(checkExport);
  }
  checkExport(pkg.exports);
  for (const field of ['dependencies', 'peerDependencies']) {
    for (const [dependency, required] of Object.entries(pkg[field] || {})) {
      if (dependency.startsWith('@alpha/'))
        assert.equal(required, expectedVersion, `${name}: ${dependency} version`);
    }
  }
  if (name === 'core') {
    for (const [file, source] of Object.entries(coreDocuments)) {
      assert.ok(paths.includes(file), `${name}: missing documentation ${file}`);
      assert.deepEqual(
        await readFile(join(directory, file)),
        await readFile(join(root, source)),
        `${name}: stale documentation ${file}`,
      );
    }
    const catalog = JSON.parse(await readFile(join(directory, 'dist/catalog.json'), 'utf8'));
    assert.equal(catalog.schema, 1);
    assert.equal(
      catalog.version,
      expectedVersion,
      'catalog must identify the packaged library version',
    );
    assert.deepEqual(
      paths.filter((file) => file.startsWith('dist/assets/')).sort(),
      expectedAssets,
      'only declared runtime assets belong in core',
    );
    assert.ok(paths.includes('dist/icons/LICENSE'), 'Lucide notice must travel with its icons');
  }
  return paths.length;
}

try {
  for (const [file, upstream] of Object.entries(licenseSources)) {
    assert.deepEqual(
      await readFile(join(root, file)),
      await readFile(join(root, 'node_modules', upstream)),
      `Review updated upstream license: ${upstream}`,
    );
  }
  for (const name of packageNames) {
    const files = await checkPackage(join(root, 'packages', name), name, version);
    const target = join(scratch, name);
    await stagePackage({ root, name, target, version: '0.0.0-package-audit' });
    const stagedFiles = await checkPackage(target, name, '0.0.0-package-audit');
    console.log(
      `@alpha/${name}: ${files} files, ${stagedFiles} staged; licenses, docs, links, exports, versions and assets OK`,
    );
  }
  const releaseDocs = join(scratch, 'release-docs');
  const source = await createReleaseSource({
    root,
    target: releaseDocs,
    version: '0.0.0-package-audit',
  });
  const extracted = join(scratch, 'source');
  const sourceFiles = await extractReleaseSource({
    release: releaseDocs,
    manifest: { version: '0.0.0-package-audit', source },
    target: extracted,
  });
  assert.deepEqual(sourceFiles, await collectSourceFiles(root), 'Complete source file set');
  for (const file of sourceFiles) {
    assert.deepEqual(
      await readFile(join(extracted, file)),
      await readFile(join(root, file)),
      `Source archive differs from workspace: ${file}`,
    );
  }
  console.log(`Source archive: ${sourceFiles.length} files, SHA-512 and exact contents OK.`);
  await stageReleaseDocumentation({ root, target: releaseDocs, source });
  const releaseFiles = [
    'README.md',
    'AGENTS.md',
    ...legalFiles,
    ...new Set(Object.values(coreDocuments)),
    source.file,
  ];
  const releaseLinks = await checkDocumentLinks({
    root: releaseDocs,
    files: releaseFiles,
    manifests,
  });
  assert.equal(releaseLinks.issues.length, 0, releaseLinks.issues.join('\n'));
  console.log('Release documentation links resolve in isolated staging.');
  // Production demos must not contain the private local test avatars either.
  async function checkDemo(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const file = join(directory, entry.name);
      if (entry.isDirectory()) await checkDemo(file);
      else {
        assert.doesNotMatch(entry.name, /ProfilePicture/i, `Local avatar in production: ${file}`);
        if (/\.(?:js|mjs|css|html)$/.test(entry.name)) {
          assert.doesNotMatch(
            await readFile(file, 'utf8'),
            /TestProfilePicture[12]\.png/,
            `Local avatar reference in production: ${file}`,
          );
        }
      }
    }
  }
  for (const name of ['react', 'qwik']) await checkDemo(join(root, 'apps', name, 'dist'));
  console.log('Production demos exclude local test avatars. No release was created.');
} finally {
  await rm(scratch, { recursive: true, force: true });
}
