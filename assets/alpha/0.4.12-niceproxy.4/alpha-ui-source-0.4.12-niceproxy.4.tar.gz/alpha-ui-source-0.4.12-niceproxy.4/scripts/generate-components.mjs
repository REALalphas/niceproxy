import { components, componentSources } from '../source/components/index.mjs';

// Only adapter-specific hooks, event names and syntax are changed here.
export async function generateComponents(emit) {
  for (const framework of ['react', 'qwik']) {
    const qwik = framework === 'qwik';
    let source = `// Generated component. See the canonical source below; run npm run generate.\n`;
    source += qwik
      ? `import { component$, Slot, useSignal, useId, useVisibleTask$, type QRL, type JSXChildren } from '@builder.io/qwik';\n`
      : `import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';\n`;
    source += `import { assets, icons, iconsRegular, cx, clamp, formatTime, formatChatTime, installChatGradient, installChatGrouping, type AssetName, type IconName } from '@alpha/core';\nexport { assets, icons } from '@alpha/core';\n`;
    source += qwik
      ? `type Handler<T extends unknown[]> = QRL<(...args: T) => void>;\ntype Children = JSXChildren;\n`
      : `type Handler<T extends unknown[]> = (...args: T) => void;\ntype Children = ReactNode;\n`;
    source += `export type NavItem = { id: string; label: string; icon?: IconName; notifications?: string | number; group?: string };\ntype CommonProps = { className?: string; id?: string; children?: Children };\n`;
    const header = source;
    source = `// Generated component exports.\nexport { assets, icons } from '@alpha/core';\nexport type NavItem = { id: string; label: string; icon?: import('@alpha/core').IconName; notifications?: string | number; group?: string };\n`;
    for (const component of components) {
      const sourcePath = componentSources[component.name];
      const componentHeader = header.replace(
        '// Generated component. See the canonical source below; run npm run generate.',
        `// Generated from ${sourcePath}. Run npm run generate; do not edit.`,
      );
      const props = component.props.replaceAll('@', qwik ? '$' : '');
      let body = component.body.replace('@CHILDREN@', qwik ? '<Slot />' : '{p.children}');
      body = body.replace(
        '@CHAT_SURFACE_LIFECYCLE@',
        qwik
          ? 'const chatRoot = useSignal<HTMLDivElement>(); useVisibleTask$(({cleanup}) => { if (chatRoot.value) cleanup(installChatGradient(chatRoot.value)); }, {strategy: "document-ready"});'
          : 'const chatRoot = useRef<HTMLDivElement>(null); useEffect(() => { if (chatRoot.current) return installChatGradient(chatRoot.current); }, []);',
      );
      body = body.replace(
        '@CHAT_THREAD_LIFECYCLE@',
        qwik
          ? 'const threadRoot = useSignal<HTMLDivElement>(); useVisibleTask$(({cleanup}) => { if (threadRoot.value) cleanup(installChatGrouping(threadRoot.value)); }, {strategy: "document-ready"});'
          : 'const threadRoot = useRef<HTMLDivElement>(null); useEffect(() => { if (threadRoot.current) return installChatGrouping(threadRoot.current); }, []);',
      );
      body = body.replace(
        '@CHAT_TIME_LIFECYCLE@',
        qwik
          ? 'const chatNow = useSignal(Date.now()); useVisibleTask$(({track,cleanup}) => { const timestamp = track(() => p.timestamp); if (timestamp === undefined) return; chatNow.value = Date.now(); const timer = setInterval(() => { chatNow.value = Date.now(); }, 1000); cleanup(() => clearInterval(timer)); }, {strategy: "document-ready"});'
          : 'const [chatNow, setChatNow] = useState(() => Date.now()); useEffect(() => { if (p.timestamp === undefined) return; setChatNow(Date.now()); const timer = setInterval(() => setChatNow(Date.now()), 1000); return () => clearInterval(timer); }, [p.timestamp]);',
      );
      body = body.replace('@CHAT_NOW@', qwik ? 'chatNow.value' : 'chatNow');
      body = body.replaceAll('for@=', qwik ? 'for=' : 'htmlFor=');
      body = body.replace(
        '@CHECKED_HANDLER@',
        qwik
          ? 'onChange$={(_, el) => p.onCheckedChange$?.(el.checked)}'
          : 'onChange={e => p.onCheckedChange?.(e.currentTarget.checked)}',
      );
      body = body.replace(
        '@SELECT_HANDLER@',
        qwik
          ? 'onChange$={(_, el) => p.onValueChange$?.(el.value)}'
          : 'onChange={e => p.onValueChange?.(e.currentTarget.value)}',
      );
      body = body.replace(
        '@PASSWORD_TOGGLE_HANDLER@',
        qwik
          ? 'onClick$={async (_, el) => { await p.onPasswordVisibleChange$?.(!p.passwordVisible); el.parentElement?.querySelector<HTMLInputElement>("input")?.focus(); }}'
          : 'onClick={e => { p.onPasswordVisibleChange?.(!p.passwordVisible); e.currentTarget.parentElement?.querySelector<HTMLInputElement>("input")?.focus(); }}',
      );
      body = body.replace(
        '@SEARCH_CLEAR_HANDLER@',
        qwik
          ? 'onClick$={async (_, el) => { await p.onValueChange$?.(""); el.parentElement?.querySelector<HTMLInputElement>("input")?.focus(); }}'
          : 'onClick={e => { p.onValueChange?.(""); e.currentTarget.parentElement?.querySelector<HTMLInputElement>("input")?.focus(); }}',
      );
      body = body.replace(
        '@TEXT_INPUT_HANDLER@',
        qwik
          ? 'onInput$={(_, el) => p.onValueChange$?.(el.value)}'
          : 'onChange={e => p.onValueChange?.(e.currentTarget.value)}',
      );
      body = body.replace(
        '@CHAT_INPUT@',
        qwik
          ? 'onInput$={(_, el) => p.onValueChange$?.(el.value)}'
          : 'onChange={e => p.onValueChange?.(e.currentTarget.value)}',
      );
      body = body.replace(
        '@INPUT_HANDLER@',
        qwik
          ? 'onInput$={(_, el) => p.onValueChange$?.(Number(el.value))}'
          : 'onChange={e => p.onValueChange?.(Number(e.currentTarget.value))}',
      );
      body = body.replaceAll('@', qwik ? '$' : '');
      if (!qwik && component.name === 'Icon')
        body = body.replace(/style=\{\{([\s\S]*?)\}\}/, 'style={({$1} as CSSProperties)}');
      if (qwik)
        body = body
          .replaceAll('onClick=', 'onClick$=')
          .replace(/<(svg|path)(\s+)className=/g, '<$1$2class=');
      const dependencies = components
        .filter((other) => other.name !== component.name && body.includes('<' + other.name))
        .map((other) => `import { ${other.name} } from './${other.name}';`)
        .join('\n');
      const definition = qwik
        ? `export const ${component.name} = component$<${component.name}Props>(p => { ${body} });\n`
        : `export function ${component.name}(p: ${component.name}Props) { ${body} }\n`;
      await emit(
        `packages/${framework}/src/components/${component.name}.tsx`,
        componentHeader +
          dependencies +
          `\nexport type ${component.name}Props = CommonProps & { ${props} };\n` +
          definition,
        'typescript',
      );
      source += `export { ${component.name}, type ${component.name}Props } from './components/${component.name}';\n`;
    }
    await emit(`packages/${framework}/src/index.tsx`, source, 'typescript');
  }
}
