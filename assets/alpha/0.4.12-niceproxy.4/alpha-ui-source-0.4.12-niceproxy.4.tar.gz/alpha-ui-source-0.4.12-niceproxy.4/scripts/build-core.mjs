import { cp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { iconFiles } from '../source/resources/icons.mjs';
import { coreDocuments } from './lib/package-files.mjs';
await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
for (const [target, source] of Object.entries(coreDocuments)) await cp(`../../${source}`, target);
await mkdir('dist/assets', { recursive: true });
const assets = JSON.parse(await readFile('../../source/resources/assets.json', 'utf8'));
for (const { file } of Object.values(assets)) {
  if (!/^packages\/core\/assets\/[a-zA-Z0-9._-]+\.svg$/.test(file))
    throw new Error(`Review runtime asset: ${file}`);
  await cp(`../../${file}`, file.replace('packages/core/', 'dist/'));
}
await mkdir('dist/icons', { recursive: true });
for (const name of new Set(Object.values(iconFiles))) {
  const svg = await readFile(`../../node_modules/lucide-static/icons/${name}.svg`, 'utf8');
  await writeFile(`dist/icons/${name}.svg`, svg);
  await writeFile(
    `dist/icons/${name}-regular.svg`,
    svg.replace('stroke-width="2"', 'stroke-width="1.5"'),
  );
}
await cp('../../node_modules/lucide-static/LICENSE', 'dist/icons/LICENSE');
for (const name of ['styles.css', 'tokens.css', 'fonts.css', 'tokens.json', 'catalog.json'])
  await cp(`src/${name}`, `dist/${name}`);
execFileSync(
  process.execPath,
  [
    '../../node_modules/tsc-rs/bin/tsc-rs',
    '--target',
    'ES2022',
    '--module',
    'ESNext',
    '--moduleResolution',
    'bundler',
    '--declaration',
    '--outDir',
    'dist',
    'src/index.ts',
    'src/assets.ts',
    'src/icons.ts',
    'src/motion.ts',
  ],
  { stdio: 'inherit' },
);
