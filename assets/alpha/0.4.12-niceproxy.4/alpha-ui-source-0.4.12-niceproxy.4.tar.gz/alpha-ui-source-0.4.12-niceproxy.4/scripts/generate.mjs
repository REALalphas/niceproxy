import { readFile, readdir } from 'node:fs/promises';
import { components } from '../source/components/index.mjs';
import { legalFiles, packageNames } from './lib/package-files.mjs';
import { generatedFiles } from './lib/generated-files.mjs';
import { generateResources } from './generate-resources.mjs';
import { generateComponents } from './generate-components.mjs';
import { generateDemo } from './generate-demo.mjs';
import { generateExamples } from './generate-examples.mjs';

const check = process.argv.includes('--check');
const emit = generatedFiles({ check });

// Detect orphaned generated files instead of silently compiling old experiments.
const expectedComponents = new Set(components.map(({ name }) => `${name}.tsx`));
for (const framework of ['react', 'qwik']) {
  const directory = `packages/${framework}/src/components`;
  const files = await readdir(directory).catch((error) => {
    if (error.code === 'ENOENT') return [];
    throw error;
  });
  const stale = files.filter((file) => file.endsWith('.tsx') && !expectedComponents.has(file));
  if (stale.length)
    throw new Error(
      `Components absent from the canonical catalog: ${stale.map((file) => `${directory}/${file}`).join(', ')}. Review and archive them before generation.`,
    );
}

for (const file of legalFiles) {
  const content = await readFile(file, 'utf8');
  for (const name of packageNames) await emit(`packages/${name}/${file}`, content);
}

await generateResources(emit);
await generateComponents(emit);
await generateDemo(emit);
await generateExamples(emit);

const { version } = JSON.parse(await readFile('packages/core/package.json', 'utf8'));
await emit(
  'packages/core/src/catalog.json',
  JSON.stringify(
    {
      schema: 1,
      version,
      frameworks: ['react', 'qwik'],
      desktop: ['tauri', 'electron'],
      components: components.map(({ body, ...metadata }) => metadata),
    },
    null,
    2,
  ) + '\n',
);

console.log(
  check
    ? 'Generated files match canonical sources.'
    : `Generated ${components.length} components for React and Qwik.`,
);
