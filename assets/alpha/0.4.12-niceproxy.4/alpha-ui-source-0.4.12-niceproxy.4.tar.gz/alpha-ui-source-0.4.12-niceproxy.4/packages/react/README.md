# @alpha/react

React components for Alpha's UI.

```tsx
import { Button } from '@alpha/react';
```

Import `@alpha/core/fonts.css` and `@alpha/core/styles.css` once in your application.

Install `@alpha/core` and this adapter at the same version; the application supplies React 19 and React DOM 19.

Wrap ordinary components in `.alpha-ui`. In the browser, call `installControlMotion()` from `@alpha/core` once and run its returned cleanup when the application is destroyed. Backend and desktop operations are application handlers.

Read the guides shipped in `@alpha/core`: `AGENTS.md`, `agent-guide.md` and `distribution.md`.

Licensed under AHCL-1.0, a source-available license with conditions on commercial use and Hub integration. Read [LICENSE](./LICENSE) and [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) before use. Corresponding source must accompany distribution or be available for the exact version as required by §4 of LICENSE.
