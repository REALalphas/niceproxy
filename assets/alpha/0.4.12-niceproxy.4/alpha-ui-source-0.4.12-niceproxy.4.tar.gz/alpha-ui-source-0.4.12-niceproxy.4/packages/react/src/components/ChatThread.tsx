// Generated from source/components/chat/ChatThread.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type ChatThreadProps = CommonProps & {
  label?: string;
};
export function ChatThread(p: ChatThreadProps) {
  const threadRoot = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (threadRoot.current) return installChatGrouping(threadRoot.current);
  }, []);
  return (
    <div
      ref={threadRoot}
      className={cx('as-chat-thread', p.className)}
      role="log"
      aria-label={p.label ?? 'Сообщения'}
      aria-live="polite"
      aria-relevant="additions"
    >
      {p.children}
    </div>
  );
}
