// Generated from source/components/navigation/NavButton.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
import { Badge } from './Badge';
export type NavButtonProps = CommonProps & {
  label: string;
  icon?: IconName;
  selected?: boolean;
  notifications?: string | number;
  onPress?: Handler<[]>;
};
export function NavButton(p: NavButtonProps) {
  return (
    <button
      type="button"
      className={cx('as-nav-button', p.className)}
      data-selected={p.selected ? 'true' : 'false'}
      aria-current={p.selected ? 'page' : undefined}
      onClick={p.onPress}
    >
      <span className="as-nav-icon">
        <Icon name={p.icon ?? 'key'} weight={p.selected ? 'bold' : 'regular'} />
        {p.notifications !== undefined && <Badge value={p.notifications} />}
      </span>
      <span className="as-nav-label">{p.label}</span>
    </button>
  );
}
