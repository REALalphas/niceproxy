// Generated from source/components/chat/ChatButton.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
import { IconButton } from './IconButton';
export type ChatButtonProps = CommonProps & {
  variant?: 'plain' | 'emoji' | 'attach' | 'record' | 'send';
  icon?: IconName;
  label?: string;
  pressed?: boolean;
  disabled?: boolean;
  onPress?: Handler<[]>;
};
export function ChatButton(p: ChatButtonProps) {
  const variant = p.variant ?? 'plain';
  const defaults = {
    plain: { icon: 'messageReply', label: 'Ответить' },
    emoji: { icon: 'emoji', label: 'Добавить эмодзи' },
    attach: { icon: 'attachment', label: 'Прикрепить файл' },
    record: { icon: 'microphone', label: 'Записать голосовое сообщение' },
    send: { icon: 'send', label: 'Отправить' },
  } as const;
  return (
    <IconButton
      weight="bold"
      className={cx('as-chat-button as-chat-' + variant, p.className)}
      icon={p.icon ?? defaults[variant].icon}
      label={p.label ?? defaults[variant].label}
      pressed={p.pressed}
      disabled={p.disabled}
      onPress={p.onPress}
    />
  );
}
