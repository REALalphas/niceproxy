// Generated from source/components/chat/ChatSurface.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type ChatSurfaceProps = CommonProps & {};
export function ChatSurface(p: ChatSurfaceProps) {
  const chatRoot = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (chatRoot.current) return installChatGradient(chatRoot.current);
  }, []);
  return (
    <div ref={chatRoot} className={cx('as-chat-surface', p.className)}>
      {p.children}
    </div>
  );
}
