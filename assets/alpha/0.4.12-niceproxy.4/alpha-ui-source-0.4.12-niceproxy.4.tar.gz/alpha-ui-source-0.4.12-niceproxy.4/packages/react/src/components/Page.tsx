// Generated from source/components/layout/Page.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type PageProps = CommonProps & {
  width?: 'form' | 'content' | 'full';
  viewport?: 'content' | 'full';
  align?: 'start' | 'center';
  inset?: 'none' | 'compact' | 'comfortable';
  gap?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
};
export function Page(p: PageProps) {
  return (
    <div
      className={cx('as-page', p.className)}
      id={p.id}
      data-viewport={p.viewport ?? 'content'}
      data-width={p.width ?? 'content'}
      data-align={p.align ?? 'start'}
      data-inset={p.inset ?? 'comfortable'}
      data-gap={p.gap ?? 6}
    >
      {p.children}
    </div>
  );
}
