// Generated from source/components/navigation/HeadBar.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Picker } from './Picker';
import { Icon } from './Icon';
import { Logo } from './Logo';
import { Profile } from './Profile';
export type HeadBarProps = CommonProps & {
  serviceValue?: string;
  serviceOptions?: { value: string; label: string; disabled?: boolean }[];
  serviceLabel?: string;
  serviceDisabled?: boolean;
  context?: {
    label: string;
    value: string;
    options: { value: string; label: string; disabled?: boolean }[];
    placeholder?: string;
    disabled?: boolean;
  };
  onServiceChange?: Handler<[value: string]>;
  onContextChange?: Handler<[value: string]>;
  serviceName: string;
  serviceMode?: 'picker' | 'static';
  showAccount?: boolean;
  accountLabel?: string;
  accountSrc?: string;
  accountState?: 'default' | 'loading' | 'unstable' | 'error';
  balance?: string;
  onServicePress?: Handler<[]>;
  onAccountPress?: Handler<[]>;
};
export function HeadBar(p: HeadBarProps) {
  return (
    <header
      className={cx('as-headbar', p.className)}
      data-has-account={p.showAccount === false ? 'false' : 'true'}
      data-has-context={p.context ? 'true' : 'false'}
    >
      <div className="as-headbar-service">
        {p.serviceMode === 'static' ? (
          <div className="as-service">
            <Logo label="" />
            <span>{p.serviceName}</span>
          </div>
        ) : p.serviceOptions ? (
          <Picker
            label={p.serviceLabel ?? 'Service'}
            value={p.serviceValue ?? p.serviceName}
            options={p.serviceOptions}
            variant="service"
            disabled={p.serviceDisabled}
            onValueChange={p.onServiceChange}
          />
        ) : (
          <button
            type="button"
            className="as-service"
            disabled={p.serviceDisabled}
            onClick={p.onServicePress}
            aria-label={'Switch service: ' + p.serviceName}
          >
            <Logo label="" />
            <span>{p.serviceName}</span>
            <Icon name="chevron" />
          </button>
        )}
      </div>
      {p.context && (
        <div className="as-headbar-context">
          <Picker
            label={p.context.label}
            value={p.context.value}
            options={p.context.options}
            placeholder={p.context.placeholder}
            disabled={p.context.disabled}
            onValueChange={p.onContextChange}
          />
        </div>
      )}
      <div className="as-headbar-actions">
        {p.balance && <span className="as-balance">{p.balance}</span>}
        {p.showAccount !== false && (
          <Profile
            label={p.accountLabel}
            src={p.accountSrc}
            state={p.accountState}
            onPress={p.onAccountPress}
          />
        )}
      </div>
    </header>
  );
}
