// Generated from source/components/layout/Card.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type CardProps = CommonProps & {};
export function Card(p: CardProps) {
  return <section className={cx('as-card', p.className)}> {p.children} </section>;
}
