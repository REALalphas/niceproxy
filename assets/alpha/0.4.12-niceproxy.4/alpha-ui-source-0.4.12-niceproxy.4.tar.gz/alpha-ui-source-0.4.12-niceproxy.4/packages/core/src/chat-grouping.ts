export type ChatGroupItem = { timestamp?: number; author?: string; outgoing?: boolean };
export function getChatGroups(items: ChatGroupItem[]) {
  const joins = (a: ChatGroupItem | undefined, b: ChatGroupItem | undefined) =>
    !!a &&
    !!b &&
    a.author === b.author &&
    !!a.outgoing === !!b.outgoing &&
    Number.isFinite(a.timestamp) &&
    Number.isFinite(b.timestamp) &&
    b.timestamp! >= a.timestamp! &&
    b.timestamp! - a.timestamp! <= 30_000;
  return items.map((item, index) => ({
    start: !joins(items[index - 1], item),
    end: !joins(item, items[index + 1]),
  }));
}

/** Group slotted React/Qwik messages by real timestamps, never by formatted labels. */
export function installChatGrouping(root: HTMLElement): () => void {
  const update = () => {
    const rows = Array.from(root.querySelectorAll<HTMLElement>('.as-chat-message-row')).filter(
      (row) => row.closest('.as-chat-thread') === root,
    );
    const groups = getChatGroups(
      rows.map((row) => ({
        timestamp: row.hasAttribute('data-timestamp') ? Number(row.dataset.timestamp) : undefined,
        author: row.dataset.author,
        outgoing: row.dataset.outgoing === 'true',
      })),
    );
    rows.forEach((row, index) => {
      row.dataset.groupStart = String(groups[index].start);
      row.dataset.groupEnd = String(groups[index].end);
    });
  };
  const observer = new MutationObserver(update);
  observer.observe(root, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['data-timestamp', 'data-author', 'data-outgoing'],
  });
  update();
  return () => observer.disconnect();
}
