export type ScrollPoint = { x: number; y: number; length: number };
export function scrollbarTrack(
  width: number,
  height: number,
  radius: number,
  stroke: number,
  curvature: number,
  reserveCorner = false,
) {
  const inner = radius - stroke,
    exponent = 2 ** curvature;
  const points: ScrollPoint[] = [];
  for (let index = 64; index >= 0; index--) {
    const normalAngle = (index * ((75 * Math.PI) / 180)) / 64;
    const angle = Math.atan(Math.tan(normalAngle) ** (exponent / (2 * (exponent - 1))));
    const x = inner * Math.cos(angle) ** (2 / exponent),
      y = inner * Math.sin(angle) ** (2 / exponent);
    const nx = (x / inner) ** (exponent - 1),
      ny = (y / inner) ** (exponent - 1),
      norm = Math.hypot(nx, ny);
    const point = {
      x: width - radius + x - (1.5 * stroke * nx) / norm,
      y: radius - y + (1.5 * stroke * ny) / norm,
      length: 0,
    };
    const previous = points.at(-1);
    point.length = previous
      ? previous.length + Math.hypot(point.x - previous.x, point.y - previous.y)
      : 0;
    points.push(point);
  }
  const arcLength = points.at(-1)!.length;
  const last = points.at(-1)!;
  const bottom = Math.max(last.y, reserveCorner ? height - radius - 2 * stroke : height - radius);
  points.push({ x: last.x, y: bottom, length: last.length + bottom - last.y });
  if (!reserveCorner)
    for (let index = 0; index <= 64; index++) {
      const normalAngle = (index * ((75 * Math.PI) / 180)) / 64;
      const angle = Math.atan(Math.tan(normalAngle) ** (exponent / (2 * (exponent - 1))));
      const x = inner * Math.cos(angle) ** (2 / exponent),
        y = inner * Math.sin(angle) ** (2 / exponent);
      const nx = (x / inner) ** (exponent - 1),
        ny = (y / inner) ** (exponent - 1),
        norm = Math.hypot(nx, ny);
      const point = {
        x: width - radius + x - (1.5 * stroke * nx) / norm,
        y: height - radius + y - (1.5 * stroke * ny) / norm,
        length: 0,
      };
      const previous = points.at(-1)!;
      point.length = previous.length + Math.hypot(point.x - previous.x, point.y - previous.y);
      points.push(point);
    }
  return {
    points,
    arcLength,
    length: points.at(-1)!.length,
    path: points.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(5)} ${p.y.toFixed(5)}`).join(' '),
  };
}
export function scrollbarThumb(
  length: number,
  minimum: number,
  viewport: number,
  content: number,
  scroll: number,
) {
  const maximum = Math.max(0, content - viewport);
  // Even a field shorter than the corner needs travel for pointer dragging.
  const available = maximum ? length - Math.min(minimum, length) / 4 : length;
  const size = Math.min(available, Math.max(minimum, (length * viewport) / content));
  const start = maximum ? ((length - size) * Math.max(0, Math.min(maximum, scroll))) / maximum : 0;
  return { size, start, maximum };
}
export function closestTrackPosition(points: ScrollPoint[], x: number, y: number): number {
  let distance = Infinity,
    position = 0;
  for (let index = 1; index < points.length; index++) {
    const a = points[index - 1],
      b = points[index],
      dx = b.x - a.x,
      dy = b.y - a.y;
    const ratio = Math.max(
      0,
      Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy || 1)),
    );
    const candidate = Math.hypot(x - a.x - ratio * dx, y - a.y - ratio * dy);
    if (candidate < distance) {
      distance = candidate;
      position = a.length + ratio * (b.length - a.length);
    }
  }
  return position;
}
