/** Compact elapsed time for chat timestamps. */
export function formatChatTime(timestamp: number, now = Date.now()): string {
  if (!Number.isFinite(timestamp) || !Number.isFinite(now)) return '';
  const seconds = Math.max(0, Math.floor((now - timestamp) / 1000));
  if (seconds < 10) return 'now';
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 48 * 3600) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}
