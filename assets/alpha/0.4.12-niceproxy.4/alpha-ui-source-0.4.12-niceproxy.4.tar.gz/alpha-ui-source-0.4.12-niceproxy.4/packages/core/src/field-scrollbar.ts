import { scrollbarTrack, scrollbarThumb, closestTrackPosition } from './scrollbar-geometry.js';

/** Native textarea scrolling with a thumb following the field's inner contour. */
export function installFieldScrollbar(root: Document | HTMLElement): () => void {
  if (typeof root.querySelectorAll !== 'function') return () => {};
  type Model = {
    field: HTMLTextAreaElement;
    bar: HTMLElement;
    width: number;
    height: number;
    track: ReturnType<typeof scrollbarTrack>;
    thumb: ReturnType<typeof scrollbarThumb>;
  };
  const models = new Map<HTMLElement, Model>();
  let frame = 0,
    disposed = false;
  let drag: { bar: HTMLElement; pointer: number; anchor: number } | null = null;
  const doc = root.nodeType === 9 ? (root as Document) : root.ownerDocument!;
  const view = doc.defaultView!;
  const update = (model: Model) => {
    const { field, bar } = model,
      wrapper = field.parentElement!;
    if (!field.clientHeight) {
      bar.hidden = true;
      return;
    }
    const overflow = field.scrollHeight > field.clientHeight + 1;
    bar.toggleAttribute('data-overflow', overflow);
    bar.setAttribute('aria-hidden', String(!overflow));
    bar.tabIndex = overflow ? 0 : -1;
    const css = view.getComputedStyle(wrapper),
      rem = parseFloat(view.getComputedStyle(doc.documentElement).fontSize);
    const radius = parseFloat(css.borderBottomRightRadius);
    const base = parseFloat(css.getPropertyValue('--as-borderwidth-control')) * rem;
    const thick =
      field.matches(':active:not(:disabled), :focus:not([readonly]):not(:disabled)') ||
      bar.hasAttribute('data-scrolling') ||
      !!wrapper.querySelector('.as-field-resize[data-resizing]');
    const stroke = base * (thick ? 2 : 1);
    const width = parseFloat(css.width),
      height = parseFloat(css.height);
    bar.toggleAttribute('data-geometry-change', width !== model.width || height !== model.height);
    model.width = width;
    model.height = height;
    model.track = scrollbarTrack(
      model.width,
      model.height,
      radius,
      stroke,
      CSS.supports('corner-shape', 'superellipse(1.2)') ? 1.2 : 1,
      !!wrapper.querySelector('[data-resize-axis=both]'),
    );
    // Preserve the last visible thumb while it fades; do not expand it into a full track.
    if (overflow)
      model.thumb = scrollbarThumb(
        model.track.length,
        model.track.arcLength,
        field.clientHeight,
        field.scrollHeight,
        field.scrollTop,
      );
    bar.hidden = false;
    const svg = bar.querySelector('svg')!;
    svg.setAttribute('viewBox', `0 0 ${model.width} ${model.height}`);
    for (const path of bar.querySelectorAll('path')) path.setAttribute('d', model.track.path);
    const thumb = bar.querySelector('.as-field-scrollbar-thumb')!;
    // Keep the visible interval relative to the contour while its length morphs.
    // At the bottom, start + size stays exactly 1 throughout the transition.
    thumb.setAttribute('pathLength', '1');
    thumb.setAttribute('stroke-dasharray', `${model.thumb.size / model.track.length} 2`);
    thumb.setAttribute('stroke-dashoffset', String(-model.thumb.start / model.track.length));
    bar.setAttribute('aria-valuemin', '0');
    bar.setAttribute('aria-valuemax', String(Math.round(model.thumb.maximum)));
    bar.setAttribute('aria-valuenow', String(Math.round(field.scrollTop)));
  };
  // ResizeObserver runs before paint: geometry must match the field in that paint.
  const resizeObserver = new ResizeObserver((entries) => {
    for (const model of models.values())
      if (entries.some((entry) => entry.target === model.field)) update(model);
  });
  const scan = () => {
    for (const field of root.querySelectorAll<HTMLTextAreaElement>(
      '.as-field-input-wrap > .as-textarea',
    )) {
      const wrapper = field.parentElement!,
        bar = wrapper.querySelector<HTMLElement>('.as-field-scrollbar');
      if (!bar || models.has(bar)) continue;
      wrapper.setAttribute('data-scrollbar-ready', '');
      models.set(bar, {
        field,
        bar,
        width: 0,
        height: 0,
        track: scrollbarTrack(100, 100, 15, 1.5, 1),
        thumb: scrollbarThumb(1, 1, 1, 1, 0),
      });
      resizeObserver.observe(field);
    }
    for (const [bar, model] of models)
      if (!bar.isConnected) {
        resizeObserver.unobserve(model.field);
        models.delete(bar);
      }
  };
  const schedule = () => {
    if (disposed || frame) return;
    frame = view.requestAnimationFrame(() => {
      frame = 0;
      scan();
      for (const model of models.values()) update(model);
    });
  };
  const observer = new MutationObserver(schedule);
  observer.observe(root, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style', 'class', 'rows', 'value', 'data-resizing'],
  });
  const modelFor = (event: Event) =>
    event.target instanceof Element
      ? models.get(event.target.closest<HTMLElement>('.as-field-scrollbar')!)
      : undefined;
  const position = (model: Model, event: PointerEvent) => {
    const bounds = model.bar.getBoundingClientRect();
    return closestTrackPosition(
      model.track.points,
      ((event.clientX - bounds.left) * model.width) / bounds.width,
      ((event.clientY - bounds.top) * model.height) / bounds.height,
    );
  };
  const scrollTo = (model: Model, start: number) => {
    const travel = model.track.length - model.thumb.size;
    model.field.scrollTop = travel
      ? (Math.max(0, Math.min(travel, start)) * model.thumb.maximum) / travel
      : 0;
    update(model);
  };
  const finish = () => {
    if (!drag) return;
    const { bar, pointer } = drag;
    drag = null;
    bar.removeAttribute('data-scrolling');
    if (bar.hasPointerCapture(pointer)) bar.releasePointerCapture(pointer);
    const model = models.get(bar);
    if (model) update(model);
  };
  const down = (event: Event) => {
    if (!(event instanceof PointerEvent) || event.button !== 0) return;
    const model = modelFor(event);
    if (!model) return;
    event.preventDefault();
    finish();
    model.bar.setAttribute('data-scrolling', '');
    update(model);
    const point = position(model, event);
    const inside = point >= model.thumb.start && point <= model.thumb.start + model.thumb.size;
    drag = {
      bar: model.bar,
      pointer: event.pointerId,
      anchor: inside ? point - model.thumb.start : model.thumb.size / 2,
    };
    if (!inside) scrollTo(model, point - drag.anchor);
    model.bar.setAttribute('data-scrolling', '');
    model.bar.setPointerCapture(event.pointerId);
  };
  const move = (event: Event) => {
    if (!(event instanceof PointerEvent) || !drag || drag.pointer !== event.pointerId) return;
    const model = models.get(drag.bar);
    if (!model) {
      finish();
      return;
    }
    event.preventDefault();
    scrollTo(model, position(model, event) - drag.anchor);
  };
  const up = (event: Event) => {
    if (event instanceof PointerEvent && drag?.pointer === event.pointerId) finish();
    schedule();
  };
  const key = (event: Event) => {
    if (!(event instanceof KeyboardEvent)) return;
    const model = modelFor(event);
    if (!model) return;
    const { field } = model,
      line = parseFloat(view.getComputedStyle(field).lineHeight);
    const steps: Record<string, number> = {
      ArrowUp: -line,
      ArrowDown: line,
      PageUp: -field.clientHeight,
      PageDown: field.clientHeight,
    };
    const delta = steps[event.key];
    if (delta !== undefined) {
      event.preventDefault();
      field.scrollTop += delta;
    } else if (event.key === 'Home' || event.key === 'End') {
      event.preventDefault();
      field.scrollTop = event.key === 'Home' ? 0 : field.scrollHeight;
    } else return;
    update(model);
  };
  const wheel = (event: Event) => {
    if (!(event instanceof WheelEvent)) return;
    const model = modelFor(event);
    if (!model) return;
    const previous = model.field.scrollTop;
    const unit =
      event.deltaMode === 1
        ? parseFloat(view.getComputedStyle(model.field).lineHeight)
        : event.deltaMode === 2
          ? model.field.clientHeight
          : 1;
    model.field.scrollTop += event.deltaY * unit;
    if (previous !== model.field.scrollTop) event.preventDefault();
    update(model);
  };
  const listeners: [string, EventListener][] = [
    ['input', schedule],
    ['scroll', schedule],
    ['focusin', schedule],
    ['focusout', schedule],
    ['pointerdown', down],
    ['pointermove', move],
    ['pointerup', up],
    ['pointercancel', up],
    ['lostpointercapture', up],
    ['keydown', key],
    ['wheel', wheel],
  ];
  for (const [name, listener] of listeners)
    root.addEventListener(name, listener, { capture: true, passive: false });
  schedule();
  void doc.fonts.ready.then(schedule);
  return () => {
    disposed = true;
    finish();
    view.cancelAnimationFrame(frame);
    observer.disconnect();
    resizeObserver.disconnect();
    for (const [name, listener] of listeners) root.removeEventListener(name, listener, true);
    for (const { field, bar } of models.values()) {
      field.parentElement?.removeAttribute('data-scrollbar-ready');
      bar.hidden = true;
    }
    models.clear();
  };
}
