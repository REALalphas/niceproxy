/** One gradient coordinate space shared by all outgoing surfaces in a chat. */
export function installChatGradient(root: HTMLElement): () => void {
  const view = root.ownerDocument.defaultView;
  if (!view) return () => {};
  let frame = 0;
  const observed = new Set<Element>();
  const update = () => {
    frame = 0;
    const bounds = root.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    const rem =
      Number.parseFloat(view.getComputedStyle(root.ownerDocument.documentElement).fontSize) || 16;
    const surfaces = Array.from(
      root.querySelectorAll<HTMLElement>('.as-chat-message[data-outgoing=true], .as-chat-send'),
    );
    for (const element of observed)
      if (!surfaces.includes(element as HTMLElement)) {
        resize.unobserve(element);
        observed.delete(element);
      }
    for (const surface of surfaces) {
      if (!observed.has(surface)) {
        resize.observe(surface);
        observed.add(surface);
      }
      const rect = surface.getBoundingClientRect();
      surface.style.setProperty('--as-chat-gradient-width', `${bounds.width / rem}rem`);
      surface.style.setProperty('--as-chat-gradient-height', `${bounds.height / rem}rem`);
      surface.style.setProperty('--as-chat-gradient-x', `${(bounds.left - rect.left) / rem}rem`);
      surface.style.setProperty('--as-chat-gradient-y', `${(bounds.top - rect.top) / rem}rem`);
    }
  };
  const schedule = () => {
    if (!frame) frame = view.requestAnimationFrame(update);
  };
  const resize = new ResizeObserver(schedule);
  resize.observe(root);
  const mutation = new MutationObserver(schedule);
  mutation.observe(root, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['data-outgoing', 'class'],
  });
  root.addEventListener('scroll', schedule, true);
  update();
  return () => {
    resize.disconnect();
    mutation.disconnect();
    root.removeEventListener('scroll', schedule, true);
    if (frame) view.cancelAnimationFrame(frame);
  };
}
