/** Shared textarea resizing for both adapters; no change to the controlled value. */
export function installFieldResize(root: Document | HTMLElement): () => void {
  type Drag = {
    handle: HTMLElement;
    field: HTMLTextAreaElement;
    pointer: number;
    x: number;
    y: number;
    width: number;
    height: number;
  };
  let drag: Drag | null = null;
  const handleFor = (event: Event) =>
    event.target instanceof Element
      ? event.target.closest<HTMLElement>('.alpha-ui .as-field-resize, .as-shell .as-field-resize')
      : null;
  const fieldFor = (handle: HTMLElement) =>
    handle.parentElement?.querySelector<HTMLTextAreaElement>('.as-textarea');
  const resize = (
    handle: HTMLElement,
    field: HTMLTextAreaElement,
    width: number,
    height: number,
  ) => {
    const view = field.ownerDocument.defaultView!;
    const wrapper = field.parentElement!;
    const css = view.getComputedStyle(wrapper);
    const rem = parseFloat(view.getComputedStyle(field.ownerDocument.documentElement).fontSize);
    const axis = handle.dataset.resizeAxis ?? 'vertical';
    const minHeight = parseFloat(css.minHeight) || 0;
    const maxHeight = parseFloat(css.maxHeight) || Infinity;
    wrapper.style.height = `${Math.max(minHeight, Math.min(maxHeight, height)) / rem}rem`;
    if (axis === 'both') {
      const container = wrapper.parentElement!;
      const containerStyle = view.getComputedStyle(container);
      const available =
        container.clientWidth -
        parseFloat(containerStyle.paddingLeft) -
        parseFloat(containerStyle.paddingRight);
      const min = Math.max(
        parseFloat(css.minWidth) || 0,
        parseFloat(css.paddingLeft) + parseFloat(css.paddingRight) + parseFloat(css.fontSize),
      );
      wrapper.style.width = `${Math.max(min, Math.min(available, width)) / rem}rem`;
    }
    const rect = wrapper.getBoundingClientRect();
    if (axis !== 'both') {
      handle.setAttribute('aria-valuenow', String(Math.round(rect.height)));
      handle.setAttribute('aria-valuetext', `${Math.round((rect.height / rem) * 100) / 100} rem`);
    }
  };
  const finish = () => {
    if (!drag) return;
    const { handle, pointer } = drag;
    drag = null;
    handle.removeAttribute('data-resizing');
    if (handle.hasPointerCapture(pointer)) handle.releasePointerCapture(pointer);
  };
  const down = (event: Event) => {
    if (!(event instanceof PointerEvent) || event.button !== 0) return;
    const handle = handleFor(event);
    const field = handle && fieldFor(handle);
    if (!handle || !field) return;
    finish();
    event.preventDefault();
    handle.focus({ preventScroll: true });
    const rect = field.parentElement!.getBoundingClientRect();
    drag = {
      handle,
      field,
      pointer: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      width: rect.width,
      height: rect.height,
    };
    handle.setAttribute('data-resizing', '');
    handle.setPointerCapture(event.pointerId);
  };
  const move = (event: Event) => {
    if (!(event instanceof PointerEvent) || !drag || event.pointerId !== drag.pointer) return;
    event.preventDefault();
    resize(
      drag.handle,
      drag.field,
      drag.width + event.clientX - drag.x,
      drag.height + event.clientY - drag.y,
    );
  };
  const up = (event: Event) => {
    if (event instanceof PointerEvent && drag?.pointer === event.pointerId) finish();
  };
  const key = (event: Event) => {
    if (!(event instanceof KeyboardEvent)) return;
    const handle = handleFor(event);
    const field = handle && fieldFor(handle);
    if (!handle || !field) return;
    const axis = handle.dataset.resizeAxis ?? 'vertical';
    const horizontal = ['ArrowLeft', 'ArrowRight'].includes(event.key) && axis === 'both';
    const vertical = ['ArrowUp', 'ArrowDown'].includes(event.key);
    if (!horizontal && !vertical) return;
    event.preventDefault();
    const css = field.ownerDocument.defaultView!.getComputedStyle(field);
    const step = parseFloat(css.lineHeight) || parseFloat(css.fontSize);
    const rect = field.parentElement!.getBoundingClientRect();
    const direction = ['ArrowUp', 'ArrowLeft'].includes(event.key) ? -1 : 1;
    resize(
      handle,
      field,
      rect.width + (horizontal ? direction * step : 0),
      rect.height + (vertical ? direction * step : 0),
    );
  };
  const listeners: [string, EventListener][] = [
    ['pointerdown', down],
    ['pointermove', move],
    ['pointerup', up],
    ['pointercancel', up],
    ['lostpointercapture', up],
    ['keydown', key],
  ];
  for (const [name, handler] of listeners) root.addEventListener(name, handler, true);
  return () => {
    finish();
    for (const [name, handler] of listeners) root.removeEventListener(name, handler, true);
  };
}
