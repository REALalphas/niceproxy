export const cx = (...values: (string | false | undefined)[]) => values.filter(Boolean).join(' ');
export const formatTime = (seconds: number) => {
  const safe = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0));
  return `${Math.floor(safe / 60)}:${String(safe % 60).padStart(2, '0')}`;
};
export const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
export type DesktopBridge = {
  minimize(): Promise<void>;
  toggleMaximize(): Promise<void>;
  close(): Promise<void>;
};
export { assets } from './assets.js';
export type { AssetName } from './assets.js';
export { icons, iconsRegular } from './icons.js';
export type { IconName } from './icons.js';
export { transitionView, waitForViewCommit, installControlMotion } from './motion.js';
export type { ViewTransitionHandle, TransitionDocument } from './motion.js';

export { installChatGradient } from './chat-gradient.js';

export { getChatGroups, installChatGrouping } from './chat-grouping.js';

export { formatChatTime } from './chat-time.js';
