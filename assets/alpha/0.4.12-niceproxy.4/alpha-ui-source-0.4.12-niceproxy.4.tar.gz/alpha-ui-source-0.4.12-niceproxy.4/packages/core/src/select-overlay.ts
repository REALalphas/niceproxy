import { installSelectMotion } from './select-motion.js';
let anchorId = 0;
/** A shared overlay for the existing native Select and its controlled events. */
export function installSelectOverlay(root: Document | HTMLElement): () => void {
  const doc = root.nodeType === 9 ? (root as Document) : root.ownerDocument;
  if (!doc?.createElement) return () => {};
  const win = doc.defaultView!;
  const disposeSelectMotion = installSelectMotion(root);
  let active: { select: HTMLSelectElement; panel: HTMLElement; revision: number } | undefined;
  const panels = new Set<HTMLElement>();
  const closingFrames = new Map<HTMLElement, MutationObserver>();
  const directed = new Set<HTMLSelectElement>();
  const values = new Map<HTMLElement, { wrap: HTMLElement }>();
  const anchors = new Map<
    HTMLElement,
    { element: HTMLElement; name: string; previous: string; priority: string }[]
  >();
  let search = '',
    searchedAt = 0;
  const placement = (select: HTMLSelectElement) => {
    const rect = select.getBoundingClientRect();
    const unit = parseFloat(win.getComputedStyle(doc.documentElement).fontSize);
    const gap = parseFloat(win.getComputedStyle(select).getPropertyValue('--as-space-2')) * unit;
    const fullHeight = select.options.length * rect.height;
    const below = win.innerHeight - gap - rect.top,
      above = rect.bottom - gap;
    return fullHeight <= below || (fullHeight > above && below >= above) ? 'down' : 'up';
  };
  const updateDirections = () => {
    for (const select of root.querySelectorAll<HTMLSelectElement>(
      'select.as-field-control[data-popup=overlay]',
    )) {
      directed.add(select);
      if (select !== active?.select && select.getClientRects().length)
        select.dataset.asPlacement = placement(select);
    }
    for (const select of directed) if (!root.contains(select)) directed.delete(select);
  };
  const settled = async (element: HTMLElement, property?: string) => {
    element.getBoundingClientRect();
    await Promise.all(
      element
        .getAnimations({ subtree: true })
        .filter(
          (animation) =>
            !property ||
            (property === 'background'
              ? (animation as CSSTransition).transitionProperty?.startsWith('background')
              : (animation as CSSTransition).transitionProperty === property),
        )
        .map((animation) => animation.finished.catch(() => {})),
    );
  };
  const remove = (panel: HTMLElement) => {
    closingFrames.get(panel)?.disconnect();
    closingFrames.delete(panel);
    const value = values.get(panel);
    if (value) {
      value.wrap.setAttribute('data-as-value-settle', '');
      for (const name of [
        '--as-select-value-offset',
        '--as-select-value-duration',
        '--as-select-value-easing',
      ])
        value.wrap.style.removeProperty(name);
      value.wrap.getBoundingClientRect();
      value.wrap.removeAttribute('data-as-value-settle');
      values.delete(panel);
    }
    for (const anchor of anchors.get(panel) ?? []) {
      if (anchor.element.style.getPropertyValue('anchor-name') !== anchor.name) continue;
      if (anchor.previous)
        anchor.element.style.setProperty('anchor-name', anchor.previous, anchor.priority);
      else anchor.element.style.removeProperty('anchor-name');
    }
    anchors.delete(panel);
    panel.remove();
    panels.delete(panel);
  };
  const moveValue = (panel: HTMLElement, offset: number, instant = false) => {
    const value = values.get(panel);
    if (!value) return;
    if (instant) value.wrap.setAttribute('data-as-value-settle', '');
    const unit = parseFloat(win.getComputedStyle(doc.documentElement).fontSize);
    value.wrap.style.setProperty('--as-select-value-offset', offset / unit + 'rem');
    if (instant) {
      value.wrap.getBoundingClientRect();
      value.wrap.removeAttribute('data-as-value-settle');
    }
  };
  const contentWidth = (row: HTMLElement) => {
    const range = doc.createRange();
    range.selectNodeContents(row.querySelector('.as-select-overlay-text > span') ?? row);
    const css = win.getComputedStyle(row);
    return (
      range.getBoundingClientRect().width +
      parseFloat(css.paddingLeft) +
      parseFloat(css.paddingRight)
    );
  };
  const revealFrom = (list: HTMLElement, selectedIndex: number) => {
    const distance = Math.max(selectedIndex, list.children.length - 1 - selectedIndex, 1);
    for (const [index, row] of [...list.children].entries()) {
      (row as HTMLElement).style.setProperty(
        '--as-select-option-distance',
        String(Math.abs(index - selectedIndex) / distance),
      );
    }
  };
  const close = (restore = false) => {
    if (!active) return;
    const { select, panel } = active;
    active = undefined;
    select.removeAttribute('data-as-overlay-open');
    select.removeAttribute('data-as-pressed');
    select.setAttribute('aria-expanded', 'false');
    panel.inert = true;
    panel.style.pointerEvents = 'none';
    if (restore && !select.disabled) select.focus({ preventScroll: true });
    else if (doc.activeElement === select || panel.contains(doc.activeElement))
      (doc.activeElement as HTMLElement)?.blur();
    const list = panel.querySelector<HTMLElement>('.as-select-overlay-list');
    const selected = list?.children[Math.max(0, select.selectedIndex)] as HTMLElement | undefined;
    if (selected && (selected.matches(':hover') || selected.hasAttribute('data-active')))
      selected.setAttribute('data-closing-active', '');
    const rect = select.getBoundingClientRect();
    const unit = parseFloat(win.getComputedStyle(doc.documentElement).fontSize);
    if (panel.scrollTop && list) {
      const scroll = panel.scrollTop;
      const y = (parseFloat(win.getComputedStyle(list).translate.split(' ')[1]) || 0) - scroll;
      panel.dataset.phase = 'settle';
      panel.style.setProperty('--as-select-list-offset', y / unit + 'rem');
      panel.scrollTop = 0;
      panel.getBoundingClientRect();
    }
    const syncFrame = () => {
      const field = win.getComputedStyle(select);
      for (const token of [
        '--as-field-frame-width',
        '--as-field-frame-color',
        '--as-field-status-color',
      ]) {
        const hover =
          token === '--as-field-frame-color' &&
          select.matches(':hover:not(:disabled):not([data-as-pressed])') &&
          (!select.matches(':focus') || select.hasAttribute('data-as-pointer-focus'));
        panel.style.setProperty(
          token === '--as-field-frame-color' ? '--as-select-source-frame-color' : token,
          field.getPropertyValue(hover ? '--as-field-idle-color' : token),
        );
      }
    };
    const frameObserver = new win.MutationObserver(syncFrame);
    frameObserver.observe(select, {
      attributes: true,
      attributeFilter: ['data-as-pressed', 'data-as-release', 'data-as-pointer-focus', 'disabled'],
    });
    closingFrames.set(panel, frameObserver);
    if (list) revealFrom(list, Math.max(0, select.selectedIndex));
    panel.dataset.phase = 'close';
    syncFrame();
    moveValue(panel, 0);
    if (!anchors.has(panel)) panel.style.top = rect.top / unit + 'rem';
    panel.style.height = rect.height / unit + 'rem';
    const width =
      selected && select.closest('.as-select-compact') ? contentWidth(selected) : rect.width;
    panel.style.setProperty('--as-select-overlay-width', width / unit + 'rem');
    const container = select.closest('.as-select-field')?.parentElement ?? select.parentElement!;
    const containerCSS = win.getComputedStyle(container);
    const gap = parseFloat(win.getComputedStyle(select).getPropertyValue('--as-space-2')) * unit;
    const textWidth = Math.min(
      width,
      container.getBoundingClientRect().width -
        parseFloat(containerCSS.paddingLeft) -
        parseFloat(containerCSS.paddingRight),
      win.innerWidth - 2 * gap,
    );
    panel.style.setProperty('--as-select-option-text-width', textWidth / unit + 'rem');
    if (list)
      panel.style.setProperty(
        '--as-select-list-offset',
        -(selected
          ? selected.getBoundingClientRect().top -
            list.getBoundingClientRect().top +
            (selected.getBoundingClientRect().height - rect.height) / 2
          : 0) /
          unit +
          'rem',
      );
    const selection =
      selected && panel.hasAttribute('data-selection-committed')
        ? settled(selected, 'background').then(() => {
            panel.removeAttribute('data-selection-committed');
          })
        : Promise.resolve();
    void Promise.all([settled(panel), selection])
      .then(() =>
        Promise.all([
          settled(panel),
          settled(select),
          ...[
            ...select.parentElement!.querySelectorAll<HTMLElement>(':scope > .as-select-value'),
          ].map((value) => settled(value)),
        ]),
      )
      .then(() => remove(panel));
  };
  const rows = () =>
    active ? [...active.panel.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')] : [];
  const open = (select: HTMLSelectElement, last = false) => {
    if (select.disabled || ![...select.options].some((option) => !option.disabled)) return;
    close();
    for (const closing of [...panels]) if (closing.inert) remove(closing);
    const panel = doc.createElement('div');
    panel.className = 'alpha-ui as-select-overlay';
    panel.dataset.phase = 'seed';
    panel.id = select.id + '-overlay';
    panel.setAttribute('role', 'listbox');
    panel.setAttribute('popover', 'manual');
    const container = select.closest('.as-select-field')?.parentElement ?? select.parentElement!;
    const containerCSS = win.getComputedStyle(container);
    if (
      typeof panel.showPopover === 'function' &&
      win.CSS.supports('top', 'anchor(top)') &&
      win.CSS.supports('width', 'anchor-size(width)')
    ) {
      const name = '--as-select-anchor-' + ++anchorId;
      const containerName = name + '-container';
      anchors.set(
        panel,
        [select, container].map((element, index) => {
          const binding = {
            element,
            name: index ? containerName : name,
            previous: element.style.getPropertyValue('anchor-name'),
            priority: element.style.getPropertyPriority('anchor-name'),
          };
          element.style.setProperty('anchor-name', binding.name);
          return binding;
        }),
      );
      panel.style.setProperty(
        '--as-select-overlay-max-width',
        `calc(anchor-size(${containerName} width) - ${containerCSS.paddingLeft} - ${containerCSS.paddingRight})`,
      );
      panel.style.setProperty(
        '--as-select-overlay-left',
        `max(var(--as-space-2), calc(anchor(${containerName} left) + ${containerCSS.paddingLeft}))`,
      );
      panel.style.setProperty(
        '--as-select-overlay-right',
        `min(calc(100% - var(--as-space-2)), calc(anchor(${containerName} right) - ${containerCSS.paddingRight}))`,
      );
      panel.style.setProperty('position-anchor', name);
      panel.dataset.anchored = '';
    }
    panel.setAttribute(
      'aria-label',
      select.labels?.[0]?.textContent ?? select.getAttribute('aria-label') ?? '',
    );
    const css = win.getComputedStyle(select),
      rect = select.getBoundingClientRect();
    // The top-layer panel is a sibling of Select, with its own alpha-ui scope.
    // Preserve the control's resolved motion settings across that boundary.
    for (const name of css) {
      if (name.startsWith('--as-motion-') || name === '--as-control-easing')
        panel.style.setProperty(name, css.getPropertyValue(name));
    }
    const unit = parseFloat(win.getComputedStyle(doc.documentElement).fontSize);
    const gap = parseFloat(css.getPropertyValue('--as-space-2')) * unit;
    panel.style.font = css.font;
    panel.style.letterSpacing = css.letterSpacing;
    panel.style.setProperty(
      '--as-select-option-text-padding',
      (parseFloat(css.paddingLeft) + parseFloat(css.paddingRight)) / unit + 'rem',
    );
    panel.style.setProperty('--as-select-option-initial-color', css.color);
    const wrap = select.parentElement!;
    values.set(panel, { wrap });
    wrap.style.setProperty(
      '--as-select-value-duration',
      css.getPropertyValue('--as-motion-duration') || css.getPropertyValue('--as-motion-fast'),
    );
    wrap.style.setProperty(
      '--as-select-value-easing',
      css.getPropertyValue('--as-control-easing') || css.getPropertyValue('--as-motion-transition'),
    );
    moveValue(panel, 0, true);
    panel.style.setProperty('--as-select-overlay-width', rect.width / unit + 'rem');
    if (!anchors.has(panel)) {
      const bounds = container.getBoundingClientRect();
      panel.style.setProperty(
        '--as-select-overlay-max-width',
        (bounds.width -
          parseFloat(containerCSS.paddingLeft) -
          parseFloat(containerCSS.paddingRight)) /
          unit +
          'rem',
      );
    }
    const list = doc.createElement('div');
    list.className = 'as-select-overlay-list';
    panel.append(list);
    for (const [index, option] of [...select.options].entries()) {
      const row = doc.createElement('button');
      row.type = 'button';
      row.className = 'as-select-overlay-option';
      row.setAttribute('role', 'option');
      row.setAttribute('aria-selected', String(option.selected));
      row.dataset.index = String(index);
      row.disabled = option.disabled;
      row.tabIndex = -1;
      const text = doc.createElement('span'),
        label = doc.createElement('span');
      text.className = 'as-select-overlay-text';
      label.textContent = option.label;
      text.append(label);
      row.append(text);
      row.style.font = css.font;
      row.style.letterSpacing = css.letterSpacing;
      row.style.height = rect.height / unit + 'rem';
      row.style.paddingInlineStart = css.paddingLeft;
      row.style.paddingInlineEnd = css.paddingRight;
      if (option.selected) {
        row.setAttribute('data-value-row', '');
      }
      list.append(row);
    }
    revealFrom(list, Math.max(0, select.selectedIndex));
    const arrow = wrap.querySelector<HTMLElement>(':scope > .as-icon');
    if (arrow) {
      const glyph = arrow.cloneNode(true) as HTMLElement,
        icon = win.getComputedStyle(arrow);
      glyph.classList.add('as-select-overlay-arrow');
      glyph.style.width = parseFloat(icon.width) / unit + 'rem';
      glyph.style.height = parseFloat(icon.height) / unit + 'rem';
      glyph.style.color = icon.color;
      panel.style.setProperty('--as-select-arrow-inset', parseFloat(icon.right) / unit + 'rem');
      panel.style.setProperty('--as-select-arrow-top', (rect.top + rect.height / 2) / unit + 'rem');
      panel.append(glyph);
    }
    select.parentElement!.append(panel);
    panels.add(panel);
    if (typeof panel.showPopover === 'function') panel.showPopover();
    const bounds = container.getBoundingClientRect();
    const maxWidth = Math.min(
      bounds.width - parseFloat(containerCSS.paddingLeft) - parseFloat(containerCSS.paddingRight),
      win.innerWidth - 2 * gap,
    );
    const width = Math.min(
      maxWidth,
      Math.max(rect.width, ...[...list.children].map((row) => contentWidth(row as HTMLElement))),
    );
    panel.style.setProperty('--as-select-option-text-width', width / unit + 'rem');
    const selected = list.children[Math.max(0, select.selectedIndex)] as HTMLElement;
    const offset = selected
      ? selected.getBoundingClientRect().top - list.getBoundingClientRect().top
      : 0;
    const fullHeight = [...list.children].reduce(
      (sum, row) => sum + row.getBoundingClientRect().height,
      0,
    );
    const below = win.innerHeight - gap - rect.top;
    const above = rect.bottom - gap;
    const down = fullHeight <= below || (fullHeight > above && below >= above);
    const height = Math.min(fullHeight, Math.max(rect.height, down ? below : above));
    const top = Math.max(gap, down ? rect.top : rect.bottom - height);
    const scrollTop = height < fullHeight ? Math.max(0, offset + rect.height - height) : 0;
    panel.dataset.placement = down ? 'down' : 'up';
    select.dataset.asPlacement = panel.dataset.placement;
    directed.add(select);
    panel.style.height = rect.height / unit + 'rem';
    if (!anchors.has(panel)) {
      panel.style.top = rect.top / unit + 'rem';
      const initialWidth = panel.getBoundingClientRect().width;
      const initialLeft = Math.max(gap, Math.min(rect.left, win.innerWidth - initialWidth - gap));
      panel.style.left = initialLeft / unit + 'rem';
      panel.style.setProperty('--as-select-overlay-position-left', initialLeft / unit + 'rem');
    }
    panel.style.setProperty('--as-select-list-offset', -offset / unit + 'rem');
    active = { select, panel, revision: 0 };
    select.setAttribute('data-as-overlay-open', '');
    select.setAttribute('aria-haspopup', 'listbox');
    select.setAttribute('aria-controls', panel.id);
    select.setAttribute('aria-expanded', 'true');
    const choices = rows();
    (last ? choices.at(-1) : selected?.matches(':disabled') ? choices[0] : selected)?.focus({
      preventScroll: true,
    });
    const state = active;
    const opening = async () => {
      // Establish the pressed contour before CSS transitions it to the idle tokens.
      win.getComputedStyle(panel, '::after').boxShadow;
      panel.dataset.phase = 'expand';
      if (!anchors.has(panel)) panel.style.top = top / unit + 'rem';
      panel.style.height = height / unit + 'rem';
      panel.style.setProperty('--as-select-overlay-width', width / unit + 'rem');
      panel.style.setProperty('--as-select-list-offset', -scrollTop / unit + 'rem');
      moveValue(panel, (down ? 0 : rect.height - height) + offset - scrollTop);
      await settled(panel);
      if (active !== state || state.revision) return;
      panel.dataset.phase = 'open';
      panel.style.setProperty('--as-select-list-offset', '0rem');
      panel.scrollTop = scrollTop;
    };
    void opening();
    search = '';
  };
  const choose = (row: HTMLButtonElement, keyboard: boolean) => {
    if (!active || row.disabled) return;
    const state = active;
    ++state.revision;
    state.panel.setAttribute('data-selection-changed', '');
    state.panel.setAttribute('data-selection-committed', '');
    for (const option of state.panel.querySelectorAll<HTMLElement>('[role=option]')) {
      option.setAttribute('aria-selected', String(option === row));
      option.removeAttribute('data-closing-active');
      option.removeAttribute('data-value-row');
    }
    row.setAttribute('data-closing-active', '');
    const select = state.select;
    const selectedTop =
      row.getBoundingClientRect().top +
      row.getBoundingClientRect().height / 2 -
      select.getBoundingClientRect().top -
      select.getBoundingClientRect().height / 2;
    moveValue(state.panel, selectedTop, true);
    row.setAttribute('data-value-row', '');
    select.selectedIndex = Number(row.dataset.index);
    close(keyboard);
    select.dispatchEvent(new Event('input', { bubbles: true }));
    select.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const pointer = (event: PointerEvent) => {
    if (event.button !== 0) return;
    const target = event.target as Element;
    const select = target.closest<HTMLSelectElement>('select[data-popup=overlay]');
    if (select && root.contains(select)) {
      if (select.disabled) return;
      select.dataset.asPlacement = placement(select);
      event.preventDefault();
    } else if (active && !active.panel.contains(target)) close();
  };
  const click = (event: MouseEvent) => {
    if (event.button !== 0) return;
    const target = event.target as Element;
    const select = target.closest<HTMLSelectElement>('select[data-popup=overlay]');
    if (select && root.contains(select)) {
      event.preventDefault();
      if (select.disabled) return;
      if (active?.select === select) close();
      else open(select);
      return;
    }
    const row = target.closest<HTMLButtonElement>('.as-select-overlay-option');
    if (row && active?.panel.contains(row)) choose(row, false);
  };
  const mark = (row?: HTMLButtonElement) => {
    for (const option of rows()) option.removeAttribute('data-active');
    row?.setAttribute('data-active', '');
  };
  const pointerMove = (event: PointerEvent) => {
    if (active?.panel.contains(event.target as Node)) {
      mark();
    }
  };
  const key = (event: KeyboardEvent) => {
    const target = event.target as Element;
    if (active?.panel.contains(target)) {
      const options = rows(),
        index = options.indexOf(doc.activeElement as HTMLButtonElement);
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
        event.preventDefault();
        const next =
          event.key === 'Home'
            ? 0
            : event.key === 'End'
              ? options.length - 1
              : (index + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length;
        const row = options[next];
        mark(row);
        row?.focus({ preventScroll: true });
        if (row && active.panel.dataset.phase === 'open') {
          if (row.offsetTop < active.panel.scrollTop) active.panel.scrollTop = row.offsetTop;
          else if (
            row.offsetTop + row.offsetHeight >
            active.panel.scrollTop + active.panel.clientHeight
          )
            active.panel.scrollTop = row.offsetTop + row.offsetHeight - active.panel.clientHeight;
        }
      } else if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        if (index >= 0) choose(options[index], true);
      } else if (event.key === 'Escape') {
        event.preventDefault();
        close(true);
      } else if (event.key === 'Tab') close(true);
      else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
        search =
          (performance.now() - searchedAt > 700 ? '' : search) + event.key.toLocaleLowerCase();
        searchedAt = performance.now();
        const row = options.find((row) => row.textContent?.toLocaleLowerCase().startsWith(search));
        mark(row);
        row?.focus({ preventScroll: true });
      }
    } else {
      const select = target.closest<HTMLSelectElement>('select[data-popup=overlay]');
      if (select && ['Enter', ' ', 'ArrowDown', 'ArrowUp'].includes(event.key)) {
        event.preventDefault();
        open(select, event.key === 'ArrowUp');
      }
    }
  };
  const focus = (event: FocusEvent) => {
    if (active && !active.panel.contains(event.target as Node) && event.target !== active.select)
      close();
  };
  const scroll = (event: Event) => {
    updateDirections();
    if (active?.panel.contains(event.target as Node)) {
      const row = active.panel.querySelector<HTMLElement>('[data-value-row]');
      if (row)
        moveValue(
          active.panel,
          row.getBoundingClientRect().top +
            row.getBoundingClientRect().height / 2 -
            active.select.getBoundingClientRect().top -
            active.select.getBoundingClientRect().height / 2,
          true,
        );
      return;
    }
    // CSS anchors follow all ancestor scrollers, including during collapse.
    // Older browsers retain the existing close-on-scroll fallback.
    if (active && !anchors.has(active.panel) && !active.panel.contains(event.target as Node))
      close();
  };
  const resize = () => {
    close();
    updateDirections();
  };
  const directionObserver = new win.MutationObserver(updateDirections);
  directionObserver.observe(root, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['disabled', 'data-popup', 'hidden', 'data-view', 'class'],
  });
  updateDirections();
  root.addEventListener('pointerdown', pointer as EventListener, true);
  root.addEventListener('pointermove', pointerMove as EventListener, true);
  root.addEventListener('click', click as EventListener, true);
  root.addEventListener('keydown', key as EventListener, true);
  doc.addEventListener('focusin', focus, true);
  doc.addEventListener('scroll', scroll, true);
  win.addEventListener('resize', resize);
  return () => {
    directionObserver.disconnect();
    for (const select of directed) select.removeAttribute('data-as-placement');
    disposeSelectMotion();
    root.removeEventListener('pointerdown', pointer as EventListener, true);
    root.removeEventListener('pointermove', pointerMove as EventListener, true);
    root.removeEventListener('click', click as EventListener, true);
    root.removeEventListener('keydown', key as EventListener, true);
    doc.removeEventListener('focusin', focus, true);
    doc.removeEventListener('scroll', scroll, true);
    win.removeEventListener('resize', resize);
    if (active) {
      active.select.removeAttribute('data-as-overlay-open');
      active.select.setAttribute('aria-expanded', 'false');
    }
    active = undefined;
    for (const panel of panels) remove(panel);
  };
}
