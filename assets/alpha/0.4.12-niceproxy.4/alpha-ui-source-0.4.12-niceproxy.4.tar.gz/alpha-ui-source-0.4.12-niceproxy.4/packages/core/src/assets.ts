export const assets = {
  logo: new URL('./assets/hub_logo.svg', import.meta.url).href,
} as const;
export type AssetName = keyof typeof assets;
