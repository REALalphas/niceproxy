// Generated from source/components/chat/ChatThread.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type ChatThreadProps = CommonProps & {
  label?: string;
};
export const ChatThread = component$<ChatThreadProps>((p) => {
  const threadRoot = useSignal<HTMLDivElement>();
  useVisibleTask$(
    ({ cleanup }) => {
      if (threadRoot.value) cleanup(installChatGrouping(threadRoot.value));
    },
    { strategy: 'document-ready' },
  );
  return (
    <div
      ref={threadRoot}
      className={cx('as-chat-thread', p.className)}
      role="log"
      aria-label={p.label ?? 'Messages'}
      aria-live="polite"
      aria-relevant="additions"
    >
      <Slot />
    </div>
  );
});
