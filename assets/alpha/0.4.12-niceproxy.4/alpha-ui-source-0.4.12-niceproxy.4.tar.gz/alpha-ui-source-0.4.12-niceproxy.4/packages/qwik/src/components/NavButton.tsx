// Generated from source/components/navigation/NavButton.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
import { Badge } from './Badge';
export type NavButtonProps = CommonProps & {
  label: string;
  icon?: IconName;
  selected?: boolean;
  notifications?: string | number;
  onPress$?: Handler<[]>;
};
export const NavButton = component$<NavButtonProps>((p) => {
  return (
    <button
      type="button"
      className={cx('as-nav-button', p.className)}
      data-selected={p.selected ? 'true' : 'false'}
      aria-current={p.selected ? 'page' : undefined}
      onClick$={p.onPress$}
    >
      <span className="as-nav-icon">
        <Icon name={p.icon ?? 'key'} weight={p.selected ? 'bold' : 'regular'} />
        {p.notifications !== undefined && <Badge value={p.notifications} />}
      </span>
      <span className="as-nav-label">{p.label}</span>
    </button>
  );
});
