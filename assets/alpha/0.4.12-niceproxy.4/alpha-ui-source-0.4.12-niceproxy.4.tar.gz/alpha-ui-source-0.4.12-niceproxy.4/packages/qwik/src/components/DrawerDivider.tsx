// Generated from source/components/navigation/DrawerDivider.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type DrawerDividerProps = CommonProps & {
  label?: string;
};
export const DrawerDivider = component$<DrawerDividerProps>((p) => {
  return (
    <div className={cx('as-drawer-divider', p.className)}>
      <hr />
      {p.label && <span>{p.label}</span>}
    </div>
  );
});
