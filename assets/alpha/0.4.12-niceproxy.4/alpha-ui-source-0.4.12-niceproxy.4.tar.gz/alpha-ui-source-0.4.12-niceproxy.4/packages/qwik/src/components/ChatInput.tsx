// Generated from source/components/chat/ChatInput.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { ChatButton } from './ChatButton';
export type ChatInputProps = CommonProps & {
  value: string;
  disabled?: boolean;
  placeholder?: string;
  onValueChange$?: Handler<[string]>;
  onEmoji$?: Handler<[]>;
};
export const ChatInput = component$<ChatInputProps>((p) => {
  return (
    <div className={cx('as-chat-input-surface', p.className)}>
      {p.onEmoji$ && <ChatButton variant="emoji" disabled={p.disabled} onPress$={p.onEmoji$} />}
      <textarea
        className="as-chat-input"
        aria-label="Сообщение"
        placeholder={p.placeholder ?? 'Напиши сообщение…'}
        rows={1}
        value={p.value}
        disabled={p.disabled}
        onInput$={(_, el) => p.onValueChange$?.(el.value)}
      />
      <div className="as-chat-input-actions">
        <Slot />
      </div>
    </div>
  );
});
