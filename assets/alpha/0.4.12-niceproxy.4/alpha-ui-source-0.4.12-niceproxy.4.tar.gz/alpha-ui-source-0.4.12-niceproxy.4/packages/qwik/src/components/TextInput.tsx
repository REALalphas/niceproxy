// Generated from source/components/controls/TextInput.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
export type TextInputProps = CommonProps & {
  id: string;
  label: string;
  labelPlacement?: 'inside' | 'above';
  icon?: IconName;
  showIcon?: boolean;
  value: string;
  name?: string;
  placeholder?: string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  hint?: string;
  error?: string;
  onValueChange$?: Handler<[value: string]>;
  type?: 'text' | 'url' | 'email' | 'password' | 'search' | 'tel';
  autoComplete?: string;
  passwordVisible?: boolean;
  onPasswordVisibleChange$?: Handler<[visible: boolean]>;
};
export const TextInput = component$<TextInputProps>((p) => {
  const fieldIcon =
    p.icon ??
    (
      {
        text: 'type',
        url: 'link',
        email: 'mail',
        password: 'key',
        search: 'search',
        tel: 'phone',
      } as const
    )[p.type ?? 'text'];
  const hasMarker = p.showIcon ?? (!!p.readOnly || !!p.disabled || (p.type ?? 'text') !== 'text');
  const labelAbove =
    p.labelPlacement === 'above' || (p.labelPlacement !== 'inside' && !!(p.readOnly || p.disabled));
  return (
    <div
      className={cx('as-field as-placeholder-field', p.className)}
      data-disabled={p.disabled ? 'true' : 'false'}
      data-error={p.error ? 'true' : 'false'}
      data-label-placement={labelAbove ? 'above' : 'inside'}
    >
      {labelAbove && (
        <label className="as-field-label" for={p.id}>
          {p.label}
        </label>
      )}
      <span
        className="as-field-input-wrap"
        data-has-value={p.value.length ? 'true' : 'false'}
        data-has-marker={hasMarker ? 'true' : 'false'}
        data-multiline="false"
        tabIndex={p.disabled ? 0 : undefined}
        role={p.disabled ? 'button' : undefined}
        aria-label={p.disabled ? 'Редактирование недоступно: ' + p.label : undefined}
      >
        <input
          className="as-field-control"
          id={p.id}
          name={p.name}
          value={p.value}
          disabled={p.disabled}
          required={p.required}
          aria-label={labelAbove ? undefined : p.label}
          aria-invalid={!!p.error || undefined}
          aria-describedby={p.error || p.hint ? p.id + '-description' : undefined}
          type={p.type === 'password' && p.passwordVisible ? 'text' : (p.type ?? 'text')}
          placeholder={labelAbove ? p.placeholder : undefined}
          readOnly={p.readOnly}
          autoComplete={p.autoComplete}
          onInput$={(_, el) => p.onValueChange$?.(el.value)}
        />
        {!labelAbove && (
          <span className="as-field-placeholder" aria-hidden="true">
            <span className="as-field-placeholder-text">{p.placeholder ?? p.label}</span>
          </span>
        )}
        {hasMarker &&
          (p.readOnly || p.disabled ? (
            <span className="as-field-readonly-marker" aria-hidden="true">
              <Icon name="pencilOff" weight="bold" />
            </span>
          ) : p.type === 'password' ? (
            <button
              type="button"
              className="as-field-type-marker as-field-password-action"
              aria-label={p.passwordVisible ? 'Скрыть пароль' : 'Показать пароль'}
              aria-pressed={!!p.passwordVisible}
              data-password-visible={p.passwordVisible ? 'true' : 'false'}
              disabled={!p.value.length}
              onClick$={async (_, el) => {
                await p.onPasswordVisibleChange$?.(!p.passwordVisible);
                el.parentElement?.querySelector<HTMLInputElement>('input')?.focus();
              }}
            >
              <span className="as-field-action-glyphs" aria-hidden="true">
                <Icon name="key" weight="bold" />
                <span className="as-field-password-toggle-glyphs">
                  <Icon name="eye" weight="bold" />
                  <Icon name="eyeOff" weight="bold" />
                </span>
              </span>
            </button>
          ) : p.type === 'search' ? (
            <button
              type="button"
              className="as-field-type-marker as-field-search-action"
              data-field-icon={fieldIcon}
              aria-label="Очистить поиск"
              disabled={!p.value.length}
              onClick$={async (_, el) => {
                await p.onValueChange$?.('');
                el.parentElement?.querySelector<HTMLInputElement>('input')?.focus();
              }}
            >
              <span className="as-field-action-glyphs as-field-search-glyphs" aria-hidden="true">
                <Icon name={fieldIcon} weight="bold" />
                <span className="as-field-search-cross">
                  <Icon name="close" weight="bold" />
                </span>
              </span>
            </button>
          ) : (
            <span className="as-field-type-marker" data-field-icon={fieldIcon} aria-hidden="true">
              <Icon name={fieldIcon} weight="bold" />
            </span>
          ))}
      </span>
      {(p.error || p.hint) && (
        <span id={p.id + '-description'} className="as-field-description">
          {p.error || p.hint}
        </span>
      )}
    </div>
  );
});
