// Generated from source/components/foundation/Badge.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type BadgeProps = CommonProps & {
  value: string | number;
};
export const Badge = component$<BadgeProps>((p) => {
  return (
    <span className={cx('as-badge', p.className)} aria-label={String(p.value) + ' notifications'}>
      <span className="as-badge-label" data-overflow={String(p.value) === '99+' || undefined}>
        {p.value}
      </span>
    </span>
  );
});
