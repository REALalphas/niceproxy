// Generated from source/components/layout/Page.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type PageProps = CommonProps & {
  width?: 'form' | 'content' | 'full';
  viewport?: 'content' | 'full';
  align?: 'start' | 'center';
  inset?: 'none' | 'compact' | 'comfortable';
  gap?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
};
export const Page = component$<PageProps>((p) => {
  return (
    <div
      className={cx('as-page', p.className)}
      id={p.id}
      data-viewport={p.viewport ?? 'content'}
      data-width={p.width ?? 'content'}
      data-align={p.align ?? 'start'}
      data-inset={p.inset ?? 'comfortable'}
      data-gap={p.gap ?? 6}
    >
      <Slot />
    </div>
  );
});
