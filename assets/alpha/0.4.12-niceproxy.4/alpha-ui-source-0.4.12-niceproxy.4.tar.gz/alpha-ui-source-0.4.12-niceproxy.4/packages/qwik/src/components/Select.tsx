// Generated from source/components/controls/Select.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
import { Logo } from './Logo';
export type SelectProps = CommonProps & {
  id: string;
  label: string;
  value: string;
  name?: string;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  hint?: string;
  error?: string;
  variant?: 'field' | 'plain' | 'service';
  popup?: 'native' | 'overlay';
  onValueChange$?: Handler<[value: string]>;
  options: { value: string; label: string; disabled?: boolean }[];
};
export const Select = component$<SelectProps>((p) => {
  const compact = p.variant === 'plain' || p.variant === 'service';
  const selected = p.options.find((option) => option.value === p.value);
  return (
    <div
      className={cx('as-field as-select-field', compact && 'as-select-compact', p.className)}
      data-select-variant={p.variant ?? 'field'}
      data-disabled={p.disabled ? 'true' : 'false'}
      data-error={p.error ? 'true' : 'false'}
    >
      <label className={compact ? 'as-sr-only' : 'as-field-label'} for={p.id}>
        {p.label}
      </label>
      <span className="as-select-wrap">
        <select
          className="as-field-control as-select"
          data-popup={p.popup ?? 'native'}
          id={p.id}
          name={p.name}
          value={p.value}
          disabled={p.disabled}
          required={p.required}
          title={compact ? (selected?.label ?? p.placeholder) : undefined}
          aria-invalid={!!p.error || undefined}
          aria-describedby={p.error || p.hint ? p.id + '-description' : undefined}
          onChange$={(_, el) => p.onValueChange$?.(el.value)}
        >
          {p.placeholder !== undefined && (
            <option value="" disabled>
              {p.placeholder}
            </option>
          )}
          {p.options.map((option) => (
            <option key={option.value} value={option.value} disabled={option.disabled}>
              {option.label}
            </option>
          ))}
        </select>
        {p.popup === 'overlay' && (
          <span className="as-select-value" aria-hidden="true">
            <span>{selected?.label ?? p.placeholder ?? p.options[0]?.label ?? ''}</span>
          </span>
        )}
        {compact && (
          <span className="as-select-size" aria-hidden="true">
            {selected?.label ?? p.placeholder ?? 'Не выбрано'}
          </span>
        )}
        {p.variant === 'service' && <Logo label="" />}
        {p.popup === 'overlay' ? (
          <span
            className="as-icon as-select-chevron"
            data-icon-weight={compact ? 'bold' : 'regular'}
            aria-hidden="true"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M6 9 L12 15 L18 9" />
            </svg>
          </span>
        ) : (
          <Icon name="chevron" weight={compact ? 'bold' : 'regular'} />
        )}
      </span>
      {(p.error || p.hint) && (
        <span id={p.id + '-description'} className="as-field-description">
          {p.error || p.hint}
        </span>
      )}
    </div>
  );
});
