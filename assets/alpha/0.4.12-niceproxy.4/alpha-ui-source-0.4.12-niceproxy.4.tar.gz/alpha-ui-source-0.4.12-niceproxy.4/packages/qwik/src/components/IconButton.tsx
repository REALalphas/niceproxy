// Generated from source/components/controls/IconButton.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
export type IconButtonProps = CommonProps & {
  icon: IconName;
  label: string;
  weight?: 'regular' | 'bold';
  pressed?: boolean;
  disabled?: boolean;
  onPress$?: Handler<[]>;
};
export const IconButton = component$<IconButtonProps>((p) => {
  return (
    <button
      type="button"
      className={cx('as-button as-icon-button', p.className)}
      data-variant="simple"
      aria-label={p.label}
      aria-pressed={p.pressed}
      disabled={p.disabled}
      onClick$={p.onPress$}
    >
      <Icon name={p.icon} weight={p.weight} />
    </button>
  );
});
