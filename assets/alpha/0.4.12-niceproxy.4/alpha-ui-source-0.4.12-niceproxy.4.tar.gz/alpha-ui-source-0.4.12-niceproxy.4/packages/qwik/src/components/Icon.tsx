// Generated from source/components/foundation/Icon.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type IconProps = CommonProps & {
  name: IconName;
  label?: string;
  weight?: 'regular' | 'bold';
};
export const Icon = component$<IconProps>((p) => {
  return (
    <span
      className={cx('as-icon', p.className)}
      data-icon-weight={p.weight}
      role={p.label ? 'img' : undefined}
      aria-label={p.label}
      aria-hidden={p.label ? undefined : true}
      style={{
        '--as-icon-regular-url': 'url("' + iconsRegular[p.name] + '")',
        '--as-icon-bold-url': 'url("' + icons[p.name] + '")',
      }}
    />
  );
});
