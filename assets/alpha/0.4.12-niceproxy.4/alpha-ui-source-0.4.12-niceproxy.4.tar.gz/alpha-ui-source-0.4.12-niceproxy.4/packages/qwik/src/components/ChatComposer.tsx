// Generated from source/components/chat/ChatComposer.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { ChatButton } from './ChatButton';
import { ChatInput } from './ChatInput';
export type ChatComposerProps = CommonProps & {
  value: string;
  disabled?: boolean;
  onValueChange$?: Handler<[string]>;
  onSend$?: Handler<[]>;
  onAttach$?: Handler<[]>;
  onRecord$?: Handler<[]>;
  onEmoji$?: Handler<[]>;
};
export const ChatComposer = component$<ChatComposerProps>((p) => {
  return (
    <div className={cx('as-chat-composer', p.className)}>
      <ChatInput
        value={p.value}
        disabled={p.disabled}
        onValueChange$={p.onValueChange$}
        onEmoji$={p.onEmoji$}
      >
        {p.onAttach$ && (
          <ChatButton variant="attach" disabled={p.disabled} onPress$={p.onAttach$} />
        )}
        <ChatButton variant="record" disabled={p.disabled} onPress$={p.onRecord$} />
      </ChatInput>
      <ChatButton variant="send" disabled={p.disabled || !p.value.trim()} onPress$={p.onSend$} />
    </div>
  );
});
