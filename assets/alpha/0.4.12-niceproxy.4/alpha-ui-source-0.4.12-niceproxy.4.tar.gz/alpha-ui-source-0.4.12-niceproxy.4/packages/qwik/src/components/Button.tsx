// Generated from source/components/controls/Button.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type ButtonProps = CommonProps & {
  variant?: 'default' | 'simple' | 'blank' | 'pressed' | 'focused' | 'disabled';
  size?: 'sm' | 'md';
  width?: 'content' | 'container';
  labelWrap?: 'wrap' | 'single-line';
  disabled?: boolean;
  loading?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onPress$?: Handler<[]>;
};
export const Button = component$<ButtonProps>((p) => {
  return (
    <button
      type={p.type ?? 'button'}
      className={cx('as-button', p.className)}
      data-variant={p.variant ?? 'default'}
      data-size={p.size ?? 'sm'}
      data-width={p.width ?? 'content'}
      data-label-wrap={p.labelWrap ?? 'wrap'}
      data-loading={p.loading ? 'true' : undefined}
      disabled={p.disabled || p.loading || p.variant === 'disabled'}
      aria-busy={p.loading || undefined}
      onClick$={p.onPress$}
    >
      {(p.loading || p.disabled || p.variant === 'disabled') && (
        <svg class="as-button-frame" aria-hidden="true">
          <rect />
          <path />
        </svg>
      )}
      <span className="as-button-label">
        <Slot />
      </span>
    </button>
  );
});
