import { defineConfig } from 'vite';
import { qwikVite } from '@builder.io/qwik/optimizer';
export default defineConfig({
  plugins: [qwikVite({ outDir: 'dist' })],
  build: {
    outDir: 'dist',
    target: 'es2022',
    lib: { entry: 'src/index.tsx', formats: ['es'], fileName: () => 'index.qwik.mjs' },
    rollupOptions: {
      external: ['@builder.io/qwik', '@builder.io/qwik/jsx-runtime', '@alpha/core'],
    },
  },
});
