# Alpha's UI project server

UI rules: `node_modules/@alpha/core/AGENTS.md` relative to the connected application's root. Do not pass build commands over HTTP. The project defines its own build command in `alpha.project.json`. If a component is missing, notify the user and create or update `ui-unspec/<component_name>.md` in the app.
