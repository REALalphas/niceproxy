# @alpha/project-server

Local project build and update adapter for Alpha's Hub.

```sh
npx alpha-project alpha.project.json
```

See `@alpha/core/distribution.md` for the update contract and deployment requirements.

The Hub is a separate application and is not included in this package. This adapter serves static client builds; SSR applications need their own adapter. Node.js 22+ is required.

Licensed under AHCL-1.0, a source-available license with conditions on commercial use and Hub integration. Read [LICENSE](./LICENSE) and [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) before use. Corresponding source must accompany distribution or be available for the exact version as required by §4 of LICENSE.
