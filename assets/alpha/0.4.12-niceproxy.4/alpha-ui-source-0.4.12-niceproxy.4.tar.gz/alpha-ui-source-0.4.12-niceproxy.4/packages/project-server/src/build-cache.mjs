import { readdir, lstat, stat, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { within } from './http.mjs';

// Only directories created by the project server are eligible for deletion.
export const isBuildId = (id) =>
  typeof id === 'string' &&
  /^\d+\.\d+\.\d+(?:-[\w.-]+)?-[a-f\d]{8}-(?:[a-f\d]{4}-){3}[a-f\d]{12}$/.test(id);

export async function cleanBuildCache({
  builds,
  output = 'dist',
  activeId = null,
  retainBuilds = 3,
  dryRun = false,
}) {
  if (!Number.isInteger(retainBuilds) || retainBuilds < 1 || retainBuilds > 100)
    throw new Error('retainBuilds: целое число от 1 до 100');
  const complete = [],
    incomplete = [];
  for (const entry of await readdir(builds, { withFileTypes: true })) {
    if (!entry.isDirectory() || !isBuildId(entry.name)) continue;
    const dir = within(builds, entry.name);
    if ((await lstat(dir)).isSymbolicLink()) continue;
    try {
      const index = await stat(within(dir, output + '/index.html'));
      if (!index.isFile()) throw new Error('Нет index.html');
      complete.push({ id: entry.name, time: index.mtimeMs });
    } catch (error) {
      if (error.code && error.code !== 'ENOENT' && error.code !== 'ENOTDIR') throw error;
      incomplete.push(entry.name);
    }
  }
  complete.sort((a, b) => b.time - a.time || b.id.localeCompare(a.id));
  const keep = new Set(activeId ? [activeId] : []);
  for (const entry of complete) {
    if (keep.size >= retainBuilds) break;
    keep.add(entry.id);
  }
  const removed = [
    ...incomplete.filter((id) => id !== activeId),
    ...complete.filter((entry) => !keep.has(entry.id)).map((entry) => entry.id),
  ];
  if (!dryRun)
    for (const id of removed) await rm(within(builds, id), { recursive: true, force: true });
  return { kept: [...keep], removed, dryRun };
}
