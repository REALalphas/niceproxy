import { installControlMotion } from '@alpha/core';
import { render, component$, useSignal } from '@builder.io/qwik';
import loaderUrl from '@builder.io/qwik/qwikloader.js?url';
import { Stack, Text, Card, Button, Profile } from '@alpha/qwik';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import './app.css';
const App = component$(() => {
  const count = useSignal(0);
  return (
    <main class="alpha-ui" style={{ padding: '24px' }}>
      <Stack gap={6}>
        <Text as="h1">Независимый Qwik</Text>
        <Text font="mono">Alpha's UI {import.meta.env.ALPHA_UI_VERSION}</Text>
        <Text>
          В исходном проекте закреплена версия 0.1.0. Эта сборка использует выпуск центра.
        </Text>
        <Card>
          <Stack gap={4}>
            <Text as="h2">Аккаунт и состояния</Text>
            <Stack direction="row" gap={4}>
              <Profile />
              <Profile state="loading" />
              <Profile state="unstable" />
              <Profile state="error" />
            </Stack>
            <Button
              onPress$={() => {
                count.value++;
              }}
            >
              Проверить действие
            </Button>
            <Text>Нажатий: {count.value}</Text>
          </Stack>
        </Card>
      </Stack>
    </main>
  );
});
const root = document.getElementById('root')!;
if (!root.hasAttribute('q:base'))
  root.setAttribute('q:base', new URL(/* @vite-ignore */ './', import.meta.url).href);
const loader = document.createElement('script');
loader.type = 'module';
loader.src = loaderUrl;
loader.onload = () => {
  void render(root, <App />);
};
document.head.appendChild(loader);

installControlMotion();
