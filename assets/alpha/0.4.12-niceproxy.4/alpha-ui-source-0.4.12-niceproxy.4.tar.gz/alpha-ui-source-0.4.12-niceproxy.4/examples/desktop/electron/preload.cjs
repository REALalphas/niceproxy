const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('alphaDesktop', {
  minimize: () => ipcRenderer.invoke('alpha-window:minimize'),
  toggleMaximize: () => ipcRenderer.invoke('alpha-window:toggleMaximize'),
  close: () => ipcRenderer.invoke('alpha-window:close'),
});
