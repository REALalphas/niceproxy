import type { DesktopBridge } from '@alpha/core';
declare global {
  interface Window {
    alphaDesktop?: DesktopBridge;
  }
}
export const electronBridge: DesktopBridge = {
  async minimize() {
    await window.alphaDesktop?.minimize();
  },
  async toggleMaximize() {
    await window.alphaDesktop?.toggleMaximize();
  },
  async close() {
    await window.alphaDesktop?.close();
  },
};
