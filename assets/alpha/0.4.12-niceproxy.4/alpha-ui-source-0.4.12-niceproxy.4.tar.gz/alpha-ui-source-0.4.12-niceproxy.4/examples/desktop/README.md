# Tauri and Electron

Both containers use the same React/Qwik components and CSS. UI packages do not import native APIs. The `DesktopBridge` type is defined in `@alpha/core`; the implementation lives in the desktop app.

## Electron

First run `npm run build` from the root. Then in `examples/desktop/electron`, run `npm install` and `npm start`. React opens by default. For Qwik, set `ALPHA_UI_FRAMEWORK=qwik` before starting.

[main.mjs](electron/main.mjs) loads the local build. [preload.cjs](electron/preload.cjs) exposes only three window operations, with context isolation and without node integration in the renderer. You can keep the native OS window frame. If you need a custom title bar, build it from `IconButton` with minimize/maximize/close and a callback to [window-bridge.ts](electron/window-bridge.ts).

## Tauri

The example lives in [tauri/src-tauri](tauri/src-tauri): Cargo manifest, build script, main, config, and window capabilities. Requires Rust and Tauri system prerequisites. After `npm run build` from the root, run `cargo run --manifest-path examples/desktop/tauri/src-tauri/Cargo.toml`.

For Qwik, change `frontendDist` in config to `../../../../apps/qwik/dist`. The Qwik demo builds in CSR mode without a backend server. To use the window bridge, add `@tauri-apps/api` to the frontend app; backend capabilities already list the required window actions.

In Qwik, keep native imports inside a lazy callback or a separate adapter module; do not capture a native `Window` object in a serializable store. Font and component appearance is controlled by the shared packages.

Native binaries were not built or launched in this session. Frontend builds and browser behavior were verified; native integrations are provided as runnable source examples and require verification in the target container.

Reference: [Tauri configuration](https://v2.tauri.app/reference/config/), [Qwik with Tauri](https://qwik.dev/docs/integrations/tauri/), [Electron context isolation](https://www.electronjs.org/docs/latest/tutorial/context-isolation).
