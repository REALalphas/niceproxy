# Tauri и Electron

Оба контейнера используют те же React/Qwik-компоненты и CSS. UI-пакеты не импортируют native API. Тип `DesktopBridge` определён в `@alpha/core`; реализация живёт в desktop-приложении.

## Electron

Сначала `npm run build` из корня. Затем в `examples/desktop/electron` выполни `npm install` и `npm start`. По умолчанию открывается React. Для Qwik задай `ALPHA_UI_FRAMEWORK=qwik` перед запуском.

[main.mjs](electron/main.mjs) загружает локальную сборку. [preload.cjs](electron/preload.cjs) предоставляет только три операции с окном, с context isolation и без node integration в renderer. Системную рамку окна можно оставить. Если нужна собственная панель, собери её из `IconButton` с minimize/maximize/close и callback к [window-bridge.ts](electron/window-bridge.ts).

## Tauri v2

Пример находится в [tauri/src-tauri](tauri/src-tauri): Cargo manifest, build script, main, config и window capabilities. Нужны Rust и системные prerequisites Tauri. После `npm run build` из корня запускай `cargo run --manifest-path examples/desktop/tauri/src-tauri/Cargo.toml`.

Для Qwik замени `frontendDist` в config на `../../../../apps/qwik/dist`. Qwik-демо собирается в CSR-режиме без backend-сервера. Для использования window bridge добавь `@tauri-apps/api` в frontend-приложение; backend capabilities уже перечисляют нужные window actions.

В Qwik native-импорты держи внутри lazy callback или отдельного модуля адаптера; не захватывай native Window-объект в serializable store. Внешний вид шрифтов и компонентов задают общие пакеты.

Native binaries в этой сессии не собраны и не запускались. Проверены frontend-сборки и поведение в браузере; native-интеграции приведены как runnable исходные примеры и требуют проверки в целевом контейнере.

Справка: [Tauri configuration](https://v2.tauri.app/reference/config/), [Qwik with Tauri](https://qwik.dev/docs/integrations/tauri/), [Electron context isolation](https://www.electronjs.org/docs/latest/tutorial/context-isolation).
