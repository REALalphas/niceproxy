# Alpha's UI — AI agent rules

First read `docs/agent-guide.md`, `packages/core/src/catalog.json`, and `source/README.md`. This is a React/Qwik UI library. Backend and desktop APIs belong to the application and are passed via handlers; do not import Electron/Tauri inside the library.

## Sources and API

- Use `@alpha/react` or `@alpha/qwik`, the shared `@alpha/core/styles.css`, and the local `@alpha/core/fonts.css`.
- The same component has the same props and markup in both frameworks. Handler difference: `onPress` / `onPress$`, `onSelect` / `onSelect$`, etc.
- Source map: `source/README.md`. Components live in `source/components/<group>/<Component>.mjs`, their list in `source/components/index.mjs`; demo in `source/demo/Demo.tsx.template`. Do not edit generated `packages/{react,qwik}/src/` or `apps/*/src/demo.tsx` by hand. In core, only `catalog.json`, `icons.ts`, and `tokens.css` are generated automatically; other runtime modules and CSS are edited directly.
- Public chat: ChatMessage, ChatButton, ChatInput, ChatComposer, ChatThread, ChatSurface. Source is `source/components/chat/*.mjs`; do not reintroduce removed wrappers. See `docs/chat.md`.
- Components are application-controlled. Do not present partially inspected Figma mockups as an exact implementation; extensions are marked in the catalog, and limitations are documented alongside the respective component or in the audit.
- If a component, prop, or behavior is missing, notify the user immediately and create or update `ui-unspec/<component_name>.md`: screen, specific gap, needed behavior, version, workaround, status. This folder is created on the first entry; there is no pre-existing gap log in the repository. Do not hide a missing feature behind a custom replacement. External projects follow the same format from `docs/consumer-agent-rules.md` included in core.

## Styling

- Body text: **Noto Sans**. Headings, buttons, text navigation, and service title: **Manrope**. Code and technical values: **Fira Code**.
- Font weights: regular text and buttons 400, emphasized text and headings 500, service title 600. Do not use 700/800. Minimum text size, including labels and buttons, is `1rem`.
- UI icons: **Lucide**, `1.5rem` (24×24 at 16px base): regular `0.09375rem` (1.5px), bold `0.125rem` (2px). Text `weight=bold`, `strong`/`b`, and the service title select bold; for arbitrary CSS `font-weight`, explicitly pass `Icon weight=regular/bold`. Logos, flags, photos, and illustrations are separate assets.
- Use `--as-*` tokens. Do not add fonts, UI libraries, or local colors/spacing to bypass the system. Sizes are in `rem` from a 16px base; containers use `%`, `svh`, and `aspect-ratio`. Do not introduce fixed `px`, except for the base size.
- Max width is `--as-size-content-max: 90rem`; on narrow screens, 100% of available width. Button: `docs/buttons.md`.
- Backgrounds: canvasDeep `#191919`, canvas `#222222`, overlay/surface `#292929`, navigation `#333333`. Default background is canvas; canvasDeep requires an explicit need.
- Visible borders: inset `box-shadow` only. CSS `border` is only allowed as `border: 0` for reset. Exception: Disabled and Loading states on Button use a single dashed SVG outline (static/animated); Loading Profile also uses SVG. Do not simulate dashes with masks.
- Component and inner layer rounding uses `corner-shape: superellipse(1.2)` with radii in `rem` and a `border-radius` fallback. Loading SVG matches this contour. Round chat corners use `corner-shape: round`; message actions are visible on hover/focus. Do not add invented names or labels.

## Motion and containers

- Fast 0.4s / normal 0.6s regardless of curve: Switch `cubic-bezier(.5,.4,0,1)`, Transition `cubic-bezier(.2,.66,0,1)`. Do not leave an implicit `ease`. View Transitions are wired by the application; see `docs/motion.md`.
- Button hover: delay 0.033s, duration 0.166s. Press: 0.166s without delay. Release: 0.4s without delay. `installControlMotion()` is installed in the browser once per app with cleanup.
- Qwik `q:base` belongs to the application container; do not overwrite it in components. See `docs/qwik-containers.md`; verify lazy production handlers, including subpath deployments.

## Verification and release

- Node.js 22.23.4+ (minimum required by current Astro for documentation). Install: `npm ci`. `npm run dev` starts React on 5173 and Qwik on 5174; individually: `dev:react` / `dev:qwik`.
- After changing canonical files or tokens, run `npm run generate`, then `npm run build`, `npm run typecheck`, `npm test`, `npm run check:generated`, and `npm run check:packages`. `npm run verify` runs the full suite starting with generation checks.
- `npm run format` formats sources and JSX templates, then generates adapters. `npm run format:check` checks formatting without writing files; it is also part of `verify`.
- After changing docs, run `npm run check:docs`. After building, `check:packages` also checks guide copies and links inside future archives; both checks are part of `verify`.
- Verify changed components in React and Qwik on wide screens and 320px: keyboard navigation, long labels, loading, disabled, active selection, images.
- `LICENSE`, `THIRD_PARTY_NOTICES.md`, and `licenses/` are the sources for license copies in packages; updated via `generate`. Test avatars live only in `apps/shared/local-assets/`, not as core runtime assets.
- Release: `npm run release -- X.Y.Z` with a new version. Old archives are immutable. Core/react/qwik share a single version; linked projects update through Alpha's Hub and rebuilding, not by replacing old JS files.
