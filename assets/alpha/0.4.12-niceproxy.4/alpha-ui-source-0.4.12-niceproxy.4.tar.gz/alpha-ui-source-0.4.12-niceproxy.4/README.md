# Alpha's UI

A library for building web applications in a unified visual style. Includes inputs, buttons, navigation, chat, and application shell.

**One component set for two frameworks.** The React and Qwik versions share styles and markup; your application controls state, data, and actions.

## Running the demos

Requires Node.js 22.23.4+ and npm (the minimum required by current Astro for the documentation site). In the repository root:

```sh
npm ci
npm run dev
```

Demos: [React](http://127.0.0.1:5173/) · [Qwik](http://127.0.0.1:5174/).

`dev` generates components, builds packages, and watches for changes.

For a single demo: `npm run dev:react` or `npm run dev:qwik`.

## Integrating into an application

Install `@alpha/core` and one adapter — `@alpha/react` or `@alpha/qwik` — from a [prepared release](docs/distribution.md). A public npm registry is not assumed.

Styling setup, component wiring, and examples for both frameworks are in the [integration guide](docs/agent-guide.md).

Alpha's Hub is a separate project. This repository contains the connection protocol and the project server for updates via Hub.

No public URL for obtaining Hub is specified yet; the local instructions assume a separate project has already been provided by the owner.

## Library development

```text
source/                   canonical components and demo template
packages/core/            tokens, CSS, motion, fonts, and icons
packages/react/           generated React adapter
packages/qwik/            generated Qwik adapter
packages/project-server/  local update adapter via Hub
apps/                     demos and documentation
scripts/                  generation, build, checks, and releases
tests/                    contract and behavior tests
docs/                     maintained guides and contracts
```

Edit canonical components in `source/components/`, shared styles and tokens in `packages/core/src/`. Adapters and demos are generated automatically. Details are in the [source map](source/README.md).

```sh
npm run format
npm run verify
```

`verify` checks generation, formatting, builds, links, types, tests, and package contents. Individually: `npm run generate` for generation; `npm run check:docs` for documentation links.

New releases include an archive of the corresponding source with build scripts and lockfile; its filename and SHA-512 are recorded in `manifest.source`. Transfer verification rebuilds the source and compares the result with release packages: `node scripts/check-release.mjs releases/X.Y.Z`.

## Documentation

```sh
npm run docs:dev
```

Starlight site: <http://127.0.0.1:4321/>. Each component has live React/Qwik examples, their source code, and current props. Search works in the production build: `npm run docs:build`, then `npm run docs:preview`.

The site is prepared for GitHub Pages; publishing is triggered manually and a regular push does not run it. [Local workflow and publishing later](docs/documentation.md).

The site build includes downloadable library and demo source archives with a checksum; their integrity is verified automatically.

- [Integration and composition](docs/agent-guide.md) · [API catalog](packages/core/src/catalog.json)
- [Installation, updates, and releases](docs/distribution.md) · [Consumer app rules](docs/consumer-agent-rules.md)
- [Browser verification and diagnostics](docs/verification.md) · [Pre-publication audit](PUBLIC_RELEASE_AUDIT.md)

## License

[Alpha's Hub Community License (AHCL-1.0)](LICENSE) — source-available, with usage restrictions.

| Who uses it | Non-commercial | Commercial |
| --- | --- | --- |
| Individual acting for themselves | Allowed | With an active Alpha's Hub integration |
| Organization | With an active Alpha's Hub integration | Only with separate written permission from the copyright holder |

Modifications and distribution of the library are under the same license, including the source of the distributed version and changes. The copyright holder and entities under their control have an exception within the scope of their rights. Third-party materials retain their own licenses.

Engineering rules for agents define how to work with the library and do not impose additional license restrictions.

Third-party licenses: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
