# Documentation site

The Astro/Starlight site lives in `apps/docs/`. It builds into static HTML, CSS, and JavaScript, including local Pagefind search and live React/Qwik examples. The published site does not require an application server.

## Local setup

The repository with the docs site requires Node.js **22.23.4+**: the minimum required by current Astro. Install dependencies with `npm ci`.

```sh
npm run docs:dev
```

This command stops any previous documentation server, builds the library and isolated React/Qwik examples, prepares pages, and starts the dev server at `http://127.0.0.1:4321/`. Restarting is needed so Astro re-reads the list of public files after a build. Pagefind search is built in the production build; test it with preview:

```sh
npm run docs:build
npm run docs:preview
```

Output goes to `apps/docs/dist/`. These commands run locally and do not publish anything.

The build includes the corresponding source archive in `downloads/alpha-ui-source-X.Y.Z.tar.gz` and `downloads/source.json` with version, size, and SHA-512. Links are available on the homepage and in terms of use. This is a snapshot of the library, site, and examples for the current build; it does not replace an individual package release's source from `manifest.source`. After building, checksum, contents, and byte-for-byte parity of the archive against the source are verified. Publish the entire `dist/`, including `downloads/`, so visitors receive the corresponding source.

The shared demo site is not part of the documentation. Component pages only open isolated examples; they are built via separate entry points `apps/{react,qwik}/examples.html` into `dist-examples/`. They do not import `Demo`, the catalog, or switching to the shared view. Local repository demo apps are launched separately via `npm run dev`.

## Where to edit

- Guides — existing Markdown files in `docs/`. The site uses them directly without manual copies; relative links are rewritten during build.
- Descriptions and examples — `source/docs/examples.mjs`. Both executable React/Qwik components and the code shown on the site are generated from a single example. Example state stays in the browser; no backend is connected.
- Props — the [catalog](../packages/core/src/catalog.json), generated from canonical definitions. Do not edit the catalog manually.
- Navigation — `apps/docs/astro.config.mjs`; styling — `apps/docs/src/styles/docs.css`. Uses local fonts and Alpha's UI tokens.
- Page assembly — `scripts/prepare-docs.mjs`. `apps/docs/src/content/docs/` and `apps/docs/public/` are recreated from scratch; do not store custom files there.

After modifying examples, run `npm run generate`, then `npm run verify`. The full check includes the site build and Astro type checking. The API catalog and examples are published for the current build's version; versioned site archives are not yet implemented.

After changing canonical guides or examples, restart `docs:dev` to refresh prepared pages and examples. Styling and Astro component edits are picked up by the dev server immediately.

Live examples use explicit `examples/react/index.html?component=Button` or `examples/qwik/index.html?component=Button`: Astro dev does not serve these public HTML files at the directory URL. The URL always specifies a component.

After building, you can verify links over HTTP against running dev or preview, including all examples:

```sh
node scripts/check-docs-site.mjs --url=http://127.0.0.1:4321
```

## GitHub Pages subpath check

The repository name is not yet fixed. The base path is passed via environment variables rather than hardcoded in links. For example, for an `alphas-base` repository:

```sh
DOCS_BASE_PATH=/alphas-base/ npm run docs:build
DOCS_BASE_PATH=/alphas-base/ npm run docs:preview
```

Open `http://127.0.0.1:4321/alphas-base/`. `DOCS_SITE_URL` sets the future site origin for the sitemap; it is optional for local checks. Qwik examples preserve their own container and lazy module base. Verify framework switching, inputs, buttons, and direct navigation to nested pages.

## Publishing later

Only preparation is currently configured. The `.github/workflows/pages.yml` workflow runs **manually** via `workflow_dispatch`. Regular push or pull request events do not publish the site.

Once the repository is pushed to GitHub and you decide to publish the docs:

1. In repository settings, open **Settings → Pages → Build and deployment → Source → GitHub Actions**.
2. In **Actions → Publish documentation → Run workflow**, choose the target branch and run the workflow.
3. It will verify the project, build the site with the real Pages path, and publish `apps/docs/dist/`. The URL will appear in the deployment result.

For a public repository, GitHub Pages is free. For a private repository, availability depends on the GitHub plan. Repeat the manual trigger for subsequent updates. If automatic publishing is needed later, add a push trigger for the chosen main branch.

The site does not create an npm release or modify library archives. The package release process is described in the [distribution guide](distribution.md).
