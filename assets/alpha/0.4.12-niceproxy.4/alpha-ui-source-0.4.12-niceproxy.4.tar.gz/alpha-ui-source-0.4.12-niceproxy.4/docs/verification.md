# Library and demo verification

`npm run verify` checks generation, formatting, package and demo builds, types, tests, and npm package contents. The generation check also rejects leftover `.tsx` components no longer in the canonical catalog. `npm run format` formats sources and templates consistently and updates generated files. The [source map](../source/README.md) shows where to make changes.

To verify links without a browser, run `npm run check:docs`: it checks local Markdown links, heading anchors, and references to public package exports without requiring external network access. After building, `npm run check:packages` additionally checks links against the file list of upcoming npm archives, parity between docs and sources, and the separate release docs structure. It also creates and unpacks the source archive and verifies its SHA-512, contents, and byte-for-byte match with the workspace. Both checks are part of `npm run verify`.

For a finished trusted release, run `node scripts/check-release.mjs releases/X.Y.Z`: sources from `manifest.source` go through a clean install and `verify`, the four rebuilt packages are compared with the release archives, and then React/Qwik consumer apps are verified. Details and historical release limitations are in the [distribution guide](distribution.md#release-source-and-conformance-verification).

Passing checks does not confirm the existence of every path inside example commands or implementation of every described behavior. Files that a consumer app must create and unimplemented capabilities are marked explicitly in the text.

## Browser verification

In the "Example" tab (`?view=base`), React/Qwik uses `AppShell` with `width="container"`: the shell fills the available page width. The header includes a controlled service picker and an optional context picker to the right of the sidebar. Source: `source/demo/Demo.tsx.template`.

Picker composes Select; the overlay and field states are wired via shared `installControlMotion()` and core CSS.

`node scripts/verify-headbar.mjs` verifies production React/Qwik builds at root and `/review/` at 1680/320px. `ALPHA_REVIEW_LIVE=1 node scripts/verify-headbar.mjs` verifies dev servers 5173/5174. It checks container width, controlled selection, keyboard navigation, states, animations, reduced motion, and header alignment.

The script requires built packages and demos (`npm run build`), Chromium in PATH, and free port 9351. For `ALPHA_REVIEW_LIVE=1` mode, start the dev servers first.

Screenshots and diagnostics are written to ignored `output/yonix-review/`. Store intermediate screenshots, logs, and one-off reports in `output/`, and maintained guides and contracts in `docs/`. An old screenshot does not confirm verification of the current code.
