# Pre-public release audit

Date: 2026-11-05. Checked the Alpha's UI working tree, docs, dependencies, and upcoming npm packages. No commit, push, or publication was performed; no new release was created in the working project. Old `releases/` directories were not modified.

Technical preparation is complete; the AHCL-1.0 license remains a draft with open questions. Following legal audit, per owner instruction only the brand spelling in `LICENSE` was fixed to Alpha's; licensing terms did not change. This report records the state and does not add license restrictions.

## What was fixed

| Issue | Result |
| --- | --- |
| README described 16 components and removed domain screens | README now describes the 28 current components, launch commands, structure, and source-available model; release instructions fixed |
| Docs mixed repository paths, installed package paths, and a missing gap log | Fixed catalog export to `@alpha/core/catalog.json`; physical path listed separately. Examples and AGENTS use on-demand `ui-unspec/<component_name>.md`; repository paths are explicitly marked as repository paths |
| Example bootstrap file path looked like a link to an existing source file | Non-existent specific path removed. Explicitly stated that Alpha's UI does not provide a ready-made bootstrap: the consumer app implements it per the documented requirements |
| Not all guides were included in the package; checks missed broken links | Added `chat.md` and `consumer-agent-rules.md` to core; guides are exposed via exports. Upcoming releases include their own `docs/` and README with links. `check:docs` validates links and exports; `check:packages` validates links against archive contents, copy parity, and separate release docs staging |
| Notices still called the logo unverified and referenced removed materials | Recorded owner-confirmed authorship of `hub_logo.svg`; source paths separated from core asset path. Outdated warning about removed screenshots and Figma dumps removed; third-party licenses preserved |
| Diagnostics, conflict copies, and local data could end up in Git | `.gitignore` excludes `output/`, local avatars, `.sync-conflict-*`, builds, env, keys, and logs; ignores do not remove already-tracked files |
| Conflict TSX files leaked into package declarations | Conflict copies excluded from TypeScript; package checks reject such artifacts |
| Temporary materials remained in docs, experimental components in adapters | Removed 42 intermediate screenshots from `docs/design`, eight raw Figma dumps, the 0.2.2 release report, and two unused copies of TestTextInput; generation rejects components outside the canonical catalog. Verification instructions saved in `docs/verification.md` |
| Canonical code was hard to find and read | Replaced `design/` with `source/`: 28 separate component modules by group, shared demo template, and resources. Code and JSX templates formatted; `source/README.md` map distinguishes manual sources from generation. Generated files state their source and are marked for GitHub via `.gitattributes` |
| Generation, resources, and demo were mixed in one script | `generate.mjs` coordinates separate generators for components, resources, and demo. `format` formats canonical code and updates generated output; `format:check` is part of verify and CI. Tests verify preservation of JSX text, handler placeholders, and local files outside the catalog |
| Old VPN brands, cover image, and unused assets remained in core | Removed from active runtime assets per owner instruction; `source/resources/assets.json` map now contains only `hub_logo.svg` |
| Test photos were bundled in the library package | Real PNGs `TestProfilePicture1.png` and `TestProfilePicture2.png` are only available to local dev via ignored `apps/shared/local-assets/`; production and packages do not include them |
| Unreadable name and extra SVG markup | Logo renamed to `hub_logo.svg`; Astra compared before/after renders and confirmed pixel parity |
| Licenses did not accompany packages | AHCL, THIRD_PARTY_NOTICES, and original Lucide/Feather and OFL texts are included in every upcoming npm archive and release staging |
| Catalog reported outdated version `0.1.0` | Generator reads the package version; release staging sets the version of the created release separately without rewriting old archives |
| Vulnerable tooling dependencies | Vite updated to 7.3.7, `launch-editor` in lockfile to 2.14.2; npm audit result verified separately |
| Update endpoint accepted foreign Host without a token | `allowMutation()` rejects non-loopback Host without a token; DNS rebinding check added |
| No public repository checks existed | GitHub Actions checks Node 22 and 24, generation, builds, types, tests, package contents, and no tracked file diffs |
| Release did not include corresponding source | `release` creates `alpha-ui-source-X.Y.Z.tar.gz` with canonical code, runtime, assets, workspace, lockfile, generators, tests, and licenses. `manifest.source` holds filename, size, and SHA-512; release README links to the archive. `check:packages` checks contents and byte-for-byte parity; `check-release.mjs` rebuilds source and compares the four packages against the release |
| Site build included built demos without corresponding source archive | Site build now includes `downloads/alpha-ui-source-X.Y.Z.tar.gz` and `downloads/source.json` with version, size, and SHA-512. Homepage and terms of use link to the archive. Production site check unpacks the archive and verifies contents and every file against working sources; corrupted archives are rejected. This is a snapshot of the site and demos, not a replacement for an individual release's `manifest.source` |
| Engineering prohibitions could be mistaken for extra license terms | Clarified at the top of `consumer-agent-rules.md`, in the guide, and in README: workflow and separately agreed support terms do not modify LICENSE and do not revoke rights to modify and distribute granted by it |
| Local Hub launch instructions could appear as a publicly available distribution | README and guide explicitly state that no public Hub download URL exists yet and commands assume a separately provided project; the adapter and protocol alone do not provide integration |

Local materials removed during cleanup are preserved outside the repository. Old releases contain historical assets and licenses: new cleanup does not alter them retroactively.

## Remaining items before publication

### 1. Copyright holder and permissions — high priority

`LICENSE`, §§1–2 defines Licensor as the copyright holder, but does not specify a name, stable identifier, or contact channel. Owner details and a clear way to obtain written commercial permission are needed. No fabricated details were added.

For third-party contributions, separately determine who is authorized to permit commercial use of those contributions. One's own license on the original library does not automatically grant the author rights to others' modifications. The broad exception for the owner and controlled companies is an agreed term; it should not be narrowed without a separate decision.

### 2. Hub and operator obligations — high priority

`LICENSE`, §3 requires a working integration, but does not define the responsible operator, permitted Hub instances/forks, or the limit of "temporary" loss of connectivity. The duty to restore integration after failure is already present; permanent intentional bypass is not explicitly addressed.

The condition requires the ability to request updates, not mandatory application of every update. Forced updates, recovery deadlines, and discontinuation of Hub by the owner require a separate decision. These are not existing user obligations.

External readers do not obtain Alpha's Hub from this repository. The documentation now explicitly states this limitation and the local guide's prerequisite, but a public Hub download URL is not yet set. For modes requiring integration, an accessible guide to obtaining and running it is needed; this blocker remains open.

### 3. Source distribution — high priority

`LICENSE`, §4 already requires AHCL-1.0 for derivatives. The distribution guide now explains how this applies to forks and mirrors, preserving notices, and marking modifications. Simply replacing the LICENSE file, fork name, minification, or compilation does not grant the right to relicense another's code. This clarification does not alter the license; the decision on any additional wording in the license text remains with the owner.

The technical gap is closed for future releases: `scripts/release.mjs` creates an archive of corresponding source and records it in `manifest.source`. A temporary archive is verified via `check:packages`; `check-release.mjs` runs a clean install, `verify`, and comparison of rebuilt packages with release archives. Original workspace versions and lockfile are preserved; the release version is applied during staging. Build rules are described in the [guide](docs/distribution.md#release-source-and-conformance-verification). Old releases without source were not modified.

Additionally, source preparation for the static site is closed: `scripts/prepare-docs.mjs` places the library, site, and demo archive into the future `apps/docs/dist/downloads/` output. `scripts/check-docs-site.mjs` checks version, SHA-512, contents, and byte-for-byte parity. The archive is accessible via links on the homepage and in terms of use; GitHub Pages subpath is supported. To distribute these sources, the entire `dist/`, including `downloads/`, must be published. Public deployment of the site was not performed by this change.

Distribution decisions remain: source must be available "throughout distribution of that version"; retention duration after the last transfer is undefined. Having the archive does not confirm actual delivery or availability on a public server. Upon distribution, recipients must be provided the archive or a working link to the exact version per §4; hosting has not yet been set up.

Private modifications are currently permitted without publication. Purely server-side modifications not distributed to recipients have not been given a separate network copyleft clause. JS/CSS sent to browsers require separate attention as distributed copies. A new requirement to disclose server-side changes without code transfer was not agreed and was not added.

### 4. Other legal provisions — medium priority

The boundary between engineering rules and the license is clarified in `docs/consumer-agent-rules.md`, `docs/agent-guide.md`, and README. Local overrides remain forbidden in the specified agent workflow; this is not an additional legal restriction beyond LICENSE. No changes to the license itself were required for this.

Cure/reinstatement rules after a breach, written permission procedures, contributors, trademark notices, patents, and governing law are not fully defined. These issues require owner decisions; the absence of each clause alone does not prove the license invalid. The current text is not presented as a legally vetted document.

## Checks

- On re-review of the audit, `npm run verify` passed on Node **24.21.0** after adding downloadable site source: generation, formatting, all builds, links, types, **49 tests**, and packaging. The new site archive contains **337 files**; its SHA-512, contents, and files are verified automatically. Local log: `output/public-audit-current/node24-final-verify.log`.
- Source from the new site archive was unpacked into a separate temporary directory. On minimum Node **22.23.4**, `npm ci` and full `npm run verify` passed with `DOCS_BASE_PATH=/alphas-base/`: **49 tests**, builds, and packaging passed; checked **44 HTML pages and 3066 local links and assets**, including source downloads under the subpath. The production site check also rejected an intentionally corrupted archive by SHA-512; after the check, the original archive was restored. Local logs: `output/public-audit-current/site-source-node22-verify.log` and `corrupt-site-source.log` in the same directory.
- Repeated `npm audit` showed **0 known vulnerabilities**. In the **337 current Git candidates**, no common private key or token formats were found; file contents were not printed during the check. The Git index is empty with no history or remote: this is not a check of a future index or history. SHA-256 hashes of all **1315 historical files** in `releases/` matched the snapshot taken before this work. Local report: `output/public-audit-current/final-security.json`.
- Prior to that re-check, `npm run verify` passed on Node **24.21.0**, including the new documentation site: generation, formatting, all builds, links, types, **49 tests**, and packaging. Source archive checks also exclude Astro cache and generated site copies.
- After enabling Astro, a full cycle was repeated on Node **24.21.0** from the final source archive: `npm ci`, creating a trial release, `check-release.mjs`, a second clean install and `verify` (49 tests), comparison of all four packages, installer and standalone React/Qwik builds. Everything passed; generated pages and site builds are excluded from the source archive and rebuilt by its scripts. Local log: `output/public-audit-fixes/final-roundtrip.log`.
- Before enabling the Astro site in the main build, `npm run verify` after adding the source archive passed on Node **22.22.2**: generation, formatting, builds, links, types, **46 tests**, and packaging. Four new tests verify preservation of canonical files and lockfile, exclusion of local data, rejection of symlinks and missing inputs, archive corruption, invalid versions, and duplicate paths. The temporary archive was unpacked with SHA-512 verification and byte-for-byte workspace comparison.
- In a separate temporary copy on Node **22.22.2**, `npm ci`, a real `npm run release -- 0.0.0-release-audit`, and `node scripts/check-release.mjs releases/0.0.0-release-audit` were executed. Source from the created release passed another clean install and `verify`; contents of all four rebuilt packages matched the distribution. Installer and standalone React/Qwik app builds passed. Parallel documentation site changes entered the snapshot; two of its files were only formatted in the temporary copy prior to the check. Working project releases and `latest.json` were not modified. Local log: `output/public-audit-fixes/release-roundtrip.log`.
- After restructuring, a clean install outside the working tree was re-verified on Node **22.23.4**: `npm ci`, `npm run verify`; **40 tests passed**. Production builds do not require local avatars or a neighboring Hub. Verification did not modify any of the 254 files in the source copy.
- After fixing links, `npm run verify` in the working tree passed: up-to-date generation, formatting, core/React/Qwik/demo/project-server builds, doc links, types, 42 tests, and `check:packages`.
- During restructuring, output was compared against the preserved prior version: compiled logic and public types of all 28 components matched in React and Qwik; 17 core runtime/CSS files and demo CSS were equivalent after formatting normalization. Six unused initial state fields were removed from the demo. A later brand edit changed display names and logo alt text.
- `node scripts/verify-headbar.mjs`: all eight combinations of React/Qwik, root/`/review/`, and 1680/320px widths passed in Chromium. Verified controlled selection, keyboard navigation, disabled/unknown values, animation interpolation, release/reduced motion, and shell width.
- `check:packages` validates regular packing and release staging of the four packages: presence and parity of licenses and docs, local links, exports, internal dependency/catalog versions, absence of local and conflict files, and exact core asset list. Release documentation was checked in a separate temporary staging without creating a release.
- External URLs from maintained guides were checked: npm, MDN, Qwik, Tauri, Electron, and the Figma file return HTTP 200. The Figma page response does not confirm access to each node's contents: re-reading the mockups themselves was not performed. A public link for obtaining the separate Hub is still not specified.
- After adding the archiving tool `tar@7.5.22`, repeated `npm audit` showed **0 known vulnerabilities**. This is not a guarantee against unknown vulnerabilities.
- Searching for common secret formats in sources found no confirmed tokens or private keys. This is not a full security audit; before pushing, inspect the Git index and all files of the upcoming commit.
- The GitHub workflow was added, but running it on GitHub has not yet been tested. There are no commits or remote in Git; publication history checks were not performed.
- Relative Markdown links were verified. Git candidate files exclude local avatars, diagnostic images, conflict copies, and the old `design/` folder. Checksums of 1315 historical `releases/` files are unchanged.

## Publication status

README and technical cleanup are ready. Sources have not yet been published. The project should not be announced as open source or the license as finalized until the listed issues are resolved. Changes already approved by the user do not require re-approval; new legal obligations and details are not added automatically.
