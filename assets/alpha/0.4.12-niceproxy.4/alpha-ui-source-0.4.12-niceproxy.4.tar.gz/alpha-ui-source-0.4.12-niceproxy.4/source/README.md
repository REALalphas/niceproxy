# Где что менять

Начните с файла нужного компонента, например [Button.mjs](components/controls/Button.mjs). Один файл описывает его свойства и разметку сразу для React и Qwik.

## Карта исходников

```text
source/
  components/
    foundation/   Icon, Logo, Text, Badge
    controls/     Button, IconButton, поля, переключатели и выбор
    navigation/   Profile, HeadBar, Sidebar и кнопки навигации
    layout/       AppShell, Stack, Card
    chat/         ChatMessage, ChatInput и остальные компоненты чата
    helpers/      геометрия SVG-контуров
    index.mjs     список публичных компонентов в порядке каталога
  demo/
    Demo.tsx.template   общий экран демонстрации
  resources/
    icons.mjs     соответствие имён иконок файлам Lucide
    assets.json   список ресурсов, которые включаются в core
  docs/
    examples.mjs  описания и исполняемые примеры для сайта документации
```

Общие стили и поведение живут в `packages/core/src/` и редактируются вручную:

| Задача | Файл |
| --- | --- |
| Цвета, интервалы, радиусы, типографика, длительности | [tokens.json](../packages/core/src/tokens.json) |
| Оформление компонентов и их состояния | [styles.css](../packages/core/src/styles.css), селекторы `.as-*` |
| Hover, press, release, View Transitions | [motion.ts](../packages/core/src/motion.ts) |
| Выпадающий список | [select-overlay.ts](../packages/core/src/select-overlay.ts), [select-motion.ts](../packages/core/src/select-motion.ts) |
| Resize и scrollbar полей | [field-resize.ts](../packages/core/src/field-resize.ts), [field-scrollbar.ts](../packages/core/src/field-scrollbar.ts) |
| Группировка, время и фон сообщений | [chat-grouping.ts](../packages/core/src/chat-grouping.ts), [chat-time.ts](../packages/core/src/chat-time.ts), [chat-gradient.ts](../packages/core/src/chat-gradient.ts) |
| Оформление страницы демо | [apps/shared/demo.css](../apps/shared/demo.css) |
| Сервер подключения к Hub | [packages/project-server/src/server.mjs](../packages/project-server/src/server.mjs) |

## Как устроен компонент

Каждый модуль экспортирует описание с полями `name`, `group`, `props` и `body`. `sources` хранит ID узлов Figma; `status: 'extension'` отмечает расширение библиотеки.

- `props` — TypeScript-свойства. Общие `className`, `id`, `children` добавляет генератор.
- `body` — обычная логика и JSX; `p` содержит свойства компонента.
- `onPress@` превращается в `onPress` для React и `onPress$` для Qwik.
- `@CHILDREN@` превращается в `{p.children}` или `<Slot />`.
- `for@` превращается в `htmlFor` или `for`.
- Именованные вставки вроде `@TEXT_INPUT_HANDLER@` и `@CHAT_THREAD_LIFECYCLE@` подставляют обработчик или lifecycle соответствующего фреймворка.

Эти небольшие вставки позволяют держать одну разметку для двух фреймворков. Их реализация находится в [scripts/generate-components.mjs](../scripts/generate-components.mjs). У демо свои вставки состояния и событий в [scripts/generate-demo.mjs](../scripts/generate-demo.mjs).

## Что создаётся автоматически

`npm run generate` читает исходники и обновляет:

- `packages/react/src/` и `packages/qwik/src/` — компоненты и экспорты;
- `apps/react/src/demo.tsx` и `apps/qwik/src/demo.tsx` — демо;
- `apps/{react,qwik}/src/examples/` — живые примеры документации из `source/docs/examples.mjs`;
- `packages/core/src/catalog.json`, `icons.ts`, `tokens.css` — каталог, иконки и CSS-переменные;
- лицензионные копии в четырёх пакетах — из корневых `LICENSE`, `THIRD_PARTY_NOTICES.md` и `licenses/`.

Остальные файлы `packages/core/src/`, сервер проекта и точки входа приложений — обычные исходники. `dist/` содержит результат сборки. В начале каждого сгенерированного компонента указан путь к его исходнику.

Сайт Starlight находится в `apps/docs/`. Его страницы и публичные ресурсы создаются при сборке из руководств, каталога API и изолированных примеров React/Qwik. Их не редактируют вручную и не включают в Git; подробнее — [сайт документации](../docs/documentation.md).

Руководства из `docs/` копируются в core во время сборки; список соответствий находится в [scripts/lib/package-files.mjs](../scripts/lib/package-files.mjs). Правь исходный документ. `check:packages` проверяет, что его копия и все локальные ссылки доступны в архиве.

Архив исходников будущего выпуска создаёт [scripts/lib/release-source.mjs](../scripts/lib/release-source.mjs): список файлов включает канонический код, workspace и lock-файл, скрипты, тесты и лицензии. При добавлении нового корневого каталога обнови этот список. Версия выпуска записывается отдельно в `RELEASE_SOURCE.json`; исходные версии workspace и lock-файл сохраняются. Проверка архива входит в `check:packages`, пересборка и сравнение с пакетами выпуска — в `scripts/check-release.mjs`.

## Порядок работы

1. Найдите компонент по имени и измените его `props` или `body`. Для нового компонента добавьте модуль в `components/index.mjs`.
2. Если нужно, измените общие стили и токены в core, пример использования — в демо.
3. Выполните `npm run format`: он форматирует код, включая JSX внутри шаблонов, и запускает генерацию.
4. Выполните `npm run verify`. Изменение UI также проверьте в обоих демо на широком и узком экране по [инструкции](../docs/verification.md).

`npm run dev` следит за каноническими исходниками и пересобирает оба адаптера. `npm run format:check` проверяет оформление без записи файлов.

Локальные аватары находятся в игнорируемой `apps/shared/local-assets/`. Снимки и диагностические логи относятся к `output/`; они не являются исходниками и не попадают в пакеты.
