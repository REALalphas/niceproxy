# Where to change things

Start with the component's file, for example [Button.mjs](components/controls/Button.mjs). A single file defines its props and markup for both React and Qwik.

## Source map

```text
source/
  components/
    foundation/   Text, Logo, Icon, Badge, Stack, Card, Page...
    controls/     Button, IconButton, fields, switches, and selection
    navigation/   Profile, HeadBar, Sidebar, and navigation buttons
    layout/       AppShell
    chat/         ChatMessage, ChatInput, and remaining chat components
    helpers/      SVG path geometry
    index.mjs     public component list in catalog order
  demo/
    Demo.tsx.template   shared demo screen
  resources/
    icons.mjs     mapping from icon names to Lucide files
    assets.json   list of assets bundled into core
  docs/
    examples.mjs  descriptions and runnable examples for the docs site
```

Shared styles and behavior live in `packages/core/src/` and are edited manually:

| Task | File |
| --- | --- |
| Colors, spacing, radii, typography, durations | [tokens.json](../packages/core/src/tokens.json) |
| Component styling and states | [styles.css](../packages/core/src/styles.css), `.as-*` selectors |
| Dropdown list | [select-overlay.ts](../packages/core/src/select-overlay.ts), [select-motion.ts](../packages/core/src/select-motion.ts) |
| Field resize and scrollbar | [field-resize.ts](../packages/core/src/field-resize.ts), [field-scrollbar.ts](../packages/core/src/field-scrollbar.ts) |
| Message grouping, timestamps, and background | [chat-grouping.ts](../packages/core/src/chat-grouping.ts), [chat-time.ts](../packages/core/src/chat-time.ts), [chat-gradient.ts](../packages/core/src/chat-gradient.ts) |
| Demo page styling | [apps/shared/demo.css](../apps/shared/demo.css) |
| Hub connection server | [packages/project-server/src/server.mjs](../packages/project-server/src/server.mjs) |

## How a component is structured

Each module exports a definition with `name`, `group`, `props`, and `body`. `sources` stores Figma node IDs; `status: 'extension'` marks a library extension.

- `props` — TypeScript props. Shared `className`, `id`, and `children` are added by the generator.
- `body` — standard logic and JSX; `p` holds component props.
- `onPress@` becomes `onPress` for React and `onPress$` for Qwik.
- `@CHILDREN@` becomes `{p.children}` or `<Slot />`.
- `for@` becomes `htmlFor` or `for`.
- Named placeholders such as `@TEXT_INPUT_HANDLER@` and `@CHAT_THREAD_LIFECYCLE@` substitute the handler or lifecycle for the corresponding framework.

These small placeholders keep a single markup source for two frameworks. Their implementation lives in [scripts/generate-components.mjs](../scripts/generate-components.mjs). The demo has its own state and event placeholders in [scripts/generate-demo.mjs](../scripts/generate-demo.mjs).

## What is generated automatically

`npm run generate` reads the canonical sources and updates:

- `packages/react/src/` and `packages/qwik/src/` — components and exports;
- `apps/react/src/demo.tsx` and `apps/qwik/src/demo.tsx` — demos;
- `apps/{react,qwik}/src/examples/` — live docs examples from `source/docs/examples.mjs`;
- `packages/core/src/catalog.json`, `icons.ts`, `tokens.css` — catalog, icons, and CSS variables;
- license copies in the four packages — from root `LICENSE`, `THIRD_PARTY_NOTICES.md`, and `licenses/`.

Other files in `packages/core/src/`, the project server, and app entry points are regular hand-written sources. `dist/` holds build outputs. Each generated component states the path to its source at the top.

The Starlight site lives in `apps/docs/`. Its pages and public assets are generated at build time from guides, the API catalog, and isolated React/Qwik examples. They are not edited by hand or tracked in Git; see [documentation site](../docs/documentation.md).

Guides from `docs/` are copied into core during build; the mapping list is in [scripts/lib/package-files.mjs](../scripts/lib/package-files.mjs). Edit the source document. `check:packages` verifies that its copy and all local links are reachable inside the archive.

The future release source archive is created by [scripts/lib/release-source.mjs](../scripts/lib/release-source.mjs): the file list includes canonical code, workspace and lockfile, scripts, tests, and licenses. Update this list if adding a new root directory. The release version is written separately to `RELEASE_SOURCE.json`; original workspace versions and lockfile are preserved. Checking the archive is part of `check:packages`; rebuilding and comparing with release packages is in `scripts/check-release.mjs`.

## Workflow

1. Find the component by name and edit its `props` or `body`. For a new component, add the module to `components/index.mjs`.
2. If needed, update shared styles and tokens in core, and usage example in the demo.
3. Run `npm run format`: it formats code, including JSX inside templates, and runs generation.
4. Run `npm run verify`. Also verify UI changes in both demos on wide and narrow screens per the [verification guide](../docs/verification.md).

`npm run dev` watches canonical sources and rebuilds both adapters. `npm run format:check` checks formatting without writing files.

Local avatars live in ignored `apps/shared/local-assets/`. Screenshots and diagnostic logs belong in `output/`; they are not sources and are excluded from packages.
