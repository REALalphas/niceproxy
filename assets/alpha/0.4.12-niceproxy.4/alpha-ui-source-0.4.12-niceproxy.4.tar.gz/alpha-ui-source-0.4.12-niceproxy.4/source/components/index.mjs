// Public order is shared by both adapters and the generated catalog.
import TextInput from './controls/TextInput.mjs';
import TextArea from './controls/TextArea.mjs';
import Checkbox from './controls/Checkbox.mjs';
import Switch from './controls/Switch.mjs';
import Select from './controls/Select.mjs';
import Picker from './controls/Picker.mjs';
import Icon from './foundation/Icon.mjs';
import Logo from './foundation/Logo.mjs';
import Text from './foundation/Text.mjs';
import Stack from './layout/Stack.mjs';
import Card from './layout/Card.mjs';
import Page from './layout/Page.mjs';
import ChatSurface from './chat/ChatSurface.mjs';
import ChatMessage from './chat/ChatMessage.mjs';
import ChatButton from './chat/ChatButton.mjs';
import ChatInput from './chat/ChatInput.mjs';
import ChatThread from './chat/ChatThread.mjs';
import ChatComposer from './chat/ChatComposer.mjs';
import Badge from './foundation/Badge.mjs';
import Button from './controls/Button.mjs';
import IconButton from './controls/IconButton.mjs';
import Profile from './navigation/Profile.mjs';
import HeadBar from './navigation/HeadBar.mjs';
import NavButton from './navigation/NavButton.mjs';
import BottomNav from './navigation/BottomNav.mjs';
import DrawerButton from './navigation/DrawerButton.mjs';
import DrawerDivider from './navigation/DrawerDivider.mjs';
import Sidebar from './navigation/Sidebar.mjs';
import AppShell from './layout/AppShell.mjs';

export const components = [
  TextInput,
  TextArea,
  Checkbox,
  Switch,
  Select,
  Picker,
  Icon,
  Logo,
  Text,
  Stack,
  Card,
  Page,
  ChatSurface,
  ChatMessage,
  ChatButton,
  ChatInput,
  ChatThread,
  ChatComposer,
  Badge,
  Button,
  IconButton,
  Profile,
  HeadBar,
  NavButton,
  BottomNav,
  DrawerButton,
  DrawerDivider,
  Sidebar,
  AppShell,
];

export const componentSources = Object.fromEntries(
  components.map(({ name, group }) => [name, `source/components/${group}/${name}.mjs`]),
);
