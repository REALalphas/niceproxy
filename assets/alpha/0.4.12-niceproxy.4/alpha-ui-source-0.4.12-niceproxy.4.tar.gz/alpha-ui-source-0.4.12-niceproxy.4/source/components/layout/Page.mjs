export default {
  name: 'Page',
  group: 'layout',
  sources: [],
  status: 'extension',
  props: `
width?: 'form' | 'content' | 'full';
viewport?: 'content' | 'full';
align?: 'start' | 'center';
inset?: 'none' | 'compact' | 'comfortable';
gap?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
`,
  body: `
return (
  <div
    className={cx('as-page', p.className)}
    id={p.id}
    data-viewport={p.viewport ?? 'content'}
    data-width={p.width ?? 'content'}
    data-align={p.align ?? 'start'}
    data-inset={p.inset ?? 'comfortable'}
    data-gap={p.gap ?? 6}
  >
    @CHILDREN@
  </div>
);
`,
};
