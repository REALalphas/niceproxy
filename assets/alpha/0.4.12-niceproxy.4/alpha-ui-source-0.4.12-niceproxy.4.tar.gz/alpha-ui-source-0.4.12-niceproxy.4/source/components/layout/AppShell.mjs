export default {
  name: 'AppShell',
  group: 'layout',
  sources: ['66:737', '66:747', '66:760'],
  props: `
serviceValue?: string;
serviceOptions?: { value: string; label: string; disabled?: boolean }[];
serviceLabel?: string;
serviceDisabled?: boolean;
context?: {
  label: string;
  value: string;
  options: { value: string; label: string; disabled?: boolean }[];
  placeholder?: string;
  disabled?: boolean;
};
onServiceChange@?: Handler<[value: string]>;
onContextChange@?: Handler<[value: string]>;
serviceName: string;
items: NavItem[];
selectedId: string;
width?: 'content' | 'container';
viewport?: 'content' | 'full';
serviceMode?: 'picker' | 'static';
showAccount?: boolean;
accountLabel?: string;
accountSrc?: string;
accountState?: 'default' | 'loading' | 'unstable' | 'error';
balance?: string;
onSelect@?: Handler<[id: string]>;
onServicePress@?: Handler<[]>;
onAccountPress@?: Handler<[]>;
`,
  body: `
return (
  <div
    className={cx('as-shell', p.className)}
    data-width={p.width ?? 'content'}
    data-viewport={p.viewport ?? 'content'}
  >
    <HeadBar
      serviceValue={p.serviceValue}
      serviceOptions={p.serviceOptions}
      serviceLabel={p.serviceLabel}
      serviceDisabled={p.serviceDisabled}
      context={p.context}
      onServiceChange@={p.onServiceChange@}
      onContextChange@={p.onContextChange@}
      serviceName={p.serviceName}
      serviceMode={p.serviceMode}
      showAccount={p.showAccount}
      accountLabel={p.accountLabel}
      accountSrc={p.accountSrc}
      accountState={p.accountState}
      balance={p.balance}
      onServicePress@={p.onServicePress@}
      onAccountPress@={p.onAccountPress@}
    />
    <Sidebar
      items={p.items}
      selectedId={p.selectedId}
      onSelect@={p.onSelect@}
    />
    <main className="as-shell-content" id={p.id}>
      @CHILDREN@
    </main>
    <BottomNav
      items={p.items}
      selectedId={p.selectedId}
      onSelect@={p.onSelect@}
    />
  </div>
);
`,
};
