export default {
  name: 'Card',
  group: 'layout',
  sources: ['68:2317'],
  status: 'extension',
  props: ``,
  body: `
return <section className={cx('as-card', p.className)}> @CHILDREN@ </section>;
`,
};
