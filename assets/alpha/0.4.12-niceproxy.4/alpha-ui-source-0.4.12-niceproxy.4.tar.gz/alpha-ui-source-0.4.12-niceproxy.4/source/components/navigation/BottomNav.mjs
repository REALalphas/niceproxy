export default {
  name: 'BottomNav',
  group: 'navigation',
  sources: ['66:737', '30:164'],
  props: `
items: NavItem[];
selectedId: string;
label?: string;
onSelect@?: Handler<[id: string]>;
`,
  body: `
return (
  <nav className={cx('as-bottom-nav', p.className)} aria-label={p.label ?? 'Service navigation'}>
    {p.items.map((item) => (
      <NavButton
        key={item.id}
        label={item.label}
        icon={item.icon}
        notifications={item.notifications}
        selected={item.id === p.selectedId}
        onPress@={() => p.onSelect@?.(item.id)}
      />
    ))}
  </nav>
);
`,
};
