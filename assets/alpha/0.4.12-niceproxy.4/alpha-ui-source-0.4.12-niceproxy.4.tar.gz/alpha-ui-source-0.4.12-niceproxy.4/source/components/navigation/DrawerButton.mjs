export default {
  name: 'DrawerButton',
  group: 'navigation',
  sources: ['30:269'],
  props: `
label: string;
icon?: IconName;
secondaryText?: string;
secondaryPlacement?: 'inline' | 'below';
selected?: boolean;
onPress@?: Handler<[]>;
`,
  body: `
return (
  <button
    type="button"
    className={cx('as-drawer-button', p.className)}
    data-secondary-placement={p.secondaryPlacement ?? 'inline'}
    data-selected={p.selected ? 'true' : 'false'}
    aria-current={p.selected ? 'page' : undefined}
    onClick={p.onPress@}
  >
    <Icon name={p.icon ?? 'key'} weight={p.selected ? 'bold' : 'regular'} />
    <span className="as-drawer-label">{p.label}</span>
    {p.secondaryText && <span className="as-drawer-secondary">{p.secondaryText}</span>}
  </button>
);
`,
};
