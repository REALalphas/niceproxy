export default {
  name: 'Sidebar',
  group: 'navigation',
  sources: ['66:747'],
  props: `
items: NavItem[];
selectedId: string;
label?: string;
onSelect@?: Handler<[id: string]>;
`,
  body: `
return (
  <nav className={cx('as-sidebar', p.className)} aria-label={p.label ?? 'Service navigation'}>
    {p.items.map((item) => (
      <div key={item.id}>
        {item.group && <DrawerDivider label={item.group} />}
        <DrawerButton
          label={item.label}
          icon={item.icon}
          secondaryText={
            item.notifications === undefined ? undefined : String(item.notifications)
          }
          selected={item.id === p.selectedId}
          onPress@={() => p.onSelect@?.(item.id)}
        />
      </div>
    ))}
  </nav>
);
`,
};
