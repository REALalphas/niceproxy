export default {
  name: 'TextInput',
  group: 'controls',
  sources: [],
  status: 'extension',
  props: `
id: string;
label: string;
labelPlacement?: 'inside' | 'above';
icon?: IconName;
showIcon?: boolean;
value: string;
name?: string;
placeholder?: string;
disabled?: boolean;
readOnly?: boolean;
required?: boolean;
hint?: string;
error?: string;
onValueChange@?: Handler<[value: string]>;
type?: 'text' | 'url' | 'email' | 'password' | 'search' | 'tel';
autoComplete?: string;
passwordVisible?: boolean;
onPasswordVisibleChange@?: Handler<[visible: boolean]>;
`,
  body: `
const fieldIcon =
  p.icon ??
  (
    {
      text: 'type',
      url: 'link',
      email: 'mail',
      password: 'key',
      search: 'search',
      tel: 'phone',
    } as const
  )[p.type ?? 'text'];
const hasMarker = p.showIcon ?? (!!p.readOnly || !!p.disabled || (p.type ?? 'text') !== 'text');
const labelAbove =
  p.labelPlacement === 'above' || (p.labelPlacement !== 'inside' && !!(p.readOnly || p.disabled));
return (
  <div
    className={cx('as-field as-placeholder-field', p.className)}
    data-disabled={p.disabled ? 'true' : 'false'}
    data-error={p.error ? 'true' : 'false'}
    data-label-placement={labelAbove ? 'above' : 'inside'}
  >
    {labelAbove && (
      <label className="as-field-label" for@={p.id}>
        {p.label}
      </label>
    )}
    <span
      className="as-field-input-wrap"
      data-has-value={p.value.length ? 'true' : 'false'}
      data-has-marker={hasMarker ? 'true' : 'false'}
      data-multiline="false"
      tabIndex={p.disabled ? 0 : undefined}
      role={p.disabled ? 'button' : undefined}
      aria-label={p.disabled ? 'Editing unavailable: ' + p.label : undefined}
    >
      <input
        className="as-field-control"
        id={p.id}
        name={p.name}
        value={p.value}
        disabled={p.disabled}
        required={p.required}
        aria-label={labelAbove ? undefined : p.label}
        aria-invalid={!!p.error || undefined}
        aria-describedby={p.error || p.hint ? p.id + '-description' : undefined}
        type={p.type === 'password' && p.passwordVisible ? 'text' : (p.type ?? 'text')}
        placeholder={labelAbove ? p.placeholder : undefined}
        readOnly={p.readOnly}
        autoComplete={p.autoComplete}
        @TEXT_INPUT_HANDLER@
      />
      {!labelAbove && (
        <span className="as-field-placeholder" aria-hidden="true">
          <span className="as-field-placeholder-text">{p.placeholder ?? p.label}</span>
        </span>
      )}
      {hasMarker &&
        (p.readOnly || p.disabled ? (
          <span className="as-field-readonly-marker" aria-hidden="true">
            <Icon name="pencilOff" weight="bold" />
          </span>
        ) : p.type === 'password' ? (
          <button
            type="button"
            className="as-field-type-marker as-field-password-action"
            aria-label={p.passwordVisible ? 'Hide password' : 'Show password'}
            aria-pressed={!!p.passwordVisible}
            data-password-visible={p.passwordVisible ? 'true' : 'false'}
            disabled={!p.value.length}
            @PASSWORD_TOGGLE_HANDLER@
          >
            <span className="as-field-action-glyphs" aria-hidden="true">
              <Icon name="key" weight="bold" />
              <span className="as-field-password-toggle-glyphs">
                <Icon name="eye" weight="bold" />
                <Icon name="eyeOff" weight="bold" />
              </span>
            </span>
          </button>
        ) : p.type === 'search' ? (
          <button
            type="button"
            className="as-field-type-marker as-field-search-action"
            data-field-icon={fieldIcon}
            aria-label="Clear search"
            disabled={!p.value.length}
            @SEARCH_CLEAR_HANDLER@
          >
            <span className="as-field-action-glyphs as-field-search-glyphs" aria-hidden="true">
              <Icon name={fieldIcon} weight="bold" />
              <span className="as-field-search-cross">
                <Icon name="close" weight="bold" />
              </span>
            </span>
          </button>
        ) : (
          <span className="as-field-type-marker" data-field-icon={fieldIcon} aria-hidden="true">
            <Icon name={fieldIcon} weight="bold" />
          </span>
        ))}
    </span>
    {(p.error || p.hint) && (
      <span id={p.id + '-description'} className="as-field-description">
        {p.error || p.hint}
      </span>
    )}
  </div>
);
`,
};
