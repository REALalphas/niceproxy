export default {
  name: 'Button',
  group: 'controls',
  sources: ['52:332', '52:407', '52:411', '52:349', '52:347', '52:341'],
  props: `
variant?: 'default' | 'simple' | 'blank' | 'pressed' | 'focused' | 'disabled';
size?: 'sm' | 'md';
width?: 'content' | 'container';
labelWrap?: 'wrap' | 'single-line';
disabled?: boolean;
loading?: boolean;
type?: 'button' | 'submit' | 'reset';
onPress@?: Handler<[]>;
`,
  body: `
return (
  <button
    type={p.type ?? 'button'}
    className={cx('as-button', p.className)}
    data-variant={p.variant ?? 'default'}
    data-size={p.size ?? 'sm'}
    data-width={p.width ?? 'content'}
    data-label-wrap={p.labelWrap ?? 'wrap'}
    data-loading={p.loading ? 'true' : undefined}
    disabled={p.disabled || p.loading || p.variant === 'disabled'}
    aria-busy={p.loading || undefined}
    onClick={p.onPress@}
  >
    {(p.loading || p.disabled || p.variant === 'disabled') && (
      <svg className="as-button-frame" aria-hidden="true">
        <rect />
        <path />
      </svg>
    )}
    <span className="as-button-label">@CHILDREN@</span>
  </button>
);
`,
};
