export default {
  name: 'Switch',
  group: 'controls',
  sources: [],
  status: 'extension',
  props: `
id: string;
label: string;
checked: boolean;
name?: string;
value?: string;
disabled?: boolean;
required?: boolean;
hint?: string;
onCheckedChange@?: Handler<[checked: boolean]>;
`,
  body: `
return (
  <div className={cx('as-choice', p.className)} data-disabled={p.disabled ? 'true' : 'false'}>
    <label className="as-choice-label">
      <input
        className="as-choice-input as-sr-only"
        id={p.id}
        type="checkbox"
        role="switch"
        name={p.name}
        value={p.value}
        checked={p.checked}
        disabled={p.disabled}
        required={p.required}
        aria-describedby={p.hint ? p.id + '-description' : undefined}
        @CHECKED_HANDLER@
      />
      <span className="as-choice-control as-switch" aria-hidden="true">
        <span className="as-switch-thumb" />
      </span>
      <span className="as-choice-text">{p.label}</span>
    </label>
    {p.hint && (
      <span id={p.id + '-description'} className="as-field-description">
        {p.hint}
      </span>
    )}
  </div>
);
`,
};
