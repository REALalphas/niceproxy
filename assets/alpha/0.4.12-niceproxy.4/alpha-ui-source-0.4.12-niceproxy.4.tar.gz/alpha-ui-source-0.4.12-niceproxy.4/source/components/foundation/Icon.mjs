export default {
  name: 'Icon',
  group: 'foundation',
  sources: ['4:86', '66:463'],
  props: `
name: IconName;
label?: string;
weight?: 'regular' | 'bold';
`,
  body: `
return (
  <span
    className={cx('as-icon', p.className)}
    data-icon-weight={p.weight}
    role={p.label ? 'img' : undefined}
    aria-label={p.label}
    aria-hidden={p.label ? undefined : true}
    style={{
      '--as-icon-regular-url': 'url("' + iconsRegular[p.name] + '")',
      '--as-icon-bold-url': 'url("' + icons[p.name] + '")',
    }}
  />
);
`,
};
