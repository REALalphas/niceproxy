export default {
  name: 'ChatButton',
  group: 'chat',
  sources: ['3:464'],
  props: `
variant?: 'plain' | 'emoji' | 'attach' | 'record' | 'send';
icon?: IconName;
label?: string;
pressed?: boolean;
disabled?: boolean;
onPress@?: Handler<[]>;
`,
  body: `
const variant = p.variant ?? 'plain';
const defaults = {
  plain: { icon: 'messageReply', label: 'Reply' },
  emoji: { icon: 'emoji', label: 'Add emoji' },
  attach: { icon: 'attachment', label: 'Attach file' },
  record: { icon: 'microphone', label: 'Record voice message' },
  send: { icon: 'send', label: 'Send' },
} as const;
return (
  <IconButton
    weight="bold"
    className={cx('as-chat-button as-chat-' + variant, p.className)}
    icon={p.icon ?? defaults[variant].icon}
    label={p.label ?? defaults[variant].label}
    pressed={p.pressed}
    disabled={p.disabled}
    onPress@={p.onPress@}
  />
);
`,
};
