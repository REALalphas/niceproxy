export default {
  name: 'ChatComposer',
  group: 'chat',
  sources: [],
  props: `
value: string;
disabled?: boolean;
onValueChange@?: Handler<[string]>;
onSend@?: Handler<[]>;
onAttach@?: Handler<[]>;
onRecord@?: Handler<[]>;
onEmoji@?: Handler<[]>;
`,
  body: `
return (
  <div className={cx('as-chat-composer', p.className)}>
    <ChatInput
      value={p.value}
      disabled={p.disabled}
      onValueChange@={p.onValueChange@}
      onEmoji@={p.onEmoji@}
    >
      {p.onAttach@ && (
        <ChatButton
          variant="attach"
          disabled={p.disabled}
          onPress@={p.onAttach@}
        />
      )}
      <ChatButton
        variant="record"
        disabled={p.disabled}
        onPress@={p.onRecord@}
      />
    </ChatInput>
    <ChatButton
      variant="send"
      disabled={p.disabled || !p.value.trim()}
      onPress@={p.onSend@}
    />
  </div>
);
`,
};
