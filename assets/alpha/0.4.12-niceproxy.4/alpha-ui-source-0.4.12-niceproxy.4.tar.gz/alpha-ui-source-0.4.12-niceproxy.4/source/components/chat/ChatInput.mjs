export default {
  name: 'ChatInput',
  group: 'chat',
  sources: [],
  props: `
value: string;
disabled?: boolean;
placeholder?: string;
onValueChange@?: Handler<[string]>;
onEmoji@?: Handler<[]>;
`,
  body: `
return (
  <div className={cx('as-chat-input-surface', p.className)}>
    {p.onEmoji@ && (
      <ChatButton
        variant="emoji"
        disabled={p.disabled}
        onPress@={p.onEmoji@}
      />
    )}
    <textarea
      className="as-chat-input"
      aria-label="Message"
      placeholder={p.placeholder ?? 'Write a message…'}
      rows={1}
      value={p.value}
      disabled={p.disabled}
      @CHAT_INPUT@
    />
    <div className="as-chat-input-actions">@CHILDREN@</div>
  </div>
);
`,
};
