// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, ChatSurface, ChatThread, ChatMessage } from '@alpha/react';
export function ChatSurfaceExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread>
            <ChatMessage text="Входящее сообщение" />
            <ChatMessage text="Исходящее сообщение" outgoing />
          </ChatThread>
        </ChatSurface>
      </Stack>
    </div>
  );
}
