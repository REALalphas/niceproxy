// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, DrawerDivider, DrawerButton } from '@alpha/react';
export function DrawerDividerExample() {
  const [state, setState] = useState({ selectedId: 'overview' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <DrawerButton
          label="Обзор"
          icon="home"
          selected={state.selectedId === 'overview'}
          onPress={() => update({ selectedId: 'overview' })}
        />
        <DrawerDivider label="Аккаунт" />
        <DrawerButton
          label="Настройки"
          icon="settings"
          selected={state.selectedId === 'settings'}
          onPress={() => update({ selectedId: 'settings' })}
        />
      </Stack>
    </div>
  );
}
