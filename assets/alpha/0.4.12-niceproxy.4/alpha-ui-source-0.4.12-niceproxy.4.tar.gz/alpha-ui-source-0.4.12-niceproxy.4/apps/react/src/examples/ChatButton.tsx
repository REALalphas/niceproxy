// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, ChatSurface, ChatButton, Text } from '@alpha/react';
export function ChatButtonExample() {
  const [state, setState] = useState({ notice: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <Stack direction="row" gap={3}>
            <ChatButton variant="emoji" onPress={() => update({ notice: 'Emoji' })} />
            <ChatButton variant="attach" onPress={() => update({ notice: 'Вложение' })} />
            <ChatButton variant="record" onPress={() => update({ notice: 'Запись' })} />
            <ChatButton variant="send" onPress={() => update({ notice: 'Отправка' })} />
          </Stack>
        </ChatSurface>
        <Text>{state.notice || 'Выберите действие'}</Text>
      </Stack>
    </div>
  );
}
