import { createRoot } from 'react-dom/client';
import { installControlMotion } from '@alpha/core';
import { examples } from './examples';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import '../../shared/examples.css';

const root = document.getElementById('root')!;
const name = new URLSearchParams(location.search).get('component');
if (name && Object.hasOwn(examples, name)) {
  const Example = examples[name as keyof typeof examples];
  document.body.dataset.example = name;
  const disposeMotion = installControlMotion();
  window.addEventListener(
    'pagehide',
    (event) => {
      if (!event.persisted) disposeMotion();
    },
    { once: true },
  );
  if (import.meta.hot) import.meta.hot.dispose(disposeMotion);
  createRoot(root).render(<Example />);
} else root.textContent = 'Select an example on the component page in the documentation.';
