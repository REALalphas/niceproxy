// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, TextInput, Text } from '@alpha/react';
export function TextInputExample() {
  const [state, setState] = useState({ value: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextInput
          id="name"
          label="Name"
          value={state.value}
          hint="Enter a name"
          onValueChange={(value) => update({ value })}
        />
        <Text>Value: {state.value || 'empty'}</Text>
        <TextInput id="disabled-name" label="Disabled field" value="" disabled />
      </Stack>
    </div>
  );
}
