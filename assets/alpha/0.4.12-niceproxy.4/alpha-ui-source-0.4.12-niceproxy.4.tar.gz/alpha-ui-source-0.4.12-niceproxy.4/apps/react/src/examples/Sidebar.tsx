// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Sidebar, Text, type NavItem } from '@alpha/react';
export function SidebarExample() {
  const [state, setState] = useState({ selectedId: 'overview' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));
  const items: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Sidebar
          items={items}
          selectedId={state.selectedId}
          onSelect={(selectedId) => update({ selectedId })}
        />
        <Text>Selected: {state.selectedId}</Text>
      </Stack>
    </div>
  );
}
