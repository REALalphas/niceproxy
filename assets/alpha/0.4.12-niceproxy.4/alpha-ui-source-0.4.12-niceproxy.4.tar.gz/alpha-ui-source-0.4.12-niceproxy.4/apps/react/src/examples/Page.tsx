// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Page, Text, TextInput, Card } from '@alpha/react';
export function PageExample() {
  const [state, setState] = useState({ name: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Page width="form">
          <Text as="h1">Настройки</Text>
          <Card>
            <TextInput
              id="page-name"
              label="Название"
              value={state.name}
              onValueChange={(name) => update({ name })}
            />
          </Card>
        </Page>
      </Stack>
    </div>
  );
}
