// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Switch, Text } from '@alpha/react';
export function SwitchExample() {
  const [state, setState] = useState({ checked: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Switch
          id="notifications"
          label="Notifications"
          checked={state.checked}
          onCheckedChange={(checked) => update({ checked })}
        />
        <Text>{state.checked ? 'Enabled' : 'Disabled'}</Text>
        <Switch
          id="disabled-notifications"
          label="Disabled switch"
          checked={false}
          disabled
        />
      </Stack>
    </div>
  );
}
