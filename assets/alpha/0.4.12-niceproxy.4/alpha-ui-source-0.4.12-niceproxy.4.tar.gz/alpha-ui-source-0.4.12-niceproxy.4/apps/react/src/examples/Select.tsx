// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Select, Text } from '@alpha/react';
export function SelectExample() {
  const [state, setState] = useState({ value: 'react' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));
  const options = [
    { value: 'react', label: 'React' },
    { value: 'qwik', label: 'Qwik' },
    { value: 'unavailable', label: 'Unavailable option', disabled: true },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Select
          id="framework"
          label="Framework"
          value={state.value}
          options={options}
          popup="overlay"
          onValueChange={(value) => update({ value })}
        />
        <Select
          id="native-framework"
          label="Native select"
          value={state.value}
          options={options}
          popup="native"
          onValueChange={(value) => update({ value })}
        />
        <Text>Selected: {state.value}</Text>
      </Stack>
    </div>
  );
}
