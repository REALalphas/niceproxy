// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Profile, Text } from '@alpha/react';
export function ProfileExample() {
  const [state, setState] = useState({ notice: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Stack direction="row" gap={3}>
          <Stack align="start" gap={2}>
            <Text>Default</Text>
            <Profile label="Account" onPress={() => update({ notice: 'Open account' })} />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Loading</Text>
            <Profile label="Loading account" state="loading" />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Unstable</Text>
            <Profile
              label="Unstable connection"
              state="unstable"
              onPress={() => update({ notice: 'Unstable connection' })}
            />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Error</Text>
            <Profile
              label="Account error"
              state="error"
              onPress={() => update({ notice: 'Account error' })}
            />
          </Stack>
        </Stack>
        <Text>{state.notice || 'Profile image is passed by the application via src.'}</Text>
      </Stack>
    </div>
  );
}
