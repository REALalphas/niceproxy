// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, AppShell, Text, type NavItem } from '@alpha/react';
export function AppShellExample() {
  const [state, setState] = useState({ selectedId: 'overview' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));
  const items: NavItem[] = [
    { id: 'overview', label: 'Обзор', icon: 'home' },
    { id: 'settings', label: 'Настройки', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <AppShell
          serviceName="Alpha's UI"
          items={items}
          selectedId={state.selectedId}
          width="container"
          onSelect={(selectedId) => update({ selectedId })}
        >
          <Stack gap={4}>
            <Text as="h2">{items.find((item) => item.id === state.selectedId)?.label}</Text>
            <Text>Содержимое выбранного раздела.</Text>
          </Stack>
        </AppShell>
      </Stack>
    </div>
  );
}
