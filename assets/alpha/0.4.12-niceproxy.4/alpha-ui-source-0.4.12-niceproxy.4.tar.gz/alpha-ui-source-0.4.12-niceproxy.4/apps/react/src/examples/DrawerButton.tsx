// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, DrawerButton } from '@alpha/react';
export function DrawerButtonExample() {
  const [state, setState] = useState({ selected: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <DrawerButton
          label="Настройки"
          icon="settings"
          secondaryText="Дополнительное пояснение под названием"
          secondaryPlacement="below"
          selected={state.selected}
          onPress={() => update({ selected: !state.selected })}
        />
      </Stack>
    </div>
  );
}
