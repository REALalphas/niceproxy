// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, Icon, Text } from '@alpha/react';
export function IconExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Stack direction="row" gap={4}>
          <Icon name="settings" label="Settings" />
          <Icon name="settings" label="Settings, bold" weight="bold" />
          <Icon name="search" label="Search" />
        </Stack>
        <Text>Regular — 1.5, bold — 2; size — 24 × 24 at 16px base.</Text>
      </Stack>
    </div>
  );
}
