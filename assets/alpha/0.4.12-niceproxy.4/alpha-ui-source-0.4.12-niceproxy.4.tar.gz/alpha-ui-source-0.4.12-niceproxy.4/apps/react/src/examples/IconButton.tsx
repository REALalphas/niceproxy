// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, IconButton, Text } from '@alpha/react';
export function IconButtonExample() {
  const [state, setState] = useState({ pressed: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <IconButton
          icon="heart"
          label="Favorite"
          pressed={state.pressed}
          onPress={() => update({ pressed: !state.pressed })}
        />
        <Text>{state.pressed ? 'Selected' : 'Not selected'}</Text>
        <IconButton icon="settings" label="Disabled settings" disabled />
      </Stack>
    </div>
  );
}
