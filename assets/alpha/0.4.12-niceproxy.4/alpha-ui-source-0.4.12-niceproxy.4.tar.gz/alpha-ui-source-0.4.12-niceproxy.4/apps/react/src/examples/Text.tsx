// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, Text } from '@alpha/react';
export function TextExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Text as="h2" size="title">
          Manrope · Heading
        </Text>
        <Text>Noto Sans · Primary interface body text</Text>
        <Text tone="secondary">Additional description</Text>
        <Text font="mono">Fira Code · 384 kHz</Text>
      </Stack>
    </div>
  );
}
