// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, TextArea, Text } from '@alpha/react';
export function TextAreaExample() {
  const [state, setState] = useState({ value: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextArea
          id="description"
          label="Description"
          value={state.value}
          rows={3}
          onValueChange={(value) => update({ value })}
        />
        <Text>Characters: {state.value.length}</Text>
        <TextArea id="disabled-description" label="Disabled field" value="" disabled />
      </Stack>
    </div>
  );
}
