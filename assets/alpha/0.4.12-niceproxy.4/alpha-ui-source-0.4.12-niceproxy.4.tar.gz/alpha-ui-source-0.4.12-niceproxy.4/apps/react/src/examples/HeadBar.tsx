// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, HeadBar, Text } from '@alpha/react';
export function HeadBarExample() {
  const [state, setState] = useState({ value: 'react', context: 'react', notice: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));
  const options = [
    { value: 'react', label: 'React' },
    { value: 'qwik', label: 'Qwik' },
    { value: 'unavailable', label: 'Unavailable option', disabled: true },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <HeadBar
          serviceName="Alpha's UI"
          serviceValue={state.value}
          serviceOptions={options}
          onServiceChange={(value) => update({ value })}
          context={{ label: 'Context', value: state.context, options }}
          onContextChange={(context) => update({ context })}
          onAccountPress={() => update({ notice: 'Open account' })}
        />
        <Text>
          Service: {state.value} · Context: {state.context}
        </Text>
        <Text>{state.notice}</Text>
      </Stack>
    </div>
  );
}
