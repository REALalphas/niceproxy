// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, ChatSurface, ChatComposer, Text } from '@alpha/react';
export function ChatComposerExample() {
  const [state, setState] = useState({ value: '', sent: '', recording: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatComposer
            value={state.value}
            onValueChange={(value) => update({ value })}
            onEmoji={() => update({ value: state.value + '🙂' })}
            onRecord={() => update({ recording: !state.recording })}
            onSend={() => {
              if (state.value.trim()) update({ sent: state.value, value: '' });
            }}
          />
        </ChatSurface>
        <Text>{state.sent ? 'Отправлено локально: ' + state.sent : 'Введите сообщение'}</Text>
        <Text>{state.recording ? 'Выбрана запись голосового сообщения' : 'Запись не выбрана'}</Text>
      </Stack>
    </div>
  );
}
