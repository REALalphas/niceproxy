// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, BottomNav, Text, type NavItem } from '@alpha/react';
export function BottomNavExample() {
  const [state, setState] = useState({ selectedId: 'overview' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));
  const items: NavItem[] = [
    { id: 'overview', label: 'Обзор', icon: 'home' },
    { id: 'settings', label: 'Настройки', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <BottomNav
          items={items}
          selectedId={state.selectedId}
          onSelect={(selectedId) => update({ selectedId })}
        />
        <Text>Выбрано: {state.selectedId}</Text>
      </Stack>
    </div>
  );
}
