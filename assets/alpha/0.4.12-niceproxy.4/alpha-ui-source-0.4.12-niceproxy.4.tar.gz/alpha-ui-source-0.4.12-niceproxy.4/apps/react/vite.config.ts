import { defineConfig } from 'vite';
import { localDemoAssets } from '../shared/local-assets.mjs';
import { fileURLToPath } from 'node:url';
export default defineConfig(({ command, mode }) => ({
  base: './',
  ...localDemoAssets(command),
  ...(mode === 'docs-examples'
    ? {
        build: {
          outDir: 'dist-examples',
          rollupOptions: { input: fileURLToPath(new URL('./examples.html', import.meta.url)) },
        },
      }
    : {}),
}));
