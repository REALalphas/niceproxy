import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';
import { fileURLToPath } from 'node:url';
import { components } from '../../source/components/index.mjs';
import { docsBase, groups } from '../../scripts/lib/docs-site.mjs';

const base = docsBase(process.env.DOCS_BASE_PATH);

export default defineConfig({
  site: process.env.DOCS_SITE_URL || undefined,
  base,
  trailingSlash: 'always',
  vite: {
    plugins: [
      {
        name: 'alpha-docs-lucide-icons',
        enforce: 'pre',
        resolveId(source, importer) {
          if (importer?.includes('/@astrojs/starlight/') && /(?:^|\/)Icon\.astro$/.test(source)) {
            return fileURLToPath(new URL('./src/components/DocsIcon.astro', import.meta.url));
          }
        },
      },
    ],
  },
  integrations: [
    starlight({
      title: "Alpha's UI",
      description: 'React and Qwik UI library. One source, two frameworks.',
      defaultLocale: 'root',
      locales: { root: { label: 'English', lang: 'en' } },
      customCss: ['./src/styles/docs.css'],
      credits: false,
      tableOfContents: false,
      components: {
        Header: './src/components/Header.astro',
        Sidebar: './src/components/Sidebar.astro',
        PageTitle: './src/components/PageTitle.astro',
        ThemeSelect: './src/components/Empty.astro',
        ThemeProvider: './src/components/ThemeProvider.astro',
      },
      expressiveCode: {
        themes: ['github-dark'],
        styleOverrides: {
          codeFontFamily: 'var(--as-font-mono)',
          codeFontSize: '1rem',
          borderRadius: 'var(--as-radius-card)',
          borderColor: 'transparent',
        },
      },
      sidebar: [
        { label: 'Overview', slug: '' },
        {
          label: 'Getting started',
          collapsed: true,
          items: [
            { label: 'Integration', slug: 'guides/agent-guide' },
            { label: 'Installation and updates', slug: 'guides/distribution' },
            { label: 'Consumer app rules', slug: 'guides/consumer-agent-rules' },
          ],
        },
        ...Object.entries(groups).map(([group, label]) => ({
          label,
          collapsed: true,
          items: components
            .filter((component) => component.group === group)
            .map(({ name }) => ({ label: name, slug: `components/${name.toLowerCase()}` })),
        })),
        {
          label: 'Behavior',
          collapsed: true,
          items: [
            { label: 'Buttons', slug: 'guides/buttons' },
            { label: 'Fields and selection', slug: 'guides/forms' },
            { label: 'Icons', slug: 'guides/icons' },
            { label: 'Chat', slug: 'guides/chat' },
            { label: 'Motion', slug: 'guides/motion' },
            { label: 'Qwik containers', slug: 'guides/qwik-containers' },
          ],
        },
        {
          label: 'Development',
          collapsed: true,
          items: [
            { label: 'Verification', slug: 'guides/verification' },
            { label: 'Documentation site', slug: 'guides/documentation' },
            { label: 'Terms of use', slug: 'legal' },
          ],
        },
      ],
    }),
  ],
});
