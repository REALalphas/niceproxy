// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatComposer, Text } from '@alpha/qwik';
export const ChatComposerExample = component$(() => {
  const state = useStore({ value: '', sent: '', recording: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatComposer
            value={state.value}
            onValueChange$={(value) => update({ value })}
            onEmoji$={() => update({ value: state.value + '🙂' })}
            onRecord$={() => update({ recording: !state.recording })}
            onSend$={() => {
              if (state.value.trim()) update({ sent: state.value, value: '' });
            }}
          />
        </ChatSurface>
        <Text>{state.sent ? 'Sent locally: ' + state.sent : 'Enter a message'}</Text>
        <Text>{state.recording ? 'Voice message recording selected' : 'Recording not selected'}</Text>
      </Stack>
    </div>
  );
});
