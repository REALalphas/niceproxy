// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Profile, Text } from '@alpha/qwik';
export const ProfileExample = component$(() => {
  const state = useStore({ notice: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Stack direction="row" gap={3}>
          <Stack align="start" gap={2}>
            <Text>Обычный</Text>
            <Profile label="Аккаунт" onPress$={() => update({ notice: 'Открыть аккаунт' })} />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Загрузка</Text>
            <Profile label="Загрузка аккаунта" state="loading" />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Нестабильно</Text>
            <Profile
              label="Нестабильное соединение"
              state="unstable"
              onPress$={() => update({ notice: 'Нестабильное соединение' })}
            />
          </Stack>
          <Stack align="start" gap={2}>
            <Text>Ошибка</Text>
            <Profile
              label="Ошибка аккаунта"
              state="error"
              onPress$={() => update({ notice: 'Ошибка аккаунта' })}
            />
          </Stack>
        </Stack>
        <Text>{state.notice || 'Изображение профиля передаёт приложение через src.'}</Text>
      </Stack>
    </div>
  );
});
