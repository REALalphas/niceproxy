import { render } from '@builder.io/qwik';
import loaderUrl from '@builder.io/qwik/qwikloader.js?url';
import { installControlMotion } from '@alpha/core';
import { examples } from './examples';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import '../../shared/examples.css';

const root = document.getElementById('root')!;
const name = new URLSearchParams(location.search).get('component');
if (name && Object.hasOwn(examples, name)) {
  const Example = examples[name as keyof typeof examples];
  document.body.dataset.example = name;
  const disposeMotion = installControlMotion();
  window.addEventListener(
    'pagehide',
    (event) => {
      if (!event.persisted) disposeMotion();
    },
    { once: true },
  );
  if (import.meta.hot) import.meta.hot.dispose(disposeMotion);
  if (!root.hasAttribute('q:base')) {
    root.setAttribute('q:base', new URL(/* @vite-ignore */ './', import.meta.url).href);
  }
  const loader = document.createElement('script');
  loader.type = 'module';
  loader.src = loaderUrl;
  loader.onload = () => {
    void render(root, <Example />);
  };
  document.head.appendChild(loader);
} else root.textContent = 'Выберите пример на странице компонента в документации.';
