// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, BottomNav, Text, type NavItem } from '@alpha/qwik';
export const BottomNavExample = component$(() => {
  const state = useStore({ selectedId: 'overview' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });
  const items: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <BottomNav
          items={items}
          selectedId={state.selectedId}
          onSelect$={(selectedId) => update({ selectedId })}
        />
        <Text>Selected: {state.selectedId}</Text>
      </Stack>
    </div>
  );
});
