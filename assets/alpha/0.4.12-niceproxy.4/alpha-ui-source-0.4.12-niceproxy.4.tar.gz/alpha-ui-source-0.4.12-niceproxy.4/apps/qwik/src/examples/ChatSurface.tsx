// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatThread, ChatMessage } from '@alpha/qwik';
export const ChatSurfaceExample = component$(() => {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread>
            <ChatMessage text="Incoming message" />
            <ChatMessage text="Outgoing message" outgoing />
          </ChatThread>
        </ChatSurface>
      </Stack>
    </div>
  );
});
