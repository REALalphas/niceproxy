// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$ } from '@builder.io/qwik';
import { Stack, Text } from '@alpha/qwik';
export const TextExample = component$(() => {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Text as="h2" size="title">
          Manrope · Heading
        </Text>
        <Text>Noto Sans · Primary interface body text</Text>
        <Text tone="secondary">Additional description</Text>
        <Text font="mono">Fira Code · 384 kHz</Text>
      </Stack>
    </div>
  );
});
