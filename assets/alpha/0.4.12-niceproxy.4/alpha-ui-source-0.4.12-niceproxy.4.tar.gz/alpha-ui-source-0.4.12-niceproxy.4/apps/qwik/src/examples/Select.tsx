// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Select, Text } from '@alpha/qwik';
export const SelectExample = component$(() => {
  const state = useStore({ value: 'react' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });
  const options = [
    { value: 'react', label: 'React' },
    { value: 'qwik', label: 'Qwik' },
    { value: 'unavailable', label: 'Недоступный вариант', disabled: true },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Select
          id="framework"
          label="Фреймворк"
          value={state.value}
          options={options}
          popup="overlay"
          onValueChange$={(value) => update({ value })}
        />
        <Select
          id="native-framework"
          label="Системный список"
          value={state.value}
          options={options}
          popup="native"
          onValueChange$={(value) => update({ value })}
        />
        <Text>Выбрано: {state.value}</Text>
      </Stack>
    </div>
  );
});
