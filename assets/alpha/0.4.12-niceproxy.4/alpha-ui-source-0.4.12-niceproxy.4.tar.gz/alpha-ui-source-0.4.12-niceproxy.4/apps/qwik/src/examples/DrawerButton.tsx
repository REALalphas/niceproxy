// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, DrawerButton } from '@alpha/qwik';
export const DrawerButtonExample = component$(() => {
  const state = useStore({ selected: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <DrawerButton
          label="Settings"
          icon="settings"
          secondaryText="Additional description below the label"
          secondaryPlacement="below"
          selected={state.selected}
          onPress$={() => update({ selected: !state.selected })}
        />
      </Stack>
    </div>
  );
});
