// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, TextInput, Text } from '@alpha/qwik';
export const TextInputExample = component$(() => {
  const state = useStore({ value: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextInput
          id="name"
          label="Name"
          value={state.value}
          hint="Enter a name"
          onValueChange$={(value) => update({ value })}
        />
        <Text>Value: {state.value || 'empty'}</Text>
        <TextInput id="disabled-name" label="Disabled field" value="" disabled />
      </Stack>
    </div>
  );
});
