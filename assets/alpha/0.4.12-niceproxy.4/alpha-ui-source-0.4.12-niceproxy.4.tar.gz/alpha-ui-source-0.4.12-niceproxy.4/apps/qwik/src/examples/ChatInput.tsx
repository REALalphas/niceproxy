// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatInput, Text } from '@alpha/qwik';
export const ChatInputExample = component$(() => {
  const state = useStore({ value: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatInput value={state.value} onValueChange$={(value) => update({ value })} />
        </ChatSurface>
        <Text>Символов: {state.value.length}</Text>
      </Stack>
    </div>
  );
});
