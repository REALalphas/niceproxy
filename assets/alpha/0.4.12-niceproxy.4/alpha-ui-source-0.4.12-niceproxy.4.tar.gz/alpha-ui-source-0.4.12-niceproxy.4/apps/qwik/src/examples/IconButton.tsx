// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, IconButton, Text } from '@alpha/qwik';
export const IconButtonExample = component$(() => {
  const state = useStore({ pressed: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <IconButton
          icon="heart"
          label="Favorite"
          pressed={state.pressed}
          onPress$={() => update({ pressed: !state.pressed })}
        />
        <Text>{state.pressed ? 'Selected' : 'Not selected'}</Text>
        <IconButton icon="settings" label="Disabled settings" disabled />
      </Stack>
    </div>
  );
});
