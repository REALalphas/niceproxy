import { render } from '@builder.io/qwik';
import loaderUrl from '@builder.io/qwik/qwikloader.js?url';
import { Demo } from './demo';
import { examples } from './examples';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import '../../shared/demo.css';
import '../../shared/examples.css';
import { installControlMotion } from '@alpha/core';
installControlMotion();
const root = document.getElementById('root')!;
const componentName = new URLSearchParams(window.location.search).get('component');
const Example =
  componentName && Object.hasOwn(examples, componentName)
    ? examples[componentName as keyof typeof examples]
    : undefined;
if (Example) document.body.dataset.example = componentName!;
// The host owns the container base. Default to the emitted module directory,
// which also works when the application is mounted in a subdirectory.
if (!root.hasAttribute('q:base')) {
  root.setAttribute('q:base', new URL(/* @vite-ignore */ './', import.meta.url).href);
}
// Load the upstream event dispatcher as an asset, preserving its side effects.
const loader = document.createElement('script');
loader.type = 'module';
loader.src = loaderUrl;
loader.onload = () => {
  void render(root, Example ? <Example /> : <Demo />);
};
document.head.appendChild(loader);
