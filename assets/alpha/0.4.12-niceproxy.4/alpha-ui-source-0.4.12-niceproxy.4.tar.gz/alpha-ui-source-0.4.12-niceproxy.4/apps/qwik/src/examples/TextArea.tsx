// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, TextArea, Text } from '@alpha/qwik';
export const TextAreaExample = component$(() => {
  const state = useStore({ value: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextArea
          id="description"
          label="Описание"
          value={state.value}
          rows={3}
          onValueChange$={(value) => update({ value })}
        />
        <Text>Символов: {state.value.length}</Text>
        <TextArea id="disabled-description" label="Недоступное поле" value="" disabled />
      </Stack>
    </div>
  );
});
