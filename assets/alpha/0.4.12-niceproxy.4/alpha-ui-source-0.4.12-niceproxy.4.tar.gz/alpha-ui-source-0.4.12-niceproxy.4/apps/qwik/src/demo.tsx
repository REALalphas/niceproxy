// Generated from source/demo/Demo.tsx.template. Run npm run generate; do not edit.
import { component$, useStore, useVisibleTask$, $ } from '@builder.io/qwik';
import { transitionView, waitForViewCommit } from '@alpha/core';
import {
  TextInput,
  TextArea,
  Checkbox,
  Switch,
  Select,
  Picker,
  Icon,
  Logo,
  Text,
  Stack,
  Card,
  Page,
  ChatSurface,
  ChatMessage,
  ChatButton,
  ChatInput,
  ChatThread,
  ChatComposer,
  Badge,
  Button,
  IconButton,
  Profile,
  HeadBar,
  NavButton,
  BottomNav,
  DrawerButton,
  DrawerDivider,
  Sidebar,
  AppShell,
  type NavItem,
} from '@alpha/qwik';
const testProfilePicture1: string | undefined = import.meta.env.ALPHA_TEST_PROFILE_PICTURE_1;
const testProfilePicture2: string | undefined = import.meta.env.ALPHA_TEST_PROFILE_PICTURE_2;
type View = 'catalog' | 'base';
type Category = 'foundation' | 'controls' | 'account' | 'navigation' | 'layout' | 'chat';
const categories: { id: Category; label: string }[] = [
  { id: 'foundation', label: 'Foundation' },
  { id: 'controls', label: 'Controls' },
  { id: 'account', label: 'Account and statuses' },
  { id: 'navigation', label: 'Navigation' },
  { id: 'layout', label: 'Layout' },
  { id: 'chat', label: 'Chat' },
];
type DemoMessage = {
  id: number;
  timestamp: number;
  author: string;
  text: string;
  time: string;
  outgoing?: boolean;
  favorite?: boolean;
};
type DemoState = {
  serviceId: string;
  hostId: string;
  showContext: boolean;
  formName: string;
  formUrl: string;
  formPassword: string;
  formPasswordVisible: boolean;
  formSearch: string;
  formPhone: string;
  formEmail: string;
  formDescription: string;
  formChoice: string;
  formChecked: boolean;
  formEnabled: boolean;
  previewDraft: string;
  draft: string;
  editingId: number | null;
  messages: DemoMessage[];
  view: View;
  category: Category;
  navigationId: string;
  avatar: 1 | 2;
  notice: string;
  clicks: number;
};
// MOCK: demo messages and sending are local browser state; no messages are sent to a server.
// New messages use the real send timestamp; initial messages are fixtures.
const mockReferenceTimestamp = Date.now() - 86400000;
const initial: DemoState = {
  serviceId: 'yonix',
  hostId: 'workstation',
  showContext: true,
  formName: '',
  formUrl: '',
  formPassword: '',
  formPasswordVisible: false,
  formSearch: '',
  formPhone: '',
  formEmail: 'example',
  formDescription: '',
  formChoice: 'react',
  formChecked: false,
  formEnabled: true,
  previewDraft: '',
  draft: '',
  editingId: null,
  messages: [
    {
      id: 1,
      timestamp: mockReferenceTimestamp,
      author: 'Member',
      text: 'lorem ipsum',
      time: '24h',
    },
    {
      id: 2,
      timestamp: mockReferenceTimestamp + 20000,
      author: 'Member',
      text: 'lorem',
      time: '24h',
    },
    {
      id: 3,
      timestamp: mockReferenceTimestamp + 40000,
      author: 'Member',
      text: 'lorem ipsum dolor sit amet',
      time: '24h',
    },
  ],
  view: 'catalog',
  category: 'foundation',
  navigationId: 'overview',
  avatar: 2,
  notice: '',
  clicks: 0,
};
const demoPreferencesKey = 'alpha-ui.demo.tabs';
function readDemoPreferences(): Partial<DemoState> {
  if (typeof window === 'undefined') return {};
  const requestedView = new URLSearchParams(window.location.search).get('view');
  if (requestedView === 'yonix') return { view: 'base' };
  if (requestedView === 'base' || requestedView === 'catalog') return { view: requestedView };
  try {
    const saved = JSON.parse(window.localStorage.getItem(demoPreferencesKey) ?? '{}');
    if (!saved || typeof saved !== 'object') return {};
    return {
      ...(saved.view === 'yonix'
        ? { view: 'base' as View }
        : saved.view === 'catalog' || saved.view === 'base'
          ? { view: saved.view as View }
          : {}),
      ...(categories.some((category) => category.id === saved.category)
        ? { category: saved.category as Category }
        : {}),
    };
  } catch {
    return {};
  }
}
function saveDemoPreferences(patch: Partial<DemoState>) {
  if (typeof window === 'undefined' || (!patch.view && !patch.category)) return;
  try {
    window.localStorage.setItem(
      demoPreferencesKey,
      JSON.stringify({
        ...readDemoPreferences(),
        ...(patch.view ? { view: patch.view } : {}),
        ...(patch.category ? { category: patch.category } : {}),
      }),
    );
  } catch {
    /* The demo stays usable when browser storage is unavailable. */
  }
}
const views: View[] = ['catalog', 'base'];
const labels: Record<View, string> = { base: 'Example', catalog: 'Components' };
const items: NavItem[] = [
  { id: 'base', label: 'Base', icon: 'home' },
  { id: 'catalog', label: 'Components', icon: 'settings' },
];
const navigationItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: 'home', notifications: '1' },
  { id: 'activity', label: 'Activity', icon: 'chart' },
  { id: 'settings', label: 'Settings', icon: 'settings', group: 'Account' },
];
const serviceOptions = [
  { value: 'yonix', label: 'Yonix' },
  { value: 'storyteller', label: 'Storyteller' },
];
const hostOptions = [
  { value: 'workstation', label: 'Workstation' },
  { value: 'server', label: 'Home server' },
  { value: 'long', label: 'Workstation — very long managed machine name' },
  { value: 'offline', label: 'Unavailable machine', disabled: true },
];
const bodyText =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut et massa mi. Aliquam in hendrerit urna.';
export const Demo = component$(() => {
  const state = useStore<DemoState>({ ...initial, ...readDemoPreferences() });
  useVisibleTask$(
    () => {
      Object.assign(state, readDemoPreferences());
    },
    { strategy: 'document-ready' },
  );
  const update = $(async (patch: Partial<DemoState>) => {
    saveDemoPreferences(patch);
    if (patch.view && patch.view !== state.view) {
      const root = document.querySelector('.demo')!;
      await transitionView(async () => {
        const committed = waitForViewCommit(root, 'data-view', patch.view!);
        Object.assign(state, patch);
        await committed;
      });
    } else Object.assign(state, patch);
  });
  const navItems = items;
  return (
    <div className="demo alpha-ui" data-view={state.view}>
      <header className="demo-toolbar">
        <div className="demo-brand">
          <Logo />
          <strong>Alpha's UI</strong>
        </div>
        <nav className="demo-page-nav" aria-label="Test page section">
          {views.map((view) => (
            <Button
              key={view}
              variant={state.view === view ? 'default' : 'simple'}
              onPress$={() => update({ view })}
            >
              {labels[view]}
            </Button>
          ))}
        </nav>
      </header>
      <div className="as-view" data-as-view="demo-screen">
        {state.view === 'catalog' ? (
          <div className="demo-catalog">
            <div className="demo-catalog-heading">
              <Text as="h1" size="heading">
                Component catalog
              </Text>
              <Text tone="secondary">29 components · React / Qwik · Tauri / Electron</Text>
              <Text size="sm" tone="muted">
                6 categories: foundation, controls, account, navigation, layout, and chat.
              </Text>
            </div>
            <div
              className="demo-category-nav"
              role="tablist"
              aria-label="Component categories"
              aria-orientation="horizontal"
            >
              {categories.map((category) => (
                <button
                  key={category.id}
                  type="button"
                  role="tab"
                  id={'tab-' + category.id}
                  aria-selected={state.category === category.id}
                  aria-controls={'category-' + category.id}
                  tabIndex={state.category === category.id ? 0 : -1}
                  onClick$={() => update({ category: category.id })}
                  onKeyDown$={async (event, el) => {
                    const offset =
                      event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
                    if (!offset && event.key !== 'Home' && event.key !== 'End') return;
                    event.preventDefault();
                    const index = categories.findIndex((item) => item.id === category.id);
                    const next =
                      event.key === 'Home'
                        ? 0
                        : event.key === 'End'
                          ? categories.length - 1
                          : (index + offset + categories.length) % categories.length;
                    el.parentElement
                      ?.querySelectorAll<HTMLButtonElement>('[role="tab"]')
                      [next]?.focus();
                    await update({ category: categories[next].id });
                  }}
                >
                  {category.label}
                </button>
              ))}
            </div>
            <div className="demo-categories">
              <section
                className="demo-category"
                id="category-foundation"
                role="tabpanel"
                aria-labelledby="tab-foundation"
                hidden={state.category !== 'foundation'}
              >
                <header>
                  <h2 id="title-foundation">Foundation</h2>
                  <Text tone="secondary">Text · Icon · Logo</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Typography</Text>
                    <Stack gap={5}>
                      <Text as="h3">Manrope · Heading</Text>
                      <Text>
                        Noto Sans · Primary interface body text. The quick brown fox jumps over the lazy
                        dog.
                      </Text>
                      <Text font="mono" size="sm">
                        Fira Code · 889 Mbit/s · 32Bit · 384kHz
                      </Text>
                      <Text tone="secondary" size="sm">
                        Secondary label
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Icon · Logo</Text>
                    <Stack direction="row" align="center">
                      <Logo />
                      <Icon name="settings" />
                      <Icon name="settings" weight="bold" />
                    </Stack>
                    <div className="demo-icon-grid">
                      {(
                        [
                          'book-open',
                          'compass',
                          'backpack',
                          'shield',
                          'wallet',
                          'music',
                          'key',
                          'search',
                          'settings',
                          'downloadFile',
                          'uploadFile',
                          'heart',
                          'check',
                          'globe',
                          'chart',
                        ] as const
                      ).map((name) => (
                        <IconButton
                          key={name}
                          icon={name}
                          label={name}
                          onPress$={() => update({ notice: 'Lucide: ' + name })}
                        />
                      ))}
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Palette and surfaces</Text>
                    <div className="demo-swatch-grid">
                      {['canvas', 'overlay', 'navigation', 'primary', 'selected', 'danger'].map(
                        (name) => (
                          <div key={name} className="demo-swatch">
                            <span style={{ background: 'var(--as-color-' + name + ')' }} />
                            {name}
                          </div>
                        ),
                      )}
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-controls"
                role="tabpanel"
                aria-labelledby="tab-controls"
                hidden={state.category !== 'controls'}
              >
                <header>
                  <h2 id="title-controls">Controls</h2>
                  <Text tone="secondary">
                    Button · IconButton · TextInput · TextArea · Checkbox · Switch · Select · Picker
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Button</Text>
                    <Stack gap={4}>
                      <Stack className="demo-variants" direction="row" gap={3}>
                        {(['default', 'simple', 'blank', 'pressed', 'focused'] as const).map(
                          (variant) => (
                            <Stack key={variant} gap={2}>
                              <Text size="sm" tone="secondary">
                                {variant.charAt(0).toUpperCase() + variant.slice(1)}
                              </Text>
                              <Button
                                variant={variant}
                                onPress$={() => update({ clicks: state.clicks + 1 })}
                              >
                                Test button
                              </Button>
                            </Stack>
                          ),
                        )}
                        <Stack className="demo-loading-comparison" direction="row" gap={3}>
                          <Stack gap={2}>
                            <Text size="sm" tone="secondary">
                              Disabled
                            </Text>
                            <Button disabled>Test button</Button>
                          </Stack>
                          <Stack gap={2}>
                            <Text size="sm" tone="secondary">
                              Loading
                            </Text>
                            <Button loading>Test button</Button>
                          </Stack>
                        </Stack>
                      </Stack>
                      <Text tone="secondary" size="sm">
                        Clicks: {state.clicks}
                      </Text>
                      <Text tone="muted" size="sm">
                        Default · Simple · Blank · Pressed · Focused · Disabled — Figma variants;
                        Loading — loading state. Hover, click, and test Tab.
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Input fields</Text>
                    <Stack gap={5}>
                      <TextInput
                        id="demo-name"
                        label="Name"
                        hint="Name that the user will see"
                        value={state.formName}
                        onValueChange$={(formName) => update({ formName })}
                      />
                      <TextInput
                        id="demo-url"
                        type="url"
                        label="Link"
                        value={state.formUrl}
                        onValueChange$={(formUrl) => update({ formUrl })}
                      />
                      <TextInput
                        id="demo-password"
                        type="password"
                        passwordVisible={state.formPasswordVisible}
                        onPasswordVisibleChange$={(formPasswordVisible) =>
                          update({ formPasswordVisible })
                        }
                        label="Password"
                        value={state.formPassword}
                        onValueChange$={(formPassword) => update({ formPassword })}
                      />
                      <TextInput
                        id="demo-search"
                        type="search"
                        label="Search"
                        value={state.formSearch}
                        onValueChange$={(formSearch) => update({ formSearch })}
                      />
                      <TextInput
                        id="demo-phone"
                        type="tel"
                        label="Phone"
                        value={state.formPhone}
                        onValueChange$={(formPhone) => update({ formPhone })}
                      />
                      <TextArea
                        id="demo-description"
                        label="Description"
                        value={state.formDescription}
                        onValueChange$={(formDescription) => update({ formDescription })}
                      />
                      <TextArea
                        id="demo-description-corner"
                        resize="both"
                        label="Description with corner handle"
                        value={state.formDescription}
                        onValueChange$={(formDescription) => update({ formDescription })}
                      />
                      <TextInput
                        id="demo-invalid"
                        label="Email address"
                        type="email"
                        value={state.formEmail}
                        onValueChange$={(formEmail) => update({ formEmail })}
                        error={
                          state.formEmail.includes(String.fromCharCode(64)) &&
                          state.formEmail
                            .slice(state.formEmail.indexOf(String.fromCharCode(64)) + 1)
                            .includes('.')
                            ? undefined
                            : 'Enter a full email address'
                        }
                      />
                      <TextInput
                        id="demo-disabled"
                        label="Disabled field"
                        value="Editing is disabled"
                        disabled
                      />
                      <TextArea
                        id="demo-disabled-multiline"
                        label="Disabled multiline field"
                        value={'Editing is disabled\nMultiple lines of text'}
                        disabled
                      />
                      <TextInput
                        id="demo-readonly"
                        label="Read only"
                        value="Can be selected and copied"
                        readOnly
                      />
                      <TextArea
                        id="demo-readonly-multiline"
                        label="Read-only multiline field"
                        value={'Can be selected and copied\nMultiple lines of text'}
                        readOnly
                      />
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Choice</Text>
                    <Stack gap={5}>
                      <Checkbox
                        id="demo-checkbox"
                        label="Save choice for future sessions and other open windows"
                        checked={state.formChecked}
                        onCheckedChange$={(formChecked) => update({ formChecked })}
                      />
                      <Switch
                        id="demo-switch"
                        label="Enable notifications"
                        checked={state.formEnabled}
                        onCheckedChange$={(formEnabled) => update({ formEnabled })}
                      />
                      <Select
                        id="demo-select"
                        popup="overlay"
                        label="Adapter"
                        options={[
                          { value: 'react', label: 'React' },
                          { value: 'qwik', label: 'Qwik' },
                          { value: 'unavailable', label: 'Unavailable option', disabled: true },
                        ]}
                        value={state.formChoice}
                        onValueChange$={(formChoice) => update({ formChoice })}
                      />
                      <Picker
                        id="demo-picker"
                        label="Context"
                        value={state.hostId}
                        options={hostOptions}
                        onValueChange$={(hostId) => update({ hostId })}
                      />
                      <Picker
                        id="demo-picker-disabled"
                        label="Disabled context"
                        value="workstation"
                        options={hostOptions}
                        disabled
                      />
                      <Picker
                        id="demo-picker-empty"
                        label="Empty context"
                        value=""
                        options={[]}
                        placeholder="No available options"
                      />
                      <Picker
                        id="demo-picker-unknown"
                        label="Unknown context"
                        value="missing"
                        options={hostOptions}
                        placeholder="Select context"
                      />
                      <Checkbox
                        id="demo-checkbox-disabled"
                        label="Disabled checkbox"
                        checked
                        disabled
                      />
                      <Switch
                        id="demo-switch-disabled"
                        label="Disabled switch"
                        checked={false}
                        disabled
                      />
                      <Select
                        id="demo-select-disabled"
                        label="Disabled select"
                        options={[{ value: 'react', label: 'React' }]}
                        value="react"
                        disabled
                      />
                      <Text tone="secondary">
                        {state.formChecked ? 'Selected' : 'Not selected'} ·{' '}
                        {state.formEnabled ? 'Enabled' : 'Disabled'} · {state.formChoice}
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">IconButton</Text>
                    <div className="demo-icon-grid">
                      {(
                        [
                          'book-open',
                          'compass',
                          'backpack',
                          'shield',
                          'wallet',
                          'music',
                          'key',
                          'search',
                          'settings',
                          'downloadFile',
                          'uploadFile',
                          'heart',
                          'check',
                          'globe',
                          'chart',
                        ] as const
                      ).map((name) => (
                        <IconButton
                          key={name}
                          icon={name}
                          label={name}
                          onPress$={() => update({ notice: 'Lucide: ' + name })}
                        />
                      ))}
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-account"
                role="tabpanel"
                aria-labelledby="tab-account"
                hidden={state.category !== 'account'}
              >
                <header>
                  <h2 id="title-account">Account and statuses</h2>
                  <Text tone="secondary">Profile · Badge</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Profile</Text>
                    <div className="demo-avatar-switch" role="group" aria-label="Test avatar">
                      {([1, 2] as const).map((avatar) => (
                        <button
                          key={avatar}
                          type="button"
                          className="as-button"
                          data-variant={state.avatar === avatar ? 'default' : 'simple'}
                          aria-pressed={state.avatar === avatar}
                          onClick$={() => update({ avatar })}
                        >
                          Avatar {avatar}
                        </button>
                      ))}
                    </div>
                    <div className="demo-profile-preview">
                      {(['default', 'loading', 'unstable', 'error'] as const).map(
                        (profileState) => (
                          <Profile
                            key={profileState}
                            src={state.avatar === 1 ? testProfilePicture1 : testProfilePicture2}
                            state={profileState}
                            onPress$={() => update({ notice: 'Account' })}
                          />
                        ),
                      )}
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Badge</Text>
                    <Stack direction="row" align="center">
                      <Badge value="3" />
                      <Badge value="12" />
                      <Badge value="99+" />
                    </Stack>
                    <Stack direction="row" align="center">
                      <NavButton label="Notifications" icon="settings" notifications="3" selected />
                      <Text tone="secondary">Notification counter in navigation</Text>
                    </Stack>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-navigation"
                role="tabpanel"
                aria-labelledby="tab-navigation"
                hidden={state.category !== 'navigation'}
              >
                <header>
                  <h2 id="title-navigation">Navigation</h2>
                  <Text tone="secondary">
                    HeadBar · NavButton · BottomNav · DrawerButton · DrawerDivider · Sidebar
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">HeadBar · Sidebar · BottomNav</Text>
                    <div className="demo-navigation-stage">
                      <AppShell
                        serviceName="Service"
                        accountSrc={testProfilePicture2}
                        items={navigationItems}
                        selectedId={state.navigationId}
                        onSelect$={(id) => update({ navigationId: id })}
                        onServicePress$={() => update({ notice: 'Select service' })}
                        onAccountPress$={() => update({ notice: 'Account settings' })}
                      >
                        <Stack className="demo-navigation-content" gap={4}>
                          <Text as="h3">
                            {navigationItems.find((item) => item.id === state.navigationId)?.label}
                          </Text>
                          <Text tone="secondary">
                            Header bar with profile, navigation, and content area.
                          </Text>
                        </Stack>
                      </AppShell>
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">DrawerButton · DrawerDivider</Text>
                    <div className="demo-drawer-preview">
                      <DrawerButton label="Overview" icon="home" selected secondaryText="1" />
                      <DrawerButton label="Activity" icon="chart" />
                      <DrawerDivider label="Account" />
                      <DrawerButton label="Settings" icon="settings" />
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-layout"
                role="tabpanel"
                aria-labelledby="tab-layout"
                hidden={state.category !== 'layout'}
              >
                <header>
                  <h2 id="title-layout">Layout</h2>
                  <Text tone="secondary">Stack · Card · AppShell</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Stack · Card</Text>
                    <Card>
                      <Stack gap={4}>
                        <Text>Card with vertical layout</Text>
                        <Stack direction="row" gap={3}>
                          <Button>Action</Button>
                          <Button variant="simple">Cancel</Button>
                        </Stack>
                      </Stack>
                    </Card>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">AppShell</Text>
                    <Text tone="secondary">
                      Application shell: header, sidebar and bottom navigation, content area.
                    </Text>
                    <Button variant="simple" onPress$={() => update({ view: 'base' })}>
                      Open example
                    </Button>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-chat"
                role="tabpanel"
                aria-labelledby="tab-chat"
                hidden={state.category !== 'chat'}
              >
                <header>
                  <h2>Chat</h2>
                  <Text tone="secondary">
                    ChatMessage · ChatButton · ChatInput · ChatComposer · ChatThread · ChatSurface
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h3">ChatMessage</Text>
                    <ChatSurface>
                      <ChatThread>
                        <ChatMessage
                          text="lorem ipsum"
                          timestamp={mockReferenceTimestamp}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem ipsum dolor"
                          timestamp={mockReferenceTimestamp + 20000}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem"
                          timestamp={mockReferenceTimestamp + 40000}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem"
                          timestamp={mockReferenceTimestamp + 71000}
                          time="1h"
                          outgoing
                          onReply$={() => update({ notice: 'Reply' })}
                        />
                      </ChatThread>
                    </ChatSurface>
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatButton</Text>
                    <Stack direction="row" gap={3}>
                      {(['emoji', 'attach', 'record', 'send'] as const).map((variant) => (
                        <Stack key={variant} gap={2}>
                          <Text>{variant}</Text>
                          <ChatButton
                            variant={variant}
                            onPress$={() => update({ notice: variant })}
                          />
                        </Stack>
                      ))}
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatInput</Text>
                    <ChatInput
                      value={state.previewDraft}
                      onValueChange$={(previewDraft) => update({ previewDraft })}
                    />
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatThread · ChatSurface</Text>
                    <ChatSurface>
                      <ChatThread>
                        <ChatMessage text="lorem" outgoing />
                        <ChatMessage text="lorem ipsum" outgoing />
                      </ChatThread>
                    </ChatSurface>
                  </section>
                  <section className="demo-section demo-chat-composer-preview">
                    <Text as="h3">ChatComposer</Text>
                    <ChatSurface>
                      <ChatComposer
                        value={state.previewDraft}
                        onValueChange$={(previewDraft) => update({ previewDraft })}
                        onEmoji$={() => update({ previewDraft: state.previewDraft + '🙂' })}
                        onSend$={() => update({ previewDraft: '' })}
                      />
                    </ChatSurface>
                  </section>
                </div>
                <section className="demo-section demo-chat-example">
                  <Text as="h3">Assembled chat</Text>
                  <ChatSurface className="demo-chat">
                    <ChatThread>
                      {state.messages.map((message) => (
                        <ChatMessage
                          key={message.id}
                          author={message.author}
                          text={message.text}
                          time={message.time}
                          timestamp={message.timestamp}
                          outgoing={message.outgoing}
                          favorite={message.favorite}
                          onFavorite$={() =>
                            update({
                              messages: state.messages.map((item) =>
                                item.id === message.id
                                  ? { ...item, favorite: !item.favorite }
                                  : item,
                              ),
                            })
                          }
                          onReply$={() =>
                            update({ draft: message.author + ': ' + message.text + '\n' })
                          }
                          onEdit$={() => update({ draft: message.text, editingId: message.id })}
                          onDownload$={() => {
                            const url = URL.createObjectURL(
                              new Blob([message.text], { type: 'text/plain;charset=utf-8' }),
                            );
                            const link = document.createElement('a');
                            link.href = url;
                            link.download = 'message-' + message.id + '.txt';
                            link.click();
                            URL.revokeObjectURL(url);
                          }}
                          onForward$={() =>
                            update({ draft: 'Forwarded: ' + message.text, editingId: null })
                          }
                        />
                      ))}
                    </ChatThread>
                    <input
                      className="demo-chat-file"
                      type="file"
                      hidden
                      onChange$={(_, el) => {
                        const file = el.files?.[0];
                        if (file) update({ notice: 'Selected file: ' + file.name });
                        el.value = '';
                      }}
                    />
                    <ChatComposer
                      onEmoji$={() => update({ draft: state.draft + '🙂' })}
                      onAttach$={() =>
                        document.querySelector<HTMLInputElement>('.demo-chat-file')?.click()
                      }
                      value={state.draft}
                      onValueChange$={(draft) => update({ draft })}
                      onSend$={() => {
                        const text = state.draft.trim();
                        if (!text) return;
                        const sentAt = Date.now();
                        update({
                          draft: '',
                          editingId: null,
                          messages:
                            state.editingId !== null
                              ? state.messages.map((message) =>
                                  message.id === state.editingId ? { ...message, text } : message,
                                )
                              : [
                                  ...state.messages,
                                  {
                                    id: state.messages.length + 1,
                                    timestamp: sentAt,
                                    author: 'You',
                                    text,
                                    time: '',
                                    outgoing: true,
                                  },
                                ],
                        });
                      }}
                    />
                  </ChatSurface>
                </section>
              </section>
            </div>
          </div>
        ) : (
          <div className="demo-stage">
            <AppShell
              width="container"
              serviceName={
                serviceOptions.find((option) => option.value === state.serviceId)?.label ?? 'Yonix'
              }
              serviceValue={state.serviceId}
              serviceOptions={serviceOptions}
              onServiceChange$={(serviceId) => update({ serviceId })}
              context={
                state.showContext
                  ? { label: 'Managed machine', value: state.hostId, options: hostOptions }
                  : undefined
              }
              onContextChange$={(hostId) => update({ hostId })}
              accountSrc={testProfilePicture2}
              items={navItems}
              selectedId={state.view}
              onSelect$={(id) => update({ view: id as View })}
              onAccountPress$={() => update({ notice: 'Account settings' })}
            >
              {state.view === 'base' && (
                <div className="demo-content">
                  <Stack gap={4}>
                    <Checkbox
                      id="demo-show-context"
                      label="Additional picker in header"
                      checked={state.showContext}
                      onCheckedChange$={(showContext) => update({ showContext })}
                    />
                    <Text>
                      Service:{' '}
                      {serviceOptions.find((option) => option.value === state.serviceId)?.label}
                    </Text>
                    {state.showContext && (
                      <Text>
                        Machine: {hostOptions.find((option) => option.value === state.hostId)?.label}
                      </Text>
                    )}
                  </Stack>
                  <Text as="h1" size="heading">
                    Lorem ipsum dolor sit amet.
                  </Text>
                  <Text tone="muted">{bodyText}</Text>
                  <Button onPress$={() => update({ notice: 'App action' })}>
                    Test button
                  </Button>
                  <Text as="h2" size="heading">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </Text>
                  <Text tone="muted">
                    {bodyText} Pellentesque sit amet sapien fringilla, mattis ligula consectetur,
                    ultrices mauris.
                  </Text>
                </div>
              )}
            </AppShell>
          </div>
        )}
      </div>
      {state.notice && (
        <div className="demo-toast" role="status">
          <Stack direction="row" align="center" gap={3}>
            <Text size="sm">{state.notice}</Text>
            <IconButton
              icon="close"
              label="Dismiss notification"
              onPress$={() => update({ notice: '' })}
            />
          </Stack>
        </div>
      )}
    </div>
  );
});
