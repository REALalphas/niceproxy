// Generated from source/demo/Demo.tsx.template. Run npm run generate; do not edit.
import { component$, useStore, useVisibleTask$, $ } from '@builder.io/qwik';
import { transitionView, waitForViewCommit } from '@alpha/core';
import {
  TextInput,
  TextArea,
  Checkbox,
  Switch,
  Select,
  Picker,
  Icon,
  Logo,
  Text,
  Stack,
  Card,
  Page,
  ChatSurface,
  ChatMessage,
  ChatButton,
  ChatInput,
  ChatThread,
  ChatComposer,
  Badge,
  Button,
  IconButton,
  Profile,
  HeadBar,
  NavButton,
  BottomNav,
  DrawerButton,
  DrawerDivider,
  Sidebar,
  AppShell,
  type NavItem,
} from '@alpha/qwik';
const testProfilePicture1: string | undefined = import.meta.env.ALPHA_TEST_PROFILE_PICTURE_1;
const testProfilePicture2: string | undefined = import.meta.env.ALPHA_TEST_PROFILE_PICTURE_2;
type View = 'catalog' | 'base';
type Category = 'foundation' | 'controls' | 'account' | 'navigation' | 'layout' | 'chat';
const categories: { id: Category; label: string }[] = [
  { id: 'foundation', label: 'Основы' },
  { id: 'controls', label: 'Действия' },
  { id: 'account', label: 'Аккаунт и статусы' },
  { id: 'navigation', label: 'Навигация' },
  { id: 'layout', label: 'Компоновка' },
  { id: 'chat', label: 'Чат' },
];
type DemoMessage = {
  id: number;
  timestamp: number;
  author: string;
  text: string;
  time: string;
  outgoing?: boolean;
  favorite?: boolean;
};
type DemoState = {
  serviceId: string;
  hostId: string;
  showContext: boolean;
  formName: string;
  formUrl: string;
  formPassword: string;
  formPasswordVisible: boolean;
  formSearch: string;
  formPhone: string;
  formEmail: string;
  formDescription: string;
  formChoice: string;
  formChecked: boolean;
  formEnabled: boolean;
  previewDraft: string;
  draft: string;
  editingId: number | null;
  messages: DemoMessage[];
  view: View;
  category: Category;
  navigationId: string;
  avatar: 1 | 2;
  notice: string;
  clicks: number;
};
// MOCK: demo messages and sending are local browser state; no messages are sent to a server.
// New messages use the real send timestamp; initial messages are fixtures.
const mockReferenceTimestamp = Date.now() - 86400000;
const initial: DemoState = {
  serviceId: 'yonix',
  hostId: 'workstation',
  showContext: true,
  formName: '',
  formUrl: '',
  formPassword: '',
  formPasswordVisible: false,
  formSearch: '',
  formPhone: '',
  formEmail: 'example',
  formDescription: '',
  formChoice: 'react',
  formChecked: false,
  formEnabled: true,
  previewDraft: '',
  draft: '',
  editingId: null,
  messages: [
    {
      id: 1,
      timestamp: mockReferenceTimestamp,
      author: 'Участник',
      text: 'lorem ipsum',
      time: '24h',
    },
    {
      id: 2,
      timestamp: mockReferenceTimestamp + 20000,
      author: 'Участник',
      text: 'lorem',
      time: '24h',
    },
    {
      id: 3,
      timestamp: mockReferenceTimestamp + 40000,
      author: 'Участник',
      text: 'lorem ipsum dolor sit amet',
      time: '24h',
    },
  ],
  view: 'catalog',
  category: 'foundation',
  navigationId: 'overview',
  avatar: 2,
  notice: '',
  clicks: 0,
};
const demoPreferencesKey = 'alpha-ui.demo.tabs';
function readDemoPreferences(): Partial<DemoState> {
  if (typeof window === 'undefined') return {};
  const requestedView = new URLSearchParams(window.location.search).get('view');
  if (requestedView === 'yonix') return { view: 'base' };
  if (requestedView === 'base' || requestedView === 'catalog') return { view: requestedView };
  try {
    const saved = JSON.parse(window.localStorage.getItem(demoPreferencesKey) ?? '{}');
    if (!saved || typeof saved !== 'object') return {};
    return {
      ...(saved.view === 'yonix'
        ? { view: 'base' as View }
        : saved.view === 'catalog' || saved.view === 'base'
          ? { view: saved.view as View }
          : {}),
      ...(categories.some((category) => category.id === saved.category)
        ? { category: saved.category as Category }
        : {}),
    };
  } catch {
    return {};
  }
}
function saveDemoPreferences(patch: Partial<DemoState>) {
  if (typeof window === 'undefined' || (!patch.view && !patch.category)) return;
  try {
    window.localStorage.setItem(
      demoPreferencesKey,
      JSON.stringify({
        ...readDemoPreferences(),
        ...(patch.view ? { view: patch.view } : {}),
        ...(patch.category ? { category: patch.category } : {}),
      }),
    );
  } catch {
    /* The demo stays usable when browser storage is unavailable. */
  }
}
const views: View[] = ['catalog', 'base'];
const labels: Record<View, string> = { base: 'Пример', catalog: 'Компоненты' };
const items: NavItem[] = [
  { id: 'base', label: 'Base', icon: 'home' },
  { id: 'catalog', label: 'Components', icon: 'settings' },
];
const navigationItems: NavItem[] = [
  { id: 'overview', label: 'Обзор', icon: 'home', notifications: '1' },
  { id: 'activity', label: 'Активность', icon: 'chart' },
  { id: 'settings', label: 'Настройки', icon: 'settings', group: 'Аккаунт' },
];
const serviceOptions = [
  { value: 'yonix', label: 'Yonix' },
  { value: 'storyteller', label: 'Storyteller' },
];
const hostOptions = [
  { value: 'workstation', label: 'Рабочая станция' },
  { value: 'server', label: 'Домашний сервер' },
  { value: 'long', label: 'Рабочая станция — очень длинное название управляемой машины' },
  { value: 'offline', label: 'Недоступная машина', disabled: true },
];
const bodyText =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut et massa mi. Aliquam in hendrerit urna.';
export const Demo = component$(() => {
  const state = useStore<DemoState>({ ...initial, ...readDemoPreferences() });
  useVisibleTask$(
    () => {
      Object.assign(state, readDemoPreferences());
    },
    { strategy: 'document-ready' },
  );
  const update = $(async (patch: Partial<DemoState>) => {
    saveDemoPreferences(patch);
    if (patch.view && patch.view !== state.view) {
      const root = document.querySelector('.demo')!;
      await transitionView(async () => {
        const committed = waitForViewCommit(root, 'data-view', patch.view!);
        Object.assign(state, patch);
        await committed;
      });
    } else Object.assign(state, patch);
  });
  const navItems = items;
  return (
    <div className="demo alpha-ui" data-view={state.view}>
      <header className="demo-toolbar">
        <div className="demo-brand">
          <Logo />
          <strong>Alpha's UI</strong>
        </div>
        <nav className="demo-page-nav" aria-label="Раздел тестовой страницы">
          {views.map((view) => (
            <Button
              key={view}
              variant={state.view === view ? 'default' : 'simple'}
              onPress$={() => update({ view })}
            >
              {labels[view]}
            </Button>
          ))}
        </nav>
      </header>
      <div className="as-view" data-as-view="demo-screen">
        {state.view === 'catalog' ? (
          <div className="demo-catalog">
            <div className="demo-catalog-heading">
              <Text as="h1" size="heading">
                Каталог компонентов
              </Text>
              <Text tone="secondary">29 компонентов · React / Qwik · Tauri / Electron</Text>
              <Text size="sm" tone="muted">
                6 категорий: основы, действия, аккаунт, навигация, компоновка и чат.
              </Text>
            </div>
            <div
              className="demo-category-nav"
              role="tablist"
              aria-label="Категории компонентов"
              aria-orientation="horizontal"
            >
              {categories.map((category) => (
                <button
                  key={category.id}
                  type="button"
                  role="tab"
                  id={'tab-' + category.id}
                  aria-selected={state.category === category.id}
                  aria-controls={'category-' + category.id}
                  tabIndex={state.category === category.id ? 0 : -1}
                  onClick$={() => update({ category: category.id })}
                  onKeyDown$={async (event, el) => {
                    const offset =
                      event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
                    if (!offset && event.key !== 'Home' && event.key !== 'End') return;
                    event.preventDefault();
                    const index = categories.findIndex((item) => item.id === category.id);
                    const next =
                      event.key === 'Home'
                        ? 0
                        : event.key === 'End'
                          ? categories.length - 1
                          : (index + offset + categories.length) % categories.length;
                    el.parentElement
                      ?.querySelectorAll<HTMLButtonElement>('[role="tab"]')
                      [next]?.focus();
                    await update({ category: categories[next].id });
                  }}
                >
                  {category.label}
                </button>
              ))}
            </div>
            <div className="demo-categories">
              <section
                className="demo-category"
                id="category-foundation"
                role="tabpanel"
                aria-labelledby="tab-foundation"
                hidden={state.category !== 'foundation'}
              >
                <header>
                  <h2 id="title-foundation">Основы</h2>
                  <Text tone="secondary">Text · Icon · Logo</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Типографика</Text>
                    <Stack gap={5}>
                      <Text as="h3">Manrope · Заголовок</Text>
                      <Text>
                        Noto Sans · Основной текст интерфейса. Съешь ещё этих мягких французских
                        булок.
                      </Text>
                      <Text font="mono" size="sm">
                        Fira Code · 889 Mbit/s · 32Bit · 384kHz
                      </Text>
                      <Text tone="secondary" size="sm">
                        Вторичная подпись
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Icon · Logo</Text>
                    <Stack direction="row" align="center">
                      <Logo />
                      <Icon name="settings" />
                      <Icon name="settings" weight="bold" />
                    </Stack>
                    <div className="demo-icon-grid">
                      {(
                        [
                          'book-open',
                          'compass',
                          'backpack',
                          'shield',
                          'wallet',
                          'music',
                          'key',
                          'search',
                          'settings',
                          'downloadFile',
                          'uploadFile',
                          'heart',
                          'check',
                          'globe',
                          'chart',
                        ] as const
                      ).map((name) => (
                        <IconButton
                          key={name}
                          icon={name}
                          label={name}
                          onPress$={() => update({ notice: 'Lucide: ' + name })}
                        />
                      ))}
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Палитра и поверхности</Text>
                    <div className="demo-swatch-grid">
                      {['canvas', 'overlay', 'navigation', 'primary', 'selected', 'danger'].map(
                        (name) => (
                          <div key={name} className="demo-swatch">
                            <span style={{ background: 'var(--as-color-' + name + ')' }} />
                            {name}
                          </div>
                        ),
                      )}
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-controls"
                role="tabpanel"
                aria-labelledby="tab-controls"
                hidden={state.category !== 'controls'}
              >
                <header>
                  <h2 id="title-controls">Действия</h2>
                  <Text tone="secondary">
                    Button · IconButton · TextInput · TextArea · Checkbox · Switch · Select · Picker
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Button</Text>
                    <Stack gap={4}>
                      <Stack className="demo-variants" direction="row" gap={3}>
                        {(['default', 'simple', 'blank', 'pressed', 'focused'] as const).map(
                          (variant) => (
                            <Stack key={variant} gap={2}>
                              <Text size="sm" tone="secondary">
                                {variant.charAt(0).toUpperCase() + variant.slice(1)}
                              </Text>
                              <Button
                                variant={variant}
                                onPress$={() => update({ clicks: state.clicks + 1 })}
                              >
                                Test button
                              </Button>
                            </Stack>
                          ),
                        )}
                        <Stack className="demo-loading-comparison" direction="row" gap={3}>
                          <Stack gap={2}>
                            <Text size="sm" tone="secondary">
                              Disabled
                            </Text>
                            <Button disabled>Test button</Button>
                          </Stack>
                          <Stack gap={2}>
                            <Text size="sm" tone="secondary">
                              Loading
                            </Text>
                            <Button loading>Test button</Button>
                          </Stack>
                        </Stack>
                      </Stack>
                      <Text tone="secondary" size="sm">
                        Нажатий: {state.clicks}
                      </Text>
                      <Text tone="muted" size="sm">
                        Default · Simple · Blank · Pressed · Focused · Disabled — варианты из Figma;
                        Loading — состояние загрузки. Наведи курсор, нажми и проверь Tab.
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Поля ввода</Text>
                    <Stack gap={5}>
                      <TextInput
                        id="demo-name"
                        label="Название"
                        hint="Название, которое увидит пользователь"
                        value={state.formName}
                        onValueChange$={(formName) => update({ formName })}
                      />
                      <TextInput
                        id="demo-url"
                        type="url"
                        label="Ссылка"
                        value={state.formUrl}
                        onValueChange$={(formUrl) => update({ formUrl })}
                      />
                      <TextInput
                        id="demo-password"
                        type="password"
                        passwordVisible={state.formPasswordVisible}
                        onPasswordVisibleChange$={(formPasswordVisible) =>
                          update({ formPasswordVisible })
                        }
                        label="Пароль"
                        value={state.formPassword}
                        onValueChange$={(formPassword) => update({ formPassword })}
                      />
                      <TextInput
                        id="demo-search"
                        type="search"
                        label="Поиск"
                        value={state.formSearch}
                        onValueChange$={(formSearch) => update({ formSearch })}
                      />
                      <TextInput
                        id="demo-phone"
                        type="tel"
                        label="Телефон"
                        value={state.formPhone}
                        onValueChange$={(formPhone) => update({ formPhone })}
                      />
                      <TextArea
                        id="demo-description"
                        label="Описание"
                        value={state.formDescription}
                        onValueChange$={(formDescription) => update({ formDescription })}
                      />
                      <TextArea
                        id="demo-description-corner"
                        resize="both"
                        label="Описание с угловой ручкой"
                        value={state.formDescription}
                        onValueChange$={(formDescription) => update({ formDescription })}
                      />
                      <TextInput
                        id="demo-invalid"
                        label="Адрес электронной почты"
                        type="email"
                        value={state.formEmail}
                        onValueChange$={(formEmail) => update({ formEmail })}
                        error={
                          state.formEmail.includes(String.fromCharCode(64)) &&
                          state.formEmail
                            .slice(state.formEmail.indexOf(String.fromCharCode(64)) + 1)
                            .includes('.')
                            ? undefined
                            : 'Введите полный адрес электронной почты'
                        }
                      />
                      <TextInput
                        id="demo-disabled"
                        label="Недоступное поле"
                        value="Редактирование отключено"
                        disabled
                      />
                      <TextArea
                        id="demo-disabled-multiline"
                        label="Недоступное многострочное поле"
                        value={'Редактирование отключено\nНесколько строк текста'}
                        disabled
                      />
                      <TextInput
                        id="demo-readonly"
                        label="Только чтение"
                        value="Можно выделить и скопировать"
                        readOnly
                      />
                      <TextArea
                        id="demo-readonly-multiline"
                        label="Многострочное поле только для чтения"
                        value={'Можно выделить и скопировать\nНесколько строк текста'}
                        readOnly
                      />
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Выбор</Text>
                    <Stack gap={5}>
                      <Checkbox
                        id="demo-checkbox"
                        label="Сохранить выбор для следующих сеансов и других открытых окон"
                        checked={state.formChecked}
                        onCheckedChange$={(formChecked) => update({ formChecked })}
                      />
                      <Switch
                        id="demo-switch"
                        label="Включить уведомления"
                        checked={state.formEnabled}
                        onCheckedChange$={(formEnabled) => update({ formEnabled })}
                      />
                      <Select
                        id="demo-select"
                        popup="overlay"
                        label="Адаптер"
                        options={[
                          { value: 'react', label: 'React' },
                          { value: 'qwik', label: 'Qwik' },
                          { value: 'unavailable', label: 'Недоступный вариант', disabled: true },
                        ]}
                        value={state.formChoice}
                        onValueChange$={(formChoice) => update({ formChoice })}
                      />
                      <Picker
                        id="demo-picker"
                        label="Контекст"
                        value={state.hostId}
                        options={hostOptions}
                        onValueChange$={(hostId) => update({ hostId })}
                      />
                      <Picker
                        id="demo-picker-disabled"
                        label="Недоступный контекст"
                        value="workstation"
                        options={hostOptions}
                        disabled
                      />
                      <Picker
                        id="demo-picker-empty"
                        label="Пустой контекст"
                        value=""
                        options={[]}
                        placeholder="Нет доступных вариантов"
                      />
                      <Picker
                        id="demo-picker-unknown"
                        label="Неизвестный контекст"
                        value="missing"
                        options={hostOptions}
                        placeholder="Выберите контекст"
                      />
                      <Checkbox
                        id="demo-checkbox-disabled"
                        label="Недоступный выбор"
                        checked
                        disabled
                      />
                      <Switch
                        id="demo-switch-disabled"
                        label="Недоступное переключение"
                        checked={false}
                        disabled
                      />
                      <Select
                        id="demo-select-disabled"
                        label="Недоступный список"
                        options={[{ value: 'react', label: 'React' }]}
                        value="react"
                        disabled
                      />
                      <Text tone="secondary">
                        {state.formChecked ? 'Выбрано' : 'Не выбрано'} ·{' '}
                        {state.formEnabled ? 'Включено' : 'Выключено'} · {state.formChoice}
                      </Text>
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">IconButton</Text>
                    <div className="demo-icon-grid">
                      {(
                        [
                          'book-open',
                          'compass',
                          'backpack',
                          'shield',
                          'wallet',
                          'music',
                          'key',
                          'search',
                          'settings',
                          'downloadFile',
                          'uploadFile',
                          'heart',
                          'check',
                          'globe',
                          'chart',
                        ] as const
                      ).map((name) => (
                        <IconButton
                          key={name}
                          icon={name}
                          label={name}
                          onPress$={() => update({ notice: 'Lucide: ' + name })}
                        />
                      ))}
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-account"
                role="tabpanel"
                aria-labelledby="tab-account"
                hidden={state.category !== 'account'}
              >
                <header>
                  <h2 id="title-account">Аккаунт и статусы</h2>
                  <Text tone="secondary">Profile · Badge</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Profile</Text>
                    <div className="demo-avatar-switch" role="group" aria-label="Тестовая аватарка">
                      {([1, 2] as const).map((avatar) => (
                        <button
                          key={avatar}
                          type="button"
                          className="as-button"
                          data-variant={state.avatar === avatar ? 'default' : 'simple'}
                          aria-pressed={state.avatar === avatar}
                          onClick$={() => update({ avatar })}
                        >
                          Аватарка {avatar}
                        </button>
                      ))}
                    </div>
                    <div className="demo-profile-preview">
                      {(['default', 'loading', 'unstable', 'error'] as const).map(
                        (profileState) => (
                          <Profile
                            key={profileState}
                            src={state.avatar === 1 ? testProfilePicture1 : testProfilePicture2}
                            state={profileState}
                            onPress$={() => update({ notice: 'Аккаунт' })}
                          />
                        ),
                      )}
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">Badge</Text>
                    <Stack direction="row" align="center">
                      <Badge value="3" />
                      <Badge value="12" />
                      <Badge value="99+" />
                    </Stack>
                    <Stack direction="row" align="center">
                      <NavButton label="Уведомления" icon="settings" notifications="3" selected />
                      <Text tone="secondary">Счётчик уведомлений в навигации</Text>
                    </Stack>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-navigation"
                role="tabpanel"
                aria-labelledby="tab-navigation"
                hidden={state.category !== 'navigation'}
              >
                <header>
                  <h2 id="title-navigation">Навигация</h2>
                  <Text tone="secondary">
                    HeadBar · NavButton · BottomNav · DrawerButton · DrawerDivider · Sidebar
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">HeadBar · Sidebar · BottomNav</Text>
                    <div className="demo-navigation-stage">
                      <AppShell
                        serviceName="Service"
                        accountSrc={testProfilePicture2}
                        items={navigationItems}
                        selectedId={state.navigationId}
                        onSelect$={(id) => update({ navigationId: id })}
                        onServicePress$={() => update({ notice: 'Выбор сервиса' })}
                        onAccountPress$={() => update({ notice: 'Настройки аккаунта' })}
                      >
                        <Stack className="demo-navigation-content" gap={4}>
                          <Text as="h3">
                            {navigationItems.find((item) => item.id === state.navigationId)?.label}
                          </Text>
                          <Text tone="secondary">
                            Шапка с профилем, навигация и область содержимого.
                          </Text>
                        </Stack>
                      </AppShell>
                    </div>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">DrawerButton · DrawerDivider</Text>
                    <div className="demo-drawer-preview">
                      <DrawerButton label="Обзор" icon="home" selected secondaryText="1" />
                      <DrawerButton label="Активность" icon="chart" />
                      <DrawerDivider label="Аккаунт" />
                      <DrawerButton label="Настройки" icon="settings" />
                    </div>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-layout"
                role="tabpanel"
                aria-labelledby="tab-layout"
                hidden={state.category !== 'layout'}
              >
                <header>
                  <h2 id="title-layout">Компоновка</h2>
                  <Text tone="secondary">Stack · Card · AppShell</Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h2">Stack · Card</Text>
                    <Card>
                      <Stack gap={4}>
                        <Text>Карточка с вертикальной компоновкой</Text>
                        <Stack direction="row" gap={3}>
                          <Button>Действие</Button>
                          <Button variant="simple">Отмена</Button>
                        </Stack>
                      </Stack>
                    </Card>
                  </section>
                  <section className="demo-section">
                    <Text as="h2">AppShell</Text>
                    <Text tone="secondary">
                      Каркас приложения: шапка, боковая и нижняя навигация, область содержимого.
                    </Text>
                    <Button variant="simple" onPress$={() => update({ view: 'base' })}>
                      Открыть пример
                    </Button>
                  </section>
                </div>
              </section>
              <section
                className="demo-category"
                id="category-chat"
                role="tabpanel"
                aria-labelledby="tab-chat"
                hidden={state.category !== 'chat'}
              >
                <header>
                  <h2>Чат</h2>
                  <Text tone="secondary">
                    ChatMessage · ChatButton · ChatInput · ChatComposer · ChatThread · ChatSurface
                  </Text>
                </header>
                <div className="demo-grid">
                  <section className="demo-section">
                    <Text as="h3">ChatMessage</Text>
                    <ChatSurface>
                      <ChatThread>
                        <ChatMessage
                          text="lorem ipsum"
                          timestamp={mockReferenceTimestamp}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem ipsum dolor"
                          timestamp={mockReferenceTimestamp + 20000}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem"
                          timestamp={mockReferenceTimestamp + 40000}
                          time="24h"
                        />
                        <ChatMessage
                          text="lorem"
                          timestamp={mockReferenceTimestamp + 71000}
                          time="1h"
                          outgoing
                          onReply$={() => update({ notice: 'Ответить' })}
                        />
                      </ChatThread>
                    </ChatSurface>
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatButton</Text>
                    <Stack direction="row" gap={3}>
                      {(['emoji', 'attach', 'record', 'send'] as const).map((variant) => (
                        <Stack key={variant} gap={2}>
                          <Text>{variant}</Text>
                          <ChatButton
                            variant={variant}
                            onPress$={() => update({ notice: variant })}
                          />
                        </Stack>
                      ))}
                    </Stack>
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatInput</Text>
                    <ChatInput
                      value={state.previewDraft}
                      onValueChange$={(previewDraft) => update({ previewDraft })}
                    />
                  </section>
                  <section className="demo-section">
                    <Text as="h3">ChatThread · ChatSurface</Text>
                    <ChatSurface>
                      <ChatThread>
                        <ChatMessage text="lorem" outgoing />
                        <ChatMessage text="lorem ipsum" outgoing />
                      </ChatThread>
                    </ChatSurface>
                  </section>
                  <section className="demo-section demo-chat-composer-preview">
                    <Text as="h3">ChatComposer</Text>
                    <ChatSurface>
                      <ChatComposer
                        value={state.previewDraft}
                        onValueChange$={(previewDraft) => update({ previewDraft })}
                        onEmoji$={() => update({ previewDraft: state.previewDraft + '🙂' })}
                        onSend$={() => update({ previewDraft: '' })}
                      />
                    </ChatSurface>
                  </section>
                </div>
                <section className="demo-section demo-chat-example">
                  <Text as="h3">Собранный чат</Text>
                  <ChatSurface className="demo-chat">
                    <ChatThread>
                      {state.messages.map((message) => (
                        <ChatMessage
                          key={message.id}
                          author={message.author}
                          text={message.text}
                          time={message.time}
                          timestamp={message.timestamp}
                          outgoing={message.outgoing}
                          favorite={message.favorite}
                          onFavorite$={() =>
                            update({
                              messages: state.messages.map((item) =>
                                item.id === message.id
                                  ? { ...item, favorite: !item.favorite }
                                  : item,
                              ),
                            })
                          }
                          onReply$={() =>
                            update({ draft: message.author + ': ' + message.text + '\n' })
                          }
                          onEdit$={() => update({ draft: message.text, editingId: message.id })}
                          onDownload$={() => {
                            const url = URL.createObjectURL(
                              new Blob([message.text], { type: 'text/plain;charset=utf-8' }),
                            );
                            const link = document.createElement('a');
                            link.href = url;
                            link.download = 'message-' + message.id + '.txt';
                            link.click();
                            URL.revokeObjectURL(url);
                          }}
                          onForward$={() =>
                            update({ draft: 'Переслано: ' + message.text, editingId: null })
                          }
                        />
                      ))}
                    </ChatThread>
                    <input
                      className="demo-chat-file"
                      type="file"
                      hidden
                      onChange$={(_, el) => {
                        const file = el.files?.[0];
                        if (file) update({ notice: 'Выбран файл: ' + file.name });
                        el.value = '';
                      }}
                    />
                    <ChatComposer
                      onEmoji$={() => update({ draft: state.draft + '🙂' })}
                      onAttach$={() =>
                        document.querySelector<HTMLInputElement>('.demo-chat-file')?.click()
                      }
                      value={state.draft}
                      onValueChange$={(draft) => update({ draft })}
                      onSend$={() => {
                        const text = state.draft.trim();
                        if (!text) return;
                        const sentAt = Date.now();
                        update({
                          draft: '',
                          editingId: null,
                          messages:
                            state.editingId !== null
                              ? state.messages.map((message) =>
                                  message.id === state.editingId ? { ...message, text } : message,
                                )
                              : [
                                  ...state.messages,
                                  {
                                    id: state.messages.length + 1,
                                    timestamp: sentAt,
                                    author: 'Вы',
                                    text,
                                    time: '',
                                    outgoing: true,
                                  },
                                ],
                        });
                      }}
                    />
                  </ChatSurface>
                </section>
              </section>
            </div>
          </div>
        ) : (
          <div className="demo-stage">
            <AppShell
              width="container"
              serviceName={
                serviceOptions.find((option) => option.value === state.serviceId)?.label ?? 'Yonix'
              }
              serviceValue={state.serviceId}
              serviceOptions={serviceOptions}
              onServiceChange$={(serviceId) => update({ serviceId })}
              context={
                state.showContext
                  ? { label: 'Управляемая машина', value: state.hostId, options: hostOptions }
                  : undefined
              }
              onContextChange$={(hostId) => update({ hostId })}
              accountSrc={testProfilePicture2}
              items={navItems}
              selectedId={state.view}
              onSelect$={(id) => update({ view: id as View })}
              onAccountPress$={() => update({ notice: 'Настройки аккаунта' })}
            >
              {state.view === 'base' && (
                <div className="demo-content">
                  <Stack gap={4}>
                    <Checkbox
                      id="demo-show-context"
                      label="Дополнительный пикер в шапке"
                      checked={state.showContext}
                      onCheckedChange$={(showContext) => update({ showContext })}
                    />
                    <Text>
                      Сервис:{' '}
                      {serviceOptions.find((option) => option.value === state.serviceId)?.label}
                    </Text>
                    {state.showContext && (
                      <Text>
                        Машина: {hostOptions.find((option) => option.value === state.hostId)?.label}
                      </Text>
                    )}
                  </Stack>
                  <Text as="h1" size="heading">
                    Lorem ipsum dolor sit amet.
                  </Text>
                  <Text tone="muted">{bodyText}</Text>
                  <Button onPress$={() => update({ notice: 'Действие приложения' })}>
                    Test button
                  </Button>
                  <Text as="h2" size="heading">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </Text>
                  <Text tone="muted">
                    {bodyText} Pellentesque sit amet sapien fringilla, mattis ligula consectetur,
                    ultrices mauris.
                  </Text>
                </div>
              )}
            </AppShell>
          </div>
        )}
      </div>
      {state.notice && (
        <div className="demo-toast" role="status">
          <Stack direction="row" align="center" gap={3}>
            <Text size="sm">{state.notice}</Text>
            <IconButton
              icon="close"
              label="Dismiss notification"
              onPress$={() => update({ notice: '' })}
            />
          </Stack>
        </div>
      )}
    </div>
  );
});
