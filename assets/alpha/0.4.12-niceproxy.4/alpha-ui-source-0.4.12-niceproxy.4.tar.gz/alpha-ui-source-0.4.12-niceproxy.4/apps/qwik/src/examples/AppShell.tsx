// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, AppShell, Text, type NavItem } from '@alpha/qwik';
export const AppShellExample = component$(() => {
  const state = useStore({ selectedId: 'overview' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });
  const items: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <AppShell
          serviceName="Alpha's UI"
          items={items}
          selectedId={state.selectedId}
          width="container"
          onSelect$={(selectedId) => update({ selectedId })}
        >
          <Stack gap={4}>
            <Text as="h2">{items.find((item) => item.id === state.selectedId)?.label}</Text>
            <Text>Content of the selected section.</Text>
          </Stack>
        </AppShell>
      </Stack>
    </div>
  );
});
