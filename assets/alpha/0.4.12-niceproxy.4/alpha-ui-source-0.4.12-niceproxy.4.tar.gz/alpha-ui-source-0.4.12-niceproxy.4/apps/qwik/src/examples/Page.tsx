// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Page, Text, TextInput, Card } from '@alpha/qwik';
export const PageExample = component$(() => {
  const state = useStore({ name: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Page width="form">
          <Text as="h1">Настройки</Text>
          <Card>
            <TextInput
              id="page-name"
              label="Название"
              value={state.name}
              onValueChange$={(name) => update({ name })}
            />
          </Card>
        </Page>
      </Stack>
    </div>
  );
});
