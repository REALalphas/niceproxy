// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatThread, ChatMessage } from '@alpha/qwik';
export const ChatThreadExample = component$(() => {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread label="Conversation example">
            <ChatMessage text="First message" />
            <ChatMessage text="Next message" />
            <ChatMessage text="Reply" outgoing />
          </ChatThread>
        </ChatSurface>
      </Stack>
    </div>
  );
});
