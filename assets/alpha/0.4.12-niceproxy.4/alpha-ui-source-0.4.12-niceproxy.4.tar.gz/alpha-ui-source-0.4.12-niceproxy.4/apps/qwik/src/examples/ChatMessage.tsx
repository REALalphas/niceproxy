// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatThread, ChatMessage, Text } from '@alpha/qwik';
export const ChatMessageExample = component$(() => {
  const state = useStore({ favorite: false, notice: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread>
            <ChatMessage
              text="Hover or navigate to actions with Tab"
              favorite={state.favorite}
              onFavorite$={() => update({ favorite: !state.favorite })}
              onReply$={() => update({ notice: 'Selected action: Reply' })}
            />
          </ChatThread>
        </ChatSurface>
        <Text>{state.favorite ? 'Favorited' : 'Not favorited'}</Text>
        <Text>{state.notice}</Text>
      </Stack>
    </div>
  );
});
