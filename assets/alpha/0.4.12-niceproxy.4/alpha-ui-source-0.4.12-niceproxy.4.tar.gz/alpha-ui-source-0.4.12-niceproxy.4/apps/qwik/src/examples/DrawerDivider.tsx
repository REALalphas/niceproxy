// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, DrawerDivider, DrawerButton } from '@alpha/qwik';
export const DrawerDividerExample = component$(() => {
  const state = useStore({ selectedId: 'overview' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <DrawerButton
          label="Обзор"
          icon="home"
          selected={state.selectedId === 'overview'}
          onPress$={() => update({ selectedId: 'overview' })}
        />
        <DrawerDivider label="Аккаунт" />
        <DrawerButton
          label="Настройки"
          icon="settings"
          selected={state.selectedId === 'settings'}
          onPress$={() => update({ selectedId: 'settings' })}
        />
      </Stack>
    </div>
  );
});
