// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Switch, Card, Text } from '@alpha/qwik';
export const StackExample = component$(() => {
  const state = useStore({ horizontal: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Switch
          id="direction"
          label="Horizontal direction"
          checked={state.horizontal}
          onCheckedChange$={(horizontal) => update({ horizontal })}
        />
        <Stack direction={state.horizontal ? 'row' : 'column'} gap={4}>
          <Card>
            <Text>First block</Text>
          </Card>
          <Card>
            <Text>Second block</Text>
          </Card>
          <Card>
            <Text>Third block</Text>
          </Card>
        </Stack>
      </Stack>
    </div>
  );
});
