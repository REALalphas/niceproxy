// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { TextInputExample } from './TextInput';
import { TextAreaExample } from './TextArea';
import { CheckboxExample } from './Checkbox';
import { SwitchExample } from './Switch';
import { SelectExample } from './Select';
import { PickerExample } from './Picker';
import { IconExample } from './Icon';
import { LogoExample } from './Logo';
import { TextExample } from './Text';
import { StackExample } from './Stack';
import { CardExample } from './Card';
import { PageExample } from './Page';
import { ChatSurfaceExample } from './ChatSurface';
import { ChatMessageExample } from './ChatMessage';
import { ChatButtonExample } from './ChatButton';
import { ChatInputExample } from './ChatInput';
import { ChatThreadExample } from './ChatThread';
import { ChatComposerExample } from './ChatComposer';
import { BadgeExample } from './Badge';
import { ButtonExample } from './Button';
import { IconButtonExample } from './IconButton';
import { ProfileExample } from './Profile';
import { HeadBarExample } from './HeadBar';
import { NavButtonExample } from './NavButton';
import { BottomNavExample } from './BottomNav';
import { DrawerButtonExample } from './DrawerButton';
import { DrawerDividerExample } from './DrawerDivider';
import { SidebarExample } from './Sidebar';
import { AppShellExample } from './AppShell';
export const examples = {
  TextInput: TextInputExample,
  TextArea: TextAreaExample,
  Checkbox: CheckboxExample,
  Switch: SwitchExample,
  Select: SelectExample,
  Picker: PickerExample,
  Icon: IconExample,
  Logo: LogoExample,
  Text: TextExample,
  Stack: StackExample,
  Card: CardExample,
  Page: PageExample,
  ChatSurface: ChatSurfaceExample,
  ChatMessage: ChatMessageExample,
  ChatButton: ChatButtonExample,
  ChatInput: ChatInputExample,
  ChatThread: ChatThreadExample,
  ChatComposer: ChatComposerExample,
  Badge: BadgeExample,
  Button: ButtonExample,
  IconButton: IconButtonExample,
  Profile: ProfileExample,
  HeadBar: HeadBarExample,
  NavButton: NavButtonExample,
  BottomNav: BottomNavExample,
  DrawerButton: DrawerButtonExample,
  DrawerDivider: DrawerDividerExample,
  Sidebar: SidebarExample,
  AppShell: AppShellExample,
};
