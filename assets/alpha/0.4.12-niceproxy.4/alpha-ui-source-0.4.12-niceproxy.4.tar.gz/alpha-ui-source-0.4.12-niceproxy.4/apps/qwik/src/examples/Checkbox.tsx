// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Checkbox, Text } from '@alpha/qwik';
export const CheckboxExample = component$(() => {
  const state = useStore({ checked: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Checkbox
          id="choice"
          label="Save choice for future sessions and other open windows"
          checked={state.checked}
          onCheckedChange$={(checked) => update({ checked })}
        />
        <Text>{state.checked ? 'Selected' : 'Not selected'}</Text>
        <Checkbox id="disabled-choice" label="Unavailable option" checked={false} disabled />
      </Stack>
    </div>
  );
});
