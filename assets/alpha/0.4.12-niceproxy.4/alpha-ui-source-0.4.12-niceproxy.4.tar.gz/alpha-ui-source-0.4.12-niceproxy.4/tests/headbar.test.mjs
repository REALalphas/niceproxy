import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement as h } from 'react';
import { renderToStaticMarkup as render } from 'react-dom/server';
import { HeadBar, AppShell, Picker, Select } from '../packages/react/dist/index.js';

const services = [
  { value: 'yonix', label: 'Yonix' },
  { value: 'storyteller', label: 'Storyteller' },
];
const context = {
  label: 'Машина',
  value: 'server',
  options: [
    { value: 'desktop', label: 'Рабочая станция' },
    { value: 'server', label: 'Сервер' },
  ],
};

test('HeadBar and AppShell keep independent controlled service and optional context pickers', () => {
  for (const Component of [HeadBar, AppShell]) {
    const html = render(
      h(Component, {
        serviceName: 'Yonix',
        serviceValue: 'yonix',
        serviceOptions: services,
        context,
        items: [],
        selectedId: '',
      }),
    );
    assert.equal((html.match(/<select /g) ?? []).length, 2);
    assert.match(html, /data-select-variant="service"/);
    assert.match(html, /<label[^>]*>Сервис<\/label>/);
    assert.match(html, /<label[^>]*>Машина<\/label>/);
    assert.match(html, /<option value="yonix"[^>]*selected="">Yonix<\/option>/);
    assert.match(html, /<option value="server"[^>]*selected="">Сервер<\/option>/);
    const controls = [...html.matchAll(/<select[^>]* id="([^"]+)"/g)].map((match) => match[1]);
    assert.equal(new Set(controls).size, 2);
    controls.forEach((id) => assert.ok(html.includes('for="' + id + '"')));
    const withoutContext = render(
      h(Component, {
        serviceName: 'Yonix',
        serviceValue: 'yonix',
        serviceOptions: services,
        items: [],
        selectedId: '',
      }),
    );
    assert.equal((withoutContext.match(/<select /g) ?? []).length, 1);
  }
});

test('legacy HeadBar preserves its service action without requiring picker options', () => {
  const html = render(h(HeadBar, { serviceName: 'Service', onServicePress: () => {} }));
  assert.match(html, /class="as-service"/);
  assert.match(html, /Switch service: Service/);
  assert.doesNotMatch(html, /<select /);
});

test('Picker exposes unknown values as placeholder and disables empty/unavailable choices', () => {
  const unknown = render(
    h(Picker, {
      id: 'context',
      label: 'Машина',
      value: 'missing',
      options: services,
      placeholder: 'Выберите машину',
    }),
  );
  assert.match(unknown, /<option value="" disabled=""[^>]*selected="">Выберите машину<\/option>/);
  assert.doesNotMatch(unknown, /aria-selected="true"/);
  for (const options of [[], [{ value: 'none', label: 'Недоступно', disabled: true }]]) {
    const html = render(h(Picker, { label: 'Машина', value: '', options }));
    assert.match(html, /<select[^>]*disabled=""/);
  }
});

test('Select keeps its field default and native semantics in compact variants', () => {
  for (const variant of [undefined, 'plain', 'service']) {
    const html = render(
      h(Select, { id: 'adapter', label: 'Адаптер', value: 'yonix', options: services, variant }),
    );
    assert.equal((html.match(/<select /g) ?? []).length, 1);
    assert.match(html, /<label[^>]*for="adapter">Адаптер<\/label>/);
    assert.match(html, /<option value="yonix"[^>]*selected="">Yonix<\/option>/);
    assert.match(html, new RegExp('data-select-variant="' + (variant ?? 'field') + '"'));
    if (variant) assert.match(html, /class="as-sr-only"/);
    else assert.match(html, /class="as-field-label"/);
  }
});
