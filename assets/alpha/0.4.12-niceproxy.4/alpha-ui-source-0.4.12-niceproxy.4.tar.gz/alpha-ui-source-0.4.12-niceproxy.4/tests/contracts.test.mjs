import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import * as ui from '../packages/react/dist/index.js';
import { formatTime, clamp } from '../packages/core/dist/index.js';
import { components } from '../source/components/index.mjs';
import { iconFiles } from '../source/resources/icons.mjs';

test('both packages export the same canonical component names', async () => {
  const qwik = await import('../packages/qwik/dist/index.qwik.mjs');
  for (const { name } of components) {
    assert.equal(typeof ui[name], 'function', name + ' React export');
    assert.equal(typeof qwik[name], 'function', name + ' Qwik export');
  }
});
test('tokens enforce the agreed font roles', async () => {
  const { font } = JSON.parse(await readFile('packages/core/src/tokens.json', 'utf8'));
  assert.match(font.ui, /^'Noto Sans Variable'/);
  assert.match(font.heading, /^'Manrope Variable'/);
  assert.match(font.mono, /^'Fira Code Variable'/);
});

test('button sizing preserves labels and loading action semantics', () => {
  const label = 'Very long action label';
  const html = renderToStaticMarkup(
    createElement(
      ui.Button,
      { width: 'container', labelWrap: 'single-line', loading: true },
      label,
    ),
  );
  assert.match(html, /data-width="container"/);
  assert.match(html, /data-label-wrap="single-line"/);
  assert.ok(html.includes(label));
  assert.match(html, /disabled=""/);
  assert.match(html, /aria-busy="true"/);
  assert.match(html, /as-button-frame/);
  assert.doesNotMatch(html, /as-spinner/);
  const disabled = renderToStaticMarkup(createElement(ui.Button, { disabled: true }, label));
  assert.match(disabled, /as-button-frame/);
  assert.doesNotMatch(disabled, /aria-busy/);
  const content = renderToStaticMarkup(createElement(ui.Button, {}, 'Short'));
  assert.match(content, /data-width="content"/);
  assert.match(content, /data-label-wrap="wrap"/);
});

test('semantic story icons have named and decorative accessibility', () => {
  for (const name of ['book-open', 'compass', 'backpack']) {
    assert.equal(iconFiles[name], name);
    assert.match(renderToStaticMarkup(createElement(ui.Icon, { name })), /aria-hidden="true"/);
    const named = renderToStaticMarkup(
      createElement(ui.Icon, { name, label: 'Semantic icon', weight: 'bold' }),
    );
    assert.match(named, /role="img"/);
    assert.match(named, /aria-label="Semantic icon"/);
  }
});
test('all local design assets and Lucide icons exist and are non-empty', async () => {
  const assets = JSON.parse(await readFile('source/resources/assets.json', 'utf8'));
  for (const { file } of Object.values(assets)) assert.ok((await stat(file)).size > 0, file);
  for (const file of new Set(Object.values(iconFiles))) {
    const svg = await readFile(`packages/core/dist/icons/${file}.svg`, 'utf8');
    assert.match(svg, /stroke-width="2"/);
    assert.match(svg, /viewBox="0 0 24 24"/);
  }
});
test('loading controls cannot submit actions and headings use Manrope', () => {
  const html = renderToStaticMarkup(createElement(ui.Button, { loading: true }, 'Save'));
  assert.match(html, /disabled=""/);
  assert.match(html, /aria-busy="true"/);
  assert.match(html, /type="button"/);
  const heading = renderToStaticMarkup(createElement(ui.Text, { as: 'h1' }, 'Title'));
  assert.match(heading, /data-font="heading"/);
});
test('no temporary Figma URLs appear in runtime modules or CSS', async () => {
  for (const file of [
    'packages/core/src/assets.ts',
    'packages/core/src/icons.ts',
    'packages/core/src/styles.css',
    'packages/react/src/index.tsx',
    'packages/qwik/src/index.tsx',
  ])
    assert.doesNotMatch(await readFile(file, 'utf8'), /figma\.com\/api\/mcp\/asset/);
});

test('account states match the Figma semantics and expose accessible status', () => {
  for (const [state, icon, label] of [
    ['unstable', 'circle-alert', 'Connection unstable'],
    ['error', 'triangle-alert', 'Account error'],
  ]) {
    const html = renderToStaticMarkup(createElement(ui.Profile, { state }));
    assert.match(html, new RegExp(icon));
    assert.ok(html.includes(label));
    assert.doesNotMatch(html, />!<\/span>/);
  }
  assert.doesNotMatch(renderToStaticMarkup(createElement(ui.Profile)), /as-profile-state/);
  const loading = renderToStaticMarkup(createElement(ui.Profile, { state: 'loading' }));
  assert.match(loading, /aria-busy="true"/);
  assert.doesNotMatch(loading, /as-profile-logo-wrap|as-profile-state/);
});

test('chat composition has one field surface and optional message actions', () => {
  const message = renderToStaticMarkup(createElement(ui.ChatMessage, { text: 'hello' }));
  assert.equal((message.match(/<article/g) || []).length, 1);
  assert.doesNotMatch(message, /as-chat-message-actions|tabindex/);
  const actionable = renderToStaticMarkup(
    createElement(ui.ChatMessage, { text: 'hello', onReply: () => {} }),
  );
  assert.match(actionable, /as-chat-message-actions/);
  assert.match(actionable, /as-chat-button as-chat-plain/);
  const input = renderToStaticMarkup(createElement(ui.ChatInput, { value: '' }));
  assert.match(input, /as-chat-input-surface/);
  const composer = renderToStaticMarkup(
    createElement(ui.ChatComposer, { value: 'hello', onAttach: () => {} }),
  );
  assert.equal((composer.match(/class="as-chat-input-surface"/g) || []).length, 1);
  assert.equal((composer.match(/<textarea/g) || []).length, 1);
  for (const variant of ['emoji', 'attach', 'record', 'send']) {
    const button = renderToStaticMarkup(createElement(ui.ChatButton, { variant, disabled: true }));
    assert.match(button, new RegExp('as-chat-button as-chat-' + variant));
    assert.match(button, /disabled=""/);
  }
});

test('form labels, validation descriptions and native disabled semantics survive rendering', () => {
  for (const Component of [ui.TextInput, ui.TextArea, ui.Select]) {
    const html = renderToStaticMarkup(
      createElement(Component, {
        id: 'field',
        label: 'Name',
        value: 'a',
        disabled: true,
        required: true,
        hint: 'Hint',
        error: 'Error',
        onValueChange: () => {},
        ...(Component === ui.Select
          ? {
              options: [
                { value: 'a', label: 'A' },
                { value: 'b', label: 'B', disabled: true },
              ],
            }
          : {}),
      }),
    );
    assert.match(html, /for="field"/);
    assert.match(html, /id="field-description"/);
    assert.match(html, /aria-describedby="field-description"/);
    assert.match(html, /aria-invalid="true"/);
    assert.match(html, /disabled=""/);
    assert.match(html, /required=""/);
    assert.doesNotMatch(html, /Hint/);
  }
  for (const Component of [ui.Checkbox, ui.Switch]) {
    const html = renderToStaticMarkup(
      createElement(Component, {
        id: 'choice',
        label: 'Choice',
        checked: true,
        disabled: true,
        hint: 'Description',
      }),
    );
    assert.match(html, /type="checkbox"/);
    assert.match(html, /checked=""/);
    assert.match(html, /disabled=""/);
    assert.match(html, /aria-describedby="choice-description"/);
    if (Component === ui.Switch) assert.match(html, /role="switch"/);
  }
});

test('field label placement defaults to inside for editing and above for readonly, with explicit overrides', () => {
  for (const Component of [ui.TextInput, ui.TextArea]) {
    const render = (props) =>
      renderToStaticMarkup(
        createElement(Component, {
          id: 'placement',
          label: 'Name',
          value: '',
          onValueChange: () => {},
          ...props,
        }),
      );
    const inside = render({});
    assert.match(inside, /<(?:input|textarea)[^>]*aria-label="Name"/);
    assert.match(inside, /class="as-field-placeholder" aria-hidden="true"/);
    assert.doesNotMatch(inside, /for="placement"/);
    for (const props of [{ readOnly: true }, { labelPlacement: 'above' }]) {
      const above = render(props);
      assert.match(above, /for="placement"/);
      assert.doesNotMatch(above, /class="as-field-placeholder"/);
    }
    assert.match(
      render({ readOnly: true, labelPlacement: 'inside' }),
      /class="as-field-placeholder"/,
    );
  }
});
