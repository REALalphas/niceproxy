import test from 'node:test';
import assert from 'node:assert/strict';
import {
  scrollbarTrack,
  scrollbarThumb,
  closestTrackPosition,
} from '../packages/core/dist/scrollbar-geometry.js';

test('scrollbar curls at both ends with a bottom grip and reserves a corner grip', () => {
  for (const curvature of [1, 1.2])
    for (const stroke of [1.5, 3]) {
      const full = scrollbarTrack(400, 240, 15, stroke, curvature);
      assert.ok(full.points[0].x > 385);
      assert.ok(full.points[0].y > 2.5 * stroke);
      assert.ok(Math.abs(full.points[0].x - full.points.at(-1).x) < 0.001);
      assert.ok(Math.abs(full.points[0].y + full.points.at(-1).y - 240) < 0.001);
      const corner = scrollbarTrack(400, 240, 15, stroke, curvature, true);
      assert.equal(corner.points.at(-1).y, 240 - 15 - 2 * stroke);
      assert.equal(corner.points.at(-1).x, 400 - 2.5 * stroke);
    }
});
test('minimum-height fields retain thumb travel instead of a full-track unmovable thumb', () => {
  const track = scrollbarTrack(200, 44, 15, 3, 1.2, true);
  const top = scrollbarThumb(track.length, track.arcLength, 44, 8000, 0);
  const bottom = scrollbarThumb(track.length, track.arcLength, 44, 8000, 7956);
  assert.ok(top.size < track.length);
  assert.ok(bottom.start > 0);
  assert.ok(Math.abs(bottom.start + bottom.size - track.length) < 0.00001);
});
test('thumb endpoints track scroll endpoints and tiny thumbs retain the corner contour', () => {
  const track = scrollbarTrack(400, 80, 15, 3, 1.2);
  const top = scrollbarThumb(track.length, track.arcLength, 80, 8000, 0);
  const bottom = scrollbarThumb(track.length, track.arcLength, 80, 8000, 7920);
  assert.equal(top.start, 0);
  assert.equal(top.size, track.arcLength);
  assert.equal(bottom.start + bottom.size, track.length);
  const all = scrollbarThumb(track.length, track.arcLength, 80, 80, 0);
  assert.equal(all.size, track.length);
  assert.equal(all.maximum, 0);
  const last = track.points.at(-1);
  assert.equal(closestTrackPosition(track.points, last.x, last.y), track.length);
});

test('gap between thumb and corner grip equals the frame stroke', () => {
  for (const curvature of [1, 1.2])
    for (const stroke of [1.5, 3]) {
      const track = scrollbarTrack(400, 200, 15, stroke, curvature, true);
      const thumbEdge = track.points.at(-1).y + stroke / 2;
      const gripEdge = 200 - 15 - stroke / 2;
      assert.equal(gripEdge - thumbEdge, stroke);
    }
});
