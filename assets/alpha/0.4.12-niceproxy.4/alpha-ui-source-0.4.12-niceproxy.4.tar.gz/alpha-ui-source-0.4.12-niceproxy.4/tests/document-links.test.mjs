import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { checkDocumentLinks } from '../scripts/lib/document-links.mjs';

const manifests = {
  '@alpha/core': { exports: { '.': './dist/index.js', './catalog.json': './dist/catalog.json' } },
};

test('documentation checks archive membership, headings and reference links', async () => {
  const root = await mkdtemp(join(tmpdir(), 'alpha-doc-links-'));
  try {
    await mkdir(join(root, 'docs'));
    await writeFile(join(root, 'docs/guide.md'), '# Guide\n\n## Start\n\n## Start\n');
    await writeFile(join(root, 'local-only.md'), '# Present in workspace only\n');
    await writeFile(
      join(root, 'README.md'),
      [
        '[guide](docs/guide.md#start-1)',
        '[omitted](local-only.md)',
        '[anchor](docs/guide.md#missing)',
        '[reference][missing]',
        '```md',
        '[example](not-a-real-file.md)',
        '```',
      ].join('\n'),
    );
    const result = await checkDocumentLinks({
      root,
      files: ['README.md', 'docs/guide.md'],
      manifests,
    });
    assert.equal(result.issues.length, 3);
    assert.match(result.issues.join('\n'), /local-only\.md/);
    assert.match(result.issues.join('\n'), /missing heading/);
    assert.match(result.issues.join('\n'), /undefined reference/);
    assert.doesNotMatch(result.issues.join('\n'), /not-a-real-file|start/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('package references use public exports while filesystem paths remain literal', async () => {
  const root = await mkdtemp(join(tmpdir(), 'alpha-doc-exports-'));
  try {
    await writeFile(
      join(root, 'README.md'),
      [
        '`@alpha/core/catalog.json`',
        '`@alpha/core/dist/catalog.json`',
        '`node_modules/@alpha/core/dist/catalog.json`',
      ].join('\n'),
    );
    const result = await checkDocumentLinks({ root, files: ['README.md'], manifests });
    assert.equal(result.issues.length, 1);
    assert.equal(result.packageReferences, 2);
    assert.match(result.issues[0], /not exported: @alpha\/core\/dist\/catalog.json/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
