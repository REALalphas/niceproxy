import test from 'node:test';
import assert from 'node:assert/strict';
import { installChatGradient } from '../packages/core/dist/index.js';

test('chat surfaces share one gradient canvas across layout changes and clean up observers', () => {
  const previousResize = globalThis.ResizeObserver;
  const previousMutation = globalThis.MutationObserver;
  const observers = [];
  class Observer {
    constructor(callback) {
      this.callback = callback;
      this.disconnected = false;
      observers.push(this);
    }
    observe() {}
    unobserve() {}
    disconnect() {
      this.disconnected = true;
    }
  }
  globalThis.ResizeObserver = Observer;
  globalThis.MutationObserver = Observer;
  try {
    let height = 480;
    let scheduled;
    let listenerRemoved = false;
    const makeSurface = (left, top) => {
      const values = new Map();
      return {
        values,
        style: { setProperty: (key, value) => values.set(key, value) },
        getBoundingClientRect: () => ({ left, top, width: 80, height: 48 }),
      };
    };
    const first = makeSurface(120, 98);
    const second = makeSurface(300, 450);
    const root = {
      ownerDocument: {
        documentElement: {},
        defaultView: {
          getComputedStyle: () => ({ fontSize: '16px' }),
          requestAnimationFrame: (callback) => {
            scheduled = callback;
            return 1;
          },
          cancelAnimationFrame: () => {
            scheduled = undefined;
          },
        },
      },
      getBoundingClientRect: () => ({ left: 100, top: 50, width: 320, height }),
      querySelectorAll: () => [first, second],
      addEventListener: () => {},
      removeEventListener: () => {
        listenerRemoved = true;
      },
    };
    const cleanup = installChatGradient(root);
    for (const surface of [first, second]) {
      assert.equal(surface.values.get('--as-chat-gradient-width'), '20rem');
      assert.equal(surface.values.get('--as-chat-gradient-height'), '30rem');
    }
    assert.notEqual(
      first.values.get('--as-chat-gradient-y'),
      second.values.get('--as-chat-gradient-y'),
    );
    assert.equal(second.values.get('--as-chat-gradient-y'), '-25rem');
    height = 640;
    observers[0].callback();
    scheduled();
    assert.equal(first.values.get('--as-chat-gradient-height'), '40rem');
    assert.equal(second.values.get('--as-chat-gradient-height'), '40rem');
    cleanup();
    assert.ok(observers.every((observer) => observer.disconnected));
    assert.ok(listenerRemoved);
  } finally {
    globalThis.ResizeObserver = previousResize;
    globalThis.MutationObserver = previousMutation;
  }
});
