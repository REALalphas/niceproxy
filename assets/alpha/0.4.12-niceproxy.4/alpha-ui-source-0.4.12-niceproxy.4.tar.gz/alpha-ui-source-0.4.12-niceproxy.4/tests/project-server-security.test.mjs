import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { request } from 'node:http';
import { createProjectServer } from '../packages/project-server/src/server.mjs';

async function fixture(t, token) {
  const source = await mkdtemp(join(tmpdir(), 'alpha-http-test-'));
  const { server } = await createProjectServer({ source, framework: 'react', token });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    await rm(source, { recursive: true, force: true });
  });
  return (headers) =>
    new Promise((resolve, reject) => {
      const req = request(
        {
          hostname: '127.0.0.1',
          port: server.address().port,
          path: '/_alpha/update',
          method: 'POST',
          headers,
        },
        (res) => {
          res.resume();
          res.on('end', () => resolve(res.statusCode));
        },
      );
      req.on('error', reject);
      // No outbound request: validation rejects this URL after the access check.
      req.end(JSON.stringify({ manifestUrl: 'file:///invalid' }));
    });
}

test('tokenless update denies a rebinding Host even when Origin matches', async (t) => {
  const post = await fixture(t);
  assert.equal(await post({ host: 'attacker.example', origin: 'http://attacker.example' }), 403);
  assert.equal(await post({ host: 'attacker.example' }), 403);
  assert.equal(await post({ host: '127.0.0.1:5191', origin: 'https://attacker.example' }), 403);
  for (const host of ['127.0.0.1:5191', 'localhost:5191', '[::1]:5191', 'localhost:80']) {
    assert.equal(await post({ host }), 500, `${host}: local request reaches manifest validation`);
  }
});

test('reverse proxy updates require the configured bearer token', async (t) => {
  const post = await fixture(t, 'fixture-token');
  assert.equal(await post({ host: 'project.example' }), 403);
  assert.equal(await post({ host: 'project.example', authorization: 'Bearer incorrect' }), 403);
  assert.equal(await post({ host: 'project.example', authorization: 'Bearer fixture-token' }), 500);
  assert.equal(
    await post({
      host: 'project.example',
      authorization: 'Bearer fixture-token',
      origin: 'https://other.example',
    }),
    403,
  );
});
