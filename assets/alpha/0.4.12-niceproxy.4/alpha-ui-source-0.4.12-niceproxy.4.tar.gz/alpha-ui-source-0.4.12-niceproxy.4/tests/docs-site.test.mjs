import assert from 'node:assert/strict';
import test from 'node:test';
import {
  docsBase,
  exampleUrl,
  componentProps,
  rewriteDocsLinks,
} from '../scripts/lib/docs-site.mjs';
import { components } from '../source/components/index.mjs';
import { examples } from '../source/docs/examples.mjs';
import { renderExample } from '../scripts/lib/docs-examples.mjs';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createRequire } from 'node:module';
import { runInNewContext } from 'node:vm';
import ts from 'typescript';
import * as ui from '../packages/react/dist/index.js';

test('documentation paths support project Pages, root Pages and reject traversal', () => {
  assert.equal(docsBase(), '/');
  assert.equal(docsBase(''), '/');
  assert.equal(docsBase('/alphas-base'), '/alphas-base/');
  assert.equal(docsBase('/team/library/'), '/team/library/');
  assert.throws(() => docsBase('../private'));
  assert.throws(() => docsBase('https://example.com'));
});

test('documentation links preserve code, external URLs and heading fragments', () => {
  const source =
    '[Контракт](chat.md#поведение)\n[Исходник](../source/README.md)\n[Внешний](https://example.com/)\n`[Код](chat.md)`\n```md\n[Пример](chat.md)\n```';
  const rewritten = rewriteDocsLinks(
    source,
    'docs/agent-guide.md',
    '/library/',
    (file) => '/library/reference/' + file,
  );
  assert.equal(
    rewritten,
    '[Контракт](/library/guides/chat/#поведение)\n[Исходник](/library/reference/source/README.md)\n[Внешний](https://example.com/)\n`[Код](chat.md)`\n```md\n[Пример](chat.md)\n```',
  );
});

test('every public component has an executable documentation example', () => {
  assert.deepEqual(
    Object.keys(examples).sort(),
    components.map((component) => component.name).sort(),
  );
});

test('example URLs address public HTML files in dev and in a Pages subpath', () => {
  assert.equal(exampleUrl('/', 'react', 'Button'), '/examples/react/index.html?component=Button');
  assert.equal(
    exampleUrl('/library/', 'qwik', 'Select'),
    '/library/examples/qwik/index.html?component=Select',
  );
  assert.throws(() => exampleUrl('/', 'react'));
  assert.throws(() => exampleUrl('/', 'unknown'));
});

test('API reference keeps nested object and callback types intact', () => {
  const props = componentProps(
    'value: string; context?: { label: string; options: { value: string; disabled?: boolean }[] }; onValueChange@?: Handler<[value: string]>;',
  );
  assert.deepEqual(
    props.map(({ name, optional }) => ({ name, optional })),
    [
      { name: 'value', optional: false },
      { name: 'context', optional: true },
      { name: 'onValueChange', optional: true },
    ],
  );
  assert.match(props[1].type, /disabled\?: boolean/);
  assert.equal(props[2].type, 'Handler<[value: string]>');
});

test('Badge documentation renders a navigation counter rather than an isolated badge', async () => {
  const source = await renderExample('Badge', 'react');
  const { outputText } = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
  });
  const require = createRequire(import.meta.url);
  const context = {
    exports: {},
    require: (name) => (name === '@alpha/react' ? ui : require(name)),
  };
  runInNewContext(outputText, context);
  const html = renderToStaticMarkup(createElement(context.exports.BadgeExample));
  const badge = html.indexOf('class="as-badge"');
  assert(badge > html.indexOf('class="as-nav-icon"'));
  assert(badge < html.indexOf('</button>'));
  assert.match(html, />3<\/span>/);
});
