import test from 'node:test';
import assert from 'node:assert/strict';
import { cornerArc } from '../source/components/helpers/resize-geometry.mjs';

test('corner grip leaves one stroke of clearance around both circular and superellipse frames', () => {
  for (const curvature of [1, 1.2])
    for (const stroke of [1.5, 3]) {
      const radius = 15,
        inner = radius - stroke,
        power = 2 / 2 ** curvature;
      const edge = Array.from({ length: 4097 }, (_, i) => {
        const t = (i * Math.PI) / 8192;
        return [radius + inner * Math.cos(t) ** power, radius + inner * Math.sin(t) ** power];
      });
      for (const [x, y] of cornerArc(radius, stroke, curvature).points) {
        const distance = Math.min(...edge.map(([ex, ey]) => Math.hypot(ex - x, ey - y)));
        assert.ok(Math.abs(distance - stroke / 2 - stroke) < 0.005, `uneven gap at ${x},${y}`);
      }
    }
});
