import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { create } from 'tar';
import {
  createReleaseSource,
  extractReleaseSource,
  sourceDirectories,
  sourceRootFiles,
} from '../scripts/lib/release-source.mjs';

async function fixture(run) {
  const scratch = await mkdtemp(join(tmpdir(), 'alpha-source-test-'));
  const root = join(scratch, 'workspace');
  try {
    await mkdir(root);
    for (const file of sourceRootFiles) {
      await writeFile(
        join(root, file),
        file === 'package.json' ? '{"version":"0.2.0"}\n' : `fixture: ${file}\n`,
      );
    }
    for (const directory of sourceDirectories) {
      await mkdir(join(root, directory), { recursive: true });
      await writeFile(join(root, directory, 'fixture.txt'), `source: ${directory}\n`);
    }
    await run({ root, scratch, release: join(scratch, 'release'), version: '1.2.3-test' });
  } finally {
    await rm(scratch, { recursive: true, force: true });
  }
}

test('source archive preserves canonical sources and lock while excluding local artifacts', async () => {
  await fixture(async ({ root, scratch, release, version }) => {
    for (const file of [
      'source/components/Button.mjs',
      'source/demo/Demo.tsx.template',
      'packages/core/src/styles.css',
      'packages/react/src/components/Button.tsx',
      'apps/qwik/src/demo.tsx',
    ]) {
      await mkdir(dirname(join(root, file)), { recursive: true });
      await writeFile(join(root, file), `canonical: ${file}\n`);
    }
    for (const file of [
      '.env',
      'unknown-root.txt',
      'releases/old/file.tgz',
      'apps/shared/local-assets/TestProfilePicture1.png',
      'packages/react/dist/index.js',
      'packages/react/src/Button.sync-conflict-local.tsx',
      'source/node_modules/dependency/index.js',
      'apps/docs/.astro/types.d.ts',
      'apps/docs/public/examples/react/index.html',
      'apps/docs/src/content/docs/index.mdx',
      'source/.env.production',
      'source/.npmrc',
      'source/secrets/token.txt',
      'source/private.key',
      'source/debug.log',
      'source/fixture.txt~',
      'examples/react/.alpha-builds/build/index.html',
    ]) {
      await mkdir(dirname(join(root, file)), { recursive: true });
      await writeFile(join(root, file), 'LOCAL ONLY\n');
    }
    const source = await createReleaseSource({ root, target: release, version });
    const target = join(scratch, 'extracted');
    const files = await extractReleaseSource({
      release,
      manifest: { version, source },
      target,
    });
    for (const file of files) {
      assert.deepEqual(await readFile(join(target, file)), await readFile(join(root, file)));
      assert.doesNotMatch(await readFile(join(target, file), 'utf8'), /LOCAL ONLY/);
    }
    assert.ok(files.includes('package-lock.json'));
    assert.ok(files.includes('source/demo/Demo.tsx.template'));
    assert.ok(files.includes('packages/react/src/components/Button.tsx'));
    assert.deepEqual(JSON.parse(await readFile(join(target, 'RELEASE_SOURCE.json'), 'utf8')), {
      schema: 1,
      version,
      workspaceVersion: '0.2.0',
    });
  });
});

test('source archiving rejects symlinks and missing build inputs', async () => {
  await fixture(async ({ root, scratch, release, version }) => {
    await symlink(join(root, 'LICENSE'), join(root, 'source/external.mjs'));
    await assert.rejects(createReleaseSource({ root, target: release, version }), /symlink/);
    await rm(join(root, 'source/external.mjs'));
    await rm(join(root, 'package-lock.json'));
    await assert.rejects(createReleaseSource({ root, target: release, version }), /ENOENT/);
    await assert.rejects(
      createReleaseSource({ root, target: scratch, version: '../elsewhere' }),
      /Invalid release version/,
    );
  });
});

test('source extraction rejects corruption and a different release version', async () => {
  await fixture(async ({ root, scratch, release, version }) => {
    const source = await createReleaseSource({ root, target: release, version });
    const target = join(scratch, 'extracted');
    await assert.rejects(
      extractReleaseSource({
        release,
        manifest: { version: '1.2.4', source },
        target,
      }),
      /manifest.source/,
    );
    const bytes = await readFile(join(release, source.file));
    bytes[bytes.length - 1] ^= 1;
    await writeFile(join(release, source.file), bytes);
    await assert.rejects(
      extractReleaseSource({ release, manifest: { version, source }, target }),
      /integrity mismatch/,
    );
  });
});

test('source extraction rejects links and duplicate paths even with a matching checksum', async () => {
  await fixture(async ({ root, scratch, release, version }) => {
    await mkdir(release);
    await symlink('LICENSE', join(root, 'source/link'));
    for (const entries of [['source/link'], ['LICENSE', 'LICENSE']]) {
      const file = `alpha-ui-source-${version}.tar.gz`;
      await create(
        { file: join(release, file), cwd: root, prefix: `alpha-ui-source-${version}`, gzip: true },
        entries,
      );
      const bytes = await readFile(join(release, file));
      const source = {
        file,
        size: bytes.length,
        integrity: `sha512-${createHash('sha512').update(bytes).digest('base64')}`,
      };
      await assert.rejects(
        extractReleaseSource({
          release,
          manifest: { version, source },
          target: join(scratch, 'extracted'),
        }),
        /Unexpected source entry type|Duplicate source file/,
      );
    }
  });
});
