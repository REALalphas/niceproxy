import test from 'node:test';
import assert from 'node:assert/strict';
import { loadingFramePath } from '../packages/core/dist/loading-frame.js';

test('loading contour follows wide and multiline controls without stretching corners', () => {
  for (const [width, height, radius] of [
    [100, 38, 12],
    [600, 40, 20],
    [257, 103, 12],
    [24, 24, 20],
  ]) {
    const path = loadingFramePath(width, height, radius, 2, 1.2);
    assert.ok(path.endsWith(' Z'));
    const points = [...path.matchAll(/[ML]([\d.-]+) ([\d.-]+)/g)].map((m) => [
      Number(m[1]),
      Number(m[2]),
    ]);
    assert.equal(Math.min(...points.map((p) => p[0])), 1);
    assert.equal(Math.max(...points.map((p) => p[0])), width - 1);
    assert.equal(Math.min(...points.map((p) => p[1])), 1);
    assert.equal(Math.max(...points.map((p) => p[1])), height - 1);
    assert.equal(points[0][0], width - Math.min(radius, width / 2, height / 2));
  }
});

test('unsupported corner-shape retains a round contour', () => {
  assert.notEqual(loadingFramePath(100, 40, 12, 2, 1), loadingFramePath(100, 40, 12, 2, 1.2));
});
